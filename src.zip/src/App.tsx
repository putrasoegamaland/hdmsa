import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider } from './components/AuthProvider';
import PrivateRoute from './components/PrivateRoute';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import HousingUnits from './components/HousingUnits';
import Contractors from './components/Contractors';
import Tasks from './components/Tasks';
import Reports from './components/Reports';
import ProjectPortfolio from './components/ProjectPortfolio';
import HouseTypes from './components/HouseTypes';
import Workflows from './components/workflows';

import Sidebar from './components/Sidebar';
import NotificationBell from './components/NotificationBell';
import UserProfile from './components/UserProfile';
import SharedHousingUnitView from './components/SharedHousingUnitView';
import { Menu, Settings } from 'lucide-react';

// Layout component for authenticated pages
const AppLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#f8fafc] flex">
      {/* Mobile sidebar */}
      <div className={`fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`} onClick={() => setSidebarOpen(false)} />
      
      <div className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-white transform lg:transform-none lg:opacity-100
        transition duration-200 ease-in-out lg:relative lg:flex
        ${sidebarOpen ? 'translate-x-0 opacity-100' : '-translate-x-full opacity-0 lg:translate-x-0'}
      `}>
        <Sidebar onClose={() => setSidebarOpen(false)} />
      </div>

      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <div className="h-[72px] bg-white border-b border-gray-100 flex items-center px-4">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 text-gray-500 hover:text-gray-700 lg:hidden"
          >
            <Menu className="h-6 w-6" />
          </button>
          <div className="flex-1" />
          <div className="flex items-center space-x-4">
            <NotificationBell />
            <button
              onClick={() => setProfileOpen(true)}
              className="p-2 text-gray-500 hover:text-gray-700 rounded-full hover:bg-gray-100"
            >
              <Settings className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-auto p-6">
          <Outlet />
        </div>
      </div>
      <UserProfile isOpen={profileOpen} onClose={() => setProfileOpen(false)} />
    </div>
  );
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          {/* Shared Public Routes */}
          <Route path="/shared/housing-unit/:token" element={<SharedHousingUnitView />} />
          
          {/* Protected Routes */}
          <Route path="/" element={<PrivateRoute><AppLayout /></PrivateRoute>}>
            <Route index element={<Dashboard />} />
            <Route path="housing-units" element={<HousingUnits />} />
            <Route path="contractors" element={<Contractors />} />
            <Route path="tasks" element={<Tasks />} />
            <Route path="reports" element={<Reports />} />
            <Route path="projects" element={<ProjectPortfolio />} />
            <Route path="house-types" element={<HouseTypes />} />
            <Route path="workflows" element={<Workflows />} />
          </Route>

          {/* Catch all route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;