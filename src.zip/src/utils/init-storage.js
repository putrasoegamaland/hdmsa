import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * Initialize storage bucket for task photos with proper permissions
 * @returns {Promise<{success: boolean, message: string, details?: any}>}
 */
export async function initializeStorageBucket() {
  try {
    // Check if bucket exists
    const { data: buckets, error: getBucketsError } = await supabase.storage.listBuckets();
    
    if (getBucketsError) {
      console.error('Error listing buckets:', getBucketsError);
      return {
        success: false,
        message: `Failed to list buckets: ${getBucketsError.message}`,
        details: getBucketsError
      };
    }

    const taskPhotosBucket = buckets.find(bucket => bucket.name === 'task-photos');
    
    // Create bucket if it doesn't exist
    if (!taskPhotosBucket) {
      const { data: newBucket, error: createBucketError } = await supabase.storage.createBucket('task-photos', {
        public: true, // Allows files to be publicly accessible with correct permissions
        fileSizeLimit: 10485760, // 10MB
        allowedMimeTypes: ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/webp']
      });
      
      if (createBucketError) {
        console.error('Error creating bucket:', createBucketError);
        return {
          success: false,
          message: `Failed to create task-photos bucket: ${createBucketError.message}`,
          details: createBucketError
        };
      }
      
      return {
        success: true,
        message: 'Successfully created task-photos bucket',
        details: newBucket
      };
    }
    
    return {
      success: true,
      message: 'task-photos bucket already exists',
      details: taskPhotosBucket
    };
  } catch (error) {
    console.error('Storage initialization failed:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : String(error),
      details: error
    };
  }
}

/**
 * Verify the current user has proper access to the storage bucket
 * @returns {Promise<{success: boolean, message: string, details?: any}>}
 */
export async function verifyUserStorageAccess() {
  try {
    // Check if user is authenticated
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError || !user) {
      return {
        success: false,
        message: userError ? `Authentication error: ${userError.message}` : 'User not authenticated',
        details: userError
      };
    }
    
    // Test permission: Try to list files
    const testFolder = `tests/${user.id}`;
    const { data: files, error: listError } = await supabase.storage
      .from('task-photos')
      .list(testFolder);
    
    if (listError) {
      return {
        success: false,
        message: `Cannot list files: ${listError.message}`,
        details: listError
      };
    }
    
    // Test permission: Try to upload a small test file
    const testContent = new Blob(['test'], { type: 'text/plain' });
    const testFilePath = `${testFolder}/permission-test-${Date.now()}.txt`;
    
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('task-photos')
      .upload(testFilePath, testContent);
    
    if (uploadError) {
      return {
        success: false,
        message: `Cannot upload files: ${uploadError.message}`,
        details: { uploadError, canList: true }
      };
    }
    
    // Clean up the test file
    const { error: removeError } = await supabase.storage
      .from('task-photos')
      .remove([testFilePath]);
    
    if (removeError) {
      console.warn('Could not remove test file:', removeError);
    }
    
    return {
      success: true,
      message: 'User has proper storage permissions',
      details: {
        canList: true,
        canUpload: true,
        canDelete: !removeError,
        userId: user.id,
        testPath: testFilePath,
        uploadResult: uploadData
      }
    };
  } catch (error) {
    console.error('Access verification failed:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : String(error),
      details: error
    };
  }
}

/**
 * Generate SQL policy template for task-photos bucket
 * This can be executed by an admin in the SQL editor
 * @returns {Promise<{success: boolean, message: string, sql: string}>}
 */
export async function updateStoragePolicies() {
  // This function doesn't actually execute the SQL,
  // but provides a template that can be run by an admin
  try {
    const sql = `
-- Enable Row Level Security
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to read any file in the bucket
CREATE POLICY "Authenticated users can read any file" 
ON storage.objects FOR SELECT 
TO authenticated 
USING (bucket_id = 'task-photos');

-- Allow authenticated users to upload files
CREATE POLICY "Authenticated users can upload files" 
ON storage.objects FOR INSERT 
TO authenticated 
WITH CHECK (bucket_id = 'task-photos');

-- Allow users to update their own files
CREATE POLICY "Users can update own files" 
ON storage.objects FOR UPDATE 
TO authenticated 
USING (bucket_id = 'task-photos' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Allow users to delete their own files
CREATE POLICY "Users can delete own files" 
ON storage.objects FOR DELETE 
TO authenticated 
USING (bucket_id = 'task-photos' AND auth.uid()::text = (storage.foldername(name))[1]);
`;

    return {
      success: true,
      message: 'Generated SQL policy template for task-photos bucket',
      sql
    };
  } catch (error) {
    console.error('Error generating policy template:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : String(error)
    };
  }
}