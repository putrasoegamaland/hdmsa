import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initializeStorageBucket } from './utils/init-storage';

// Initialize storage bucket with retries
(async function initStorage() {
  try {
    const result = await initializeStorageBucket();
    console.log('Storage initialization result:', result);
    
    if (!result.success) {
      console.warn('Storage initialization failed, retrying in 3 seconds...');
      // Retry once after 3 seconds
      setTimeout(async () => {
        const retryResult = await initializeStorageBucket();
        console.log('Storage initialization retry result:', retryResult);
      }, 3000);
    }
  } catch (error) {
    console.error('Storage initialization error:', error);
  }
})();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
