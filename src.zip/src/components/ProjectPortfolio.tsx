import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Search, Filter, MapPin, Calendar, Building2, Trash2, X, Loader2, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import AddProject from './AddProject';
import ProjectDetails from './ProjectDetails';

interface Project {
  id: string;
  title: string;
  status: string;
  description: string;
  address: string;
  start_date: string;
  target_completion_date: string;
  estimated_completion_date: string;
  handover_date: string | null;
  payment_total: number;
  payment_received: number;
  payment_percentage: number;
  total_units: number;
  delayed_units: number;
  created_at: string;
  updated_at: string;
  housing_units: {
    id: string;
    status: string;
    payment_phase: string;
  }[];
}

interface DeleteConfirmation {
  projectId: string;
  projectTitle: string;
  isDeleting: boolean;
}

const ProjectPortfolio = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteConfirmation, setDeleteConfirmation] = useState<DeleteConfirmation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  useEffect(() => {
    fetchProjects();
  }, []);

  async function fetchProjects() {
    try {
      const { data, error } = await supabase
        .from('projects')
        .select(`
          *,
          housing_units (
            id,
            status,
            payment_phase
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Calculate real-time metrics for each project
      const updatedProjects = (data || []).map(project => {
        const units = project.housing_units || [];
        const totalUnits = units.length;
        const delayedUnits = units.filter(u => u.status === 'delayed').length;
        const completedUnits = units.filter(u => u.status === 'completed').length;
        const inProgressUnits = totalUnits - completedUnits - delayedUnits;

        // Calculate payment metrics
        const fullPaymentUnits = units.filter(u => u.payment_phase === 'full-payment').length;
        const phase2Units = units.filter(u => u.payment_phase === 'phase-2').length;
        const phase1Units = units.filter(u => u.payment_phase === 'phase-1').length;

        const paymentReceived = (
          fullPaymentUnits * project.payment_total +
          phase2Units * project.payment_total * 0.7 +
          phase1Units * project.payment_total * 0.3
        );

        const paymentPercentage = project.payment_total > 0 
          ? (paymentReceived / (project.payment_total * totalUnits)) * 100 
          : 0;

        return {
          ...project,
          total_units: totalUnits,
          delayed_units: delayedUnits,
          payment_received: paymentReceived,
          payment_percentage: Math.round(paymentPercentage)
        };
      });

      setProjects(updatedProjects);
    } catch (error: any) {
      console.error('Error fetching projects:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  }

  const handleDeleteProject = async () => {
    if (!deleteConfirmation) return;

    try {
      setDeleteConfirmation({ ...deleteConfirmation, isDeleting: true });

      const { error } = await supabase
        .from('projects')
        .delete()
        .eq('id', deleteConfirmation.projectId);

      if (error) throw error;

      setProjects(projects.filter(project => project.id !== deleteConfirmation.projectId));
      setDeleteConfirmation(null);
    } catch (error: any) {
      setError(`Failed to delete project: ${error.message}`);
    }
  };

  const filteredProjects = projects.filter(project =>
    project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.address?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const statusColors = {
    'planning': 'bg-purple-100 text-purple-800',
    'in-progress': 'bg-blue-100 text-blue-800',
    'on-hold': 'bg-yellow-100 text-yellow-800',
    'completed': 'bg-green-100 text-green-800'
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Project Portfolio</h1>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add New Project
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="flex-shrink-0 ml-4 text-red-500 hover:text-red-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      <div className="flex space-x-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search projects..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
          <Filter className="h-5 w-5 mr-2" />
          Filter
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => setSelectedProjectId(project.id)}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">{project.title}</h2>
                    <p className="mt-1 text-sm text-gray-500">{project.description}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusColors[project.status as keyof typeof statusColors]}`}>
                    {project.status}
                  </span>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-500">
                    <MapPin className="h-4 w-4 mr-2" />
                    {project.address}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="h-4 w-4 mr-2" />
                    Target: {format(new Date(project.target_completion_date), 'MMM dd, yyyy')}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Building2 className="h-4 w-4 mr-2" />
                    Units: {project.total_units} (Delayed: {project.delayed_units})
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium text-gray-500">Payment Progress</span>
                    <span className="text-sm font-medium text-gray-900">{project.payment_percentage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${project.payment_percentage}%` }}
                    ></div>
                  </div>
                  <div className="mt-2 text-sm text-gray-500">
                    {new Intl.NumberFormat('id-ID', {
                      style: 'currency',
                      currency: 'IDR',
                      minimumFractionDigits: 0,
                      maximumFractionDigits: 0
                    }).format(project.payment_received)} / {new Intl.NumberFormat('id-ID', {
                      style: 'currency',
                      currency: 'IDR',
                      minimumFractionDigits: 0,
                      maximumFractionDigits: 0
                    }).format(project.payment_total * project.total_units)}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Project Modal */}
      {isAddModalOpen && (
        <AddProject
          onClose={() => setIsAddModalOpen(false)}
          onSuccess={fetchProjects}
        />
      )}

      {/* Project Details Modal */}
      {selectedProjectId && (
        <ProjectDetails
          projectId={selectedProjectId}
          onClose={() => setSelectedProjectId(null)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-gray-900">
                  Delete Project
                </h3>
                <div className="mt-2">
                  <p className="text-sm text-gray-500">
                    Are you sure you want to delete "{deleteConfirmation.projectTitle}"? This action cannot be undone and will also delete all associated housing units and tasks.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setDeleteConfirmation(null)}
                disabled={deleteConfirmation.isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteProject}
                disabled={deleteConfirmation.isDeleting}
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                {deleteConfirmation.isDeleting ? (
                  <>
                    <Loader2 className="animate-spin h-4 w-4 mr-2" />
                    Deleting...
                  </>
                ) : (
                  'Delete Project'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProjectPortfolio;