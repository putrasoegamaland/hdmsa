import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { AlertTriangle, Loader2, X, TrendingUp, TrendingDown, Clock } from 'lucide-react';
import { format, differenceInDays } from 'date-fns';

interface ProgressData {
  unit_number: string;
  current_progress: number;
  target_progress: number;
  last_update: string;
  status: string;
  days_remaining: number;
  completion_rate: number;
}

interface Anomaly {
  type: string;
  severity: 'low' | 'medium' | 'high';
  message: string;
  unit_number: string;
  details: any;
}

const ProgressTracking = () => {
  const [progressData, setProgressData] = useState<ProgressData[]>([]);
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProgressData();
  }, []);

  const fetchProgressData = async () => {
    try {
      const { data: units, error: unitsError } = await supabase
        .from('housing_units')
        .select(`
          id,
          unit_number,
          status,
          target_handover_date,
          workflow_started_at,
          workflow_template_id,
          housing_unit_progress (
            progress_percentage,
            report_date
          )
        `)
        .order('unit_number');

      if (unitsError) throw unitsError;

      // Process units to calculate progress metrics
      const processedData = units?.map(unit => {
        const progress = unit.housing_unit_progress || [];
        const latestProgress = progress.sort((a, b) => 
          new Date(b.report_date).getTime() - new Date(a.report_date).getTime()
        )[0];

        const daysRemaining = differenceInDays(
          new Date(unit.target_handover_date),
          new Date()
        );

        const daysElapsed = differenceInDays(
          new Date(),
          new Date(unit.workflow_started_at || new Date())
        );

        const completionRate = daysElapsed > 0 
          ? (latestProgress?.progress_percentage || 0) / daysElapsed 
          : 0;

        return {
          unit_number: unit.unit_number,
          current_progress: latestProgress?.progress_percentage || 0,
          target_progress: calculateTargetProgress(
            new Date(unit.workflow_started_at || new Date()),
            new Date(unit.target_handover_date)
          ),
          last_update: latestProgress?.report_date || unit.workflow_started_at,
          status: unit.status,
          days_remaining: daysRemaining,
          completion_rate: completionRate
        };
      }) || [];

      setProgressData(processedData);

      // Detect anomalies
      const detectedAnomalies = detectAnomalies(processedData);
      setAnomalies(detectedAnomalies);

    } catch (error: any) {
      console.error('Error fetching progress data:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const calculateTargetProgress = (startDate: Date, endDate: Date): number => {
    const totalDays = differenceInDays(endDate, startDate);
    const elapsedDays = differenceInDays(new Date(), startDate);
    return Math.min(100, Math.round((elapsedDays / totalDays) * 100));
  };

  const detectAnomalies = (data: ProgressData[]): Anomaly[] => {
    const anomalies: Anomaly[] = [];

    // Calculate average completion rate
    const rates = data.map(unit => unit.completion_rate).filter(rate => rate > 0);
    const avgRate = rates.reduce((sum, rate) => sum + rate, 0) / rates.length;
    const stdDev = Math.sqrt(
      rates.reduce((sum, rate) => sum + Math.pow(rate - avgRate, 2), 0) / rates.length
    );

    data.forEach(unit => {
      // Check for significant delays
      if (unit.current_progress < unit.target_progress - 20) {
        anomalies.push({
          type: 'delay',
          severity: 'high',
          message: `Unit ${unit.unit_number} is significantly behind schedule`,
          unit_number: unit.unit_number,
          details: {
            current: unit.current_progress,
            target: unit.target_progress,
            gap: unit.target_progress - unit.current_progress
          }
        });
      }

      // Check for unusual completion rates
      const zScore = Math.abs((unit.completion_rate - avgRate) / stdDev);
      if (zScore > 2) {
        anomalies.push({
          type: 'rate',
          severity: zScore > 3 ? 'high' : 'medium',
          message: `Unusual progress rate detected for unit ${unit.unit_number}`,
          unit_number: unit.unit_number,
          details: {
            rate: unit.completion_rate,
            average: avgRate,
            deviation: zScore
          }
        });
      }

      // Check for stalled progress
      const daysSinceUpdate = differenceInDays(new Date(), new Date(unit.last_update));
      if (daysSinceUpdate > 7 && unit.current_progress < 100) {
        anomalies.push({
          type: 'stalled',
          severity: daysSinceUpdate > 14 ? 'high' : 'medium',
          message: `No progress updates for unit ${unit.unit_number} in ${daysSinceUpdate} days`,
          unit_number: unit.unit_number,
          details: {
            daysSinceUpdate,
            lastUpdate: unit.last_update
          }
        });
      }
    });

    return anomalies;
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-semibold text-gray-900">Progress Overview</h2>
        <p className="mt-1 text-sm text-gray-500">
          Track and analyze construction progress across all units
        </p>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="flex-shrink-0 ml-4 text-red-500 hover:text-red-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      {/* Progress Chart */}
      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h3 className="text-sm font-medium text-gray-900 mb-4">Progress by Unit</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={progressData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="unit_number" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="current_progress" name="Current Progress" fill="#3B82F6" />
              <Bar dataKey="target_progress" name="Target Progress" fill="#E5E7EB" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Anomalies */}
      {anomalies.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm divide-y divide-gray-200">
          <div className="p-6">
            <h3 className="text-sm font-medium text-gray-900 mb-4">
              Detected Anomalies ({anomalies.length})
            </h3>
            <div className="space-y-4">
              {anomalies.map((anomaly, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg ${
                    anomaly.severity === 'high'
                      ? 'bg-red-50'
                      : anomaly.severity === 'medium'
                      ? 'bg-yellow-50'
                      : 'bg-blue-50'
                  }`}
                >
                  <div className="flex items-start">
                    <div className={`p-2 rounded-full ${
                      anomaly.severity === 'high'
                        ? 'bg-red-100 text-red-600'
                        : anomaly.severity === 'medium'
                        ? 'bg-yellow-100 text-yellow-600'
                        : 'bg-blue-100 text-blue-600'
                    }`}>
                      {anomaly.type === 'delay' ? (
                        <TrendingDown className="h-5 w-5" />
                      ) : anomaly.type === 'rate' ? (
                        <TrendingUp className="h-5 w-5" />
                      ) : (
                        <Clock className="h-5 w-5" />
                      )}
                    </div>
                    <div className="ml-3">
                      <p className={`text-sm font-medium ${
                        anomaly.severity === 'high'
                          ? 'text-red-800'
                          : anomaly.severity === 'medium'
                          ? 'text-yellow-800'
                          : 'text-blue-800'
                      }`}>
                        {anomaly.message}
                      </p>
                      <div className="mt-2 text-sm">
                        {anomaly.type === 'delay' && (
                          <p>
                            Current: {anomaly.details.current}% vs Target: {anomaly.details.target}%
                            <br />
                            Gap: {anomaly.details.gap}%
                          </p>
                        )}
                        {anomaly.type === 'rate' && (
                          <p>
                            Rate: {anomaly.details.rate.toFixed(2)}% per day
                            <br />
                            Avg: {anomaly.details.average.toFixed(2)}% per day
                          </p>
                        )}
                        {anomaly.type === 'stalled' && (
                          <p>
                            Last update: {format(new Date(anomaly.details.lastUpdate), 'MMM d, yyyy')}
                            <br />
                            Days inactive: {anomaly.details.daysSinceUpdate}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Detailed Progress Table */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Unit
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Progress
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Days Remaining
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Last Update
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {progressData.map((unit) => (
              <tr key={unit.unit_number}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {unit.unit_number}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="w-32 bg-gray-200 rounded-full h-2 mr-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${unit.current_progress}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-500">
                      {unit.current_progress}%
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    unit.status === 'completed'
                      ? 'bg-green-100 text-green-800'
                      : unit.status === 'delayed'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}>
                    {unit.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {unit.days_remaining} days
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(new Date(unit.last_update), 'MMM d, yyyy')}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProgressTracking;