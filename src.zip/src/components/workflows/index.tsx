import React, { useState } from 'react';
import WorkflowTemplates from './WorkflowTemplates';
import WorkflowInstances from './WorkflowInstances';
import QualityControl from './QualityControl';
import ProgressTracking from './ProgressTracking';
import AnomalyDetection from './AnomalyDetection';

const Workflows = () => {
  const [activeTab, setActiveTab] = useState<'templates' | 'instances' | 'quality' | 'progress' | 'anomalies'>('templates');

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('templates')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'templates'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Templates
          </button>
          <button
            onClick={() => setActiveTab('instances')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'instances'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Active Workflows
          </button>
          <button
            onClick={() => setActiveTab('quality')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'quality'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Quality Control
          </button>
          <button
            onClick={() => setActiveTab('progress')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'progress'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Progress Tracking
          </button>
          <button
            onClick={() => setActiveTab('anomalies')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'anomalies'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Anomaly Detection
          </button>
        </nav>
      </div>

      {activeTab === 'templates' && <WorkflowTemplates />}
      {activeTab === 'instances' && <WorkflowInstances />}
      {activeTab === 'quality' && <QualityControl />}
      {activeTab === 'progress' && <ProgressTracking />}
      {activeTab === 'anomalies' && <AnomalyDetection />}
    </div>
  );
};

export default Workflows;