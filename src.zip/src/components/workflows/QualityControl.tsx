import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Plus, Camera, Upload, AlertTriangle, Loader2, X, AlertCircle, CheckCircle2, Maximize2 } from 'lucide-react';
import { createNotification } from '../../lib/notifications';
import { format } from 'date-fns';

interface InspectionTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  house_type_id: string | null;
  version: number;
}

interface Inspector {
  id: string;
  name: string;
  email: string;
  status: string;
}

interface HousingUnit {
  id: string;
  unit_number: string;
  status: string;
  house_type_id: string | null;
}

interface QualityCheck {
  id: string;
  housing_unit_id: string;
  inspector_id: string;
  inspection_date: string;
  category: string;
  result: 'pass' | 'fail' | 'pending';
  findings: string[];
  evidence: string[];
  notes: string;
  created_at: string;
  inspector: {
    name: string;
  };
  housing_unit: {
    unit_number: string;
    status: string;
  };
}

const QualityControl = () => {
  const [checks, setChecks] = useState<QualityCheck[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [templates, setTemplates] = useState<InspectionTemplate[]>([]);
  const [inspectors, setInspectors] = useState<Inspector[]>([]);
  const [housingUnits, setHousingUnits] = useState<HousingUnit[]>([]);
  const [formData, setFormData] = useState({
    template_id: '',
    housing_unit_id: '',
    inspector_id: '',
    inspection_date: format(new Date(), 'yyyy-MM-dd\'T\'HH:mm'),
    notes: ''
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchQualityChecks();
    fetchTemplates();
    fetchInspectors();
    fetchHousingUnits();
  }, []);

  const fetchQualityChecks = async () => {
    try {
      const { data, error } = await supabase
        .from('unit_inspections')
        .select(`
          *,
          inspector:inspector_id(name),
          housing_unit:housing_unit_id(unit_number, status)
        `)
        .order('inspection_date', { ascending: false });

      if (error) throw error;
      setChecks(data || []);
    } catch (error: any) {
      console.error('Error fetching quality checks:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('inspection_templates')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  };

  const fetchInspectors = async () => {
    try {
      const { data, error } = await supabase
        .from('contractors')
        .select('*')
        .eq('status', 'Active')
        .order('name');

      if (error) throw error;
      setInspectors(data || []);
    } catch (error) {
      console.error('Error fetching inspectors:', error);
    }
  };

  const fetchHousingUnits = async () => {
    try {
      const { data, error } = await supabase
        .from('housing_units')
        .select('*')
        .order('unit_number');

      if (error) throw error;
      setHousingUnits(data || []);
    } catch (error) {
      console.error('Error fetching housing units:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      // Get template details
      const template = templates.find(t => t.id === formData.template_id);
      if (!template) throw new Error('Invalid template selected');

      // Create inspection
      const { data: inspection, error: inspectionError } = await supabase
        .from('unit_inspections')
        .insert([{
          template_id: formData.template_id,
          housing_unit_id: formData.housing_unit_id,
          inspector_id: formData.inspector_id,
          inspection_date: formData.inspection_date,
          notes: formData.notes,
          status: 'pending'
        }])
        .select()
        .single();

      if (inspectionError) throw inspectionError;

      // Create notification
      const unit = housingUnits.find(u => u.id === formData.housing_unit_id);
      const inspector = inspectors.find(i => i.id === formData.inspector_id);

      await createNotification({
        title: 'New Inspection Scheduled',
        message: `Inspection scheduled for unit ${unit?.unit_number} with ${inspector?.name}`,
        type: 'task_created',
        link: '/workflows/quality'
      });

      setIsModalOpen(false);
      fetchQualityChecks();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass':
        return 'bg-green-100 text-green-800';
      case 'fail':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Quality Control</h2>
          <p className="mt-1 text-sm text-gray-500">
            Manage and track quality inspections across all units
          </p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          New Inspection
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="flex-shrink-0 ml-4 text-red-500 hover:text-red-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
        {checks.map((check) => (
          <div key={check.id} className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center space-x-3">
                  <h3 className="text-lg font-medium text-gray-900">
                    Unit {check.housing_unit.unit_number}
                  </h3>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    getStatusColor(check.result)
                  }`}>
                    {check.result}
                  </span>
                </div>
                <p className="mt-1 text-sm text-gray-500">
                  Inspector: {check.inspector.name}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => updateCheckStatus(check.id, 'pass')}
                  className="p-2 text-green-600 hover:text-green-700 rounded-lg hover:bg-green-50"
                  title="Mark as passed"
                >
                  <CheckCircle2 className="h-5 w-5" />
                </button>
                <button
                  onClick={() => updateCheckStatus(check.id, 'fail')}
                  className="p-2 text-red-600 hover:text-red-700 rounded-lg hover:bg-red-50"
                  title="Mark as failed"
                >
                  <AlertCircle className="h-5 w-5" />
                </button>
                <label className="p-2 text-blue-600 hover:text-blue-700 rounded-lg hover:bg-blue-50 cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        handleEvidenceUpload(file, check.id);
                      }
                    }}
                  />
                  <Camera className="h-5 w-5" />
                </label>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Inspection Date</span>
                <p className="mt-1 font-medium">
                  {format(new Date(check.inspection_date), 'MMM d, yyyy')}
                </p>
              </div>
              <div>
                <span className="text-gray-500">Category</span>
                <p className="mt-1 font-medium">
                  {check.category}
                </p>
              </div>
            </div>

            {check.findings.length > 0 && (
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Findings</h4>
                <ul className="space-y-1">
                  {check.findings.map((finding, index) => (
                    <li key={index} className="text-sm text-gray-600 flex items-center">
                      <span className="w-1.5 h-1.5 bg-gray-400 rounded-full mr-2" />
                      {finding}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {check.evidence.length > 0 && (
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Evidence</h4>
                <div className="grid grid-cols-4 gap-4">
                  {check.evidence.map((url, index) => (
                    <div key={index} className="relative group">
                      <img
                        src={url}
                        alt={`Evidence ${index + 1}`}
                        className="w-full h-24 object-cover rounded-lg"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity flex items-center justify-center opacity-0 group-hover:opacity-100">
                        <a
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2 bg-white text-gray-900 rounded-full hover:bg-gray-100"
                        >
                          <Maximize2 className="h-4 w-4" />
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {check.notes && (
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Notes</h4>
                <p className="text-sm text-gray-600">
                  {check.notes}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* New Inspection Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Schedule New Inspection</h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Housing Unit
                </label>
                <select
                  required
                  value={formData.housing_unit_id}
                  onChange={(e) => setFormData({ ...formData, housing_unit_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="">Select a unit</option>
                  {housingUnits.map((unit) => (
                    <option key={unit.id} value={unit.id}>
                      Unit {unit.unit_number} ({unit.status})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Inspection Template
                </label>
                <select
                  required
                  value={formData.template_id}
                  onChange={(e) => setFormData({ ...formData, template_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="">Select a template</option>
                  {templates.map((template) => (
                    <option key={template.id} value={template.id}>
                      {template.name} (v{template.version})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Inspector
                </label>
                <select
                  required
                  value={formData.inspector_id}
                  onChange={(e) => setFormData({ ...formData, inspector_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="">Select an inspector</option>
                  {inspectors.map((inspector) => (
                    <option key={inspector.id} value={inspector.id}>
                      {inspector.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Inspection Date & Time
                </label>
                <input
                  type="datetime-local"
                  required
                  value={formData.inspection_date}
                  onChange={(e) => setFormData({ ...formData, inspection_date: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Notes
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  placeholder="Add any additional notes or instructions..."
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Scheduling...
                    </>
                  ) : (
                    'Schedule Inspection'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default QualityControl;