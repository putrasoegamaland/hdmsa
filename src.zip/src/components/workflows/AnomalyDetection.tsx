import React, { useState, useEffect } from 'react';
import { Loader2, Download, Search, Filter } from 'lucide-react';
import { format } from 'date-fns';
import { fetchTasks, analyzeTaskDelays, type TaskAnomaly } from '../../lib/anomalyDetection';
import { downloadCSV } from '../../lib/exportUtils';
import { createNotification } from '../../lib/notifications';

const AnomalyDetection = () => {
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState<TaskAnomaly[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [exporting, setExporting] = useState(false);
  const [statusFilter, setStatusFilter] = useState<TaskAnomaly['anomaly_status'] | 'all'>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      const fetchedTasks = await fetchTasks();
      const analyzedTasks = analyzeTaskDelays(fetchedTasks);
      setTasks(analyzedTasks);
    } catch (error: any) {
      console.error('Error loading tasks:', error);
      await createNotification({
        title: 'Error',
        message: error.message || 'Failed to load tasks',
        type: 'task_updated',
        link: '/workflows'
      });
    } finally {
      setLoading(false);
    }
  };

  const uniqueProjects = ['all', ...new Set(tasks.map(task => task.project_name))];

  const exportReport = async () => {
    try {
      setExporting(true);
      const reportData = tasks.map(task => ({
        'Project Name': task.project_name,
        'Task Name': task.task_name,
        'Start Date': task.start_date ? format(new Date(task.start_date), 'yyyy-MM-dd') : 'Not Started',
        'Planned End Date': format(new Date(task.planned_end_date), 'yyyy-MM-dd'),
        'Actual End Date': task.actual_end_date ? format(new Date(task.actual_end_date), 'yyyy-MM-dd') : 'In Progress',
        'Days Difference': task.day_difference ?? 'N/A',
        'Status': task.status,
        'Anomaly Status': task.anomaly_status.charAt(0).toUpperCase() + task.anomaly_status.slice(1)
      }));

      const filename = `construction-tasks-report-${format(new Date(), 'yyyy-MM-dd')}`;
      downloadCSV(reportData, filename);

      await createNotification({
        title: 'Report Generated',
        message: 'Construction tasks report has been generated successfully',
        type: 'task_updated',
        link: '/workflows'
      });
    } catch (error: any) {
      console.error('Error exporting report:', error);
      await createNotification({
        title: 'Export Failed',
        message: error.message || 'Failed to export report',
        type: 'task_updated',
        link: '/workflows'
      });
    } finally {
      setExporting(false);
    }
  };

  const filteredTasks = tasks.filter(task => {
    const matchesSearch = 
      task.project_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.task_name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || task.anomaly_status === statusFilter;
    const matchesProject = projectFilter === 'all' || task.project_name === projectFilter;

    return matchesSearch && matchesStatus && matchesProject;
  });

  const getStatusColor = (status: TaskAnomaly['anomaly_status']) => {
    switch (status) {
      case 'delayed':
        return 'text-red-600 bg-red-50';
      case 'ahead':
        return 'text-green-600 bg-green-50';
      case 'on_time':
        return 'text-blue-600 bg-blue-50';
      case 'not_started':
        return 'text-gray-600 bg-gray-50';
      default:
        return 'text-yellow-600 bg-yellow-50';
    }
  };

  const getTaskStatusColor = (status: Task['status']) => {
    switch (status) {
      case 'completed':
        return 'text-green-600 bg-green-50';
      case 'in_progress':
        return 'text-blue-600 bg-blue-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:justify-between sm:items-center">
        <h2 className="text-lg font-semibold text-gray-900">
          Monitoring Keterlambatan Tugas
        </h2>
        <div className="flex flex-col space-y-2 sm:flex-row sm:space-y-0 sm:space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari project atau tugas..."
              className="w-full sm:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as TaskAnomaly['anomaly_status'] | 'all')}
            className="pl-3 pr-10 py-2 border border-gray-300 rounded-lg"
          >
            <option value="all">Semua Status</option>
            <option value="terlambat">Terlambat</option>
            <option value="tepat waktu">Tepat Waktu</option>
            <option value="lebih cepat">Lebih Cepat</option>
            <option value="in_progress">Sedang Berjalan</option>
            <option value="not_started">Belum Dimulai</option>
          </select>
          <select
            value={projectFilter}
            onChange={(e) => setProjectFilter(e.target.value)}
            className="pl-3 pr-10 py-2 border border-gray-300 rounded-lg"
          >
            {uniqueProjects.map(project => (
              <option key={project} value={project}>
                {project === 'all' ? 'All Projects' : project}
              </option>
            ))}
          </select>
          <button
            onClick={exportReport}
            disabled={exporting || tasks.length === 0}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            {exporting ? (
              <>
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                Exporting...
              </>
            ) : (
              <>
                <Download className="h-5 w-5 mr-2" />
                Export Report
              </>
            )}
          </button>
        </div>
      </div>

      {loading ? (
        <div className="h-40 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        </div>
      ) : filteredTasks.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama Project</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama Tugas</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status Tugas</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal Mulai</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal Rencana Selesai</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal Aktual Selesai</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Selisih Hari</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status Anomali</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTasks.map((task) => (
                <tr key={task.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{task.project_name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{task.task_name}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getTaskStatusColor(task.status)}`}>
                      {task.status === 'completed' ? 'Selesai' : task.status === 'in_progress' ? 'Sedang Berjalan' : 'Belum Dimulai'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {task.start_date ? format(new Date(task.start_date), 'yyyy-MM-dd') : 'Not Started'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {format(new Date(task.planned_end_date), 'yyyy-MM-dd')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {task.actual_end_date ? format(new Date(task.actual_end_date), 'yyyy-MM-dd') : 'In Progress'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {task.day_difference !== null ? `${task.day_difference} days` : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(task.anomaly_status)}`}>
                      {task.anomaly_status.charAt(0).toUpperCase() + task.anomaly_status.slice(1)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500">
          No tasks found
        </div>
      )}
    </div>
  );
};

export default AnomalyDetection;