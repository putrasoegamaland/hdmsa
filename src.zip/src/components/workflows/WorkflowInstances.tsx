import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Play, Pause, CheckCircle, AlertTriangle, Clock, Users, Loader2, X } from 'lucide-react';
import { createNotification } from '../../lib/notifications';
import { format } from 'date-fns';

interface WorkflowInstance {
  id: string;
  housing_unit_id: string;
  template_id: string;
  current_step_id: string;
  status: 'pending' | 'in-progress' | 'completed' | 'blocked';
  started_at: string;
  completed_at: string | null;
  step_progress: Record<string, any>;
  created_at: string;
  housing_unit: {
    unit_number: string;
    status: string;
  };
  template: {
    name: string;
    estimated_duration: string;
  };
  current_step?: {
    title: string;
    description: string;
    order_number: number;
  };
  completions: {
    id: string;
    step_id: string;
    status: string;
    completed_by?: {
      name: string;
    };
  }[];
}

interface Contractor {
  id: string;
  name: string;
  email: string;
  status: string;
}

const WorkflowInstances = () => {
  const [instances, setInstances] = useState<WorkflowInstance[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedInstance, setSelectedInstance] = useState<WorkflowInstance | null>(null);

  useEffect(() => {
    fetchInstances();
    fetchContractors();
  }, []);

  const fetchInstances = async () => {
    try {
      const { data, error } = await supabase
        .from('workflow_instances')
        .select(`
          *,
          housing_unit:housing_unit_id(unit_number, status),
          template:template_id(name, estimated_duration),
          current_step:current_step_id(title, description, order_number),
          completions:workflow_step_completions(
            id,
            step_id,
            status,
            completed_by:completed_by(name)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setInstances(data || []);
    } catch (error: any) {
      console.error('Error fetching instances:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchContractors = async () => {
    try {
      const { data, error } = await supabase
        .from('contractors')
        .select('*')
        .eq('status', 'Active')
        .order('name');

      if (error) throw error;
      setContractors(data || []);
    } catch (error) {
      console.error('Error fetching contractors:', error);
    }
  };

  const updateInstanceStatus = async (instance: WorkflowInstance, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('workflow_instances')
        .update({
          status: newStatus,
          ...(newStatus === 'in-progress' && !instance.started_at ? { started_at: new Date().toISOString() } : {}),
          ...(newStatus === 'completed' ? { completed_at: new Date().toISOString() } : {})
        })
        .eq('id', instance.id);

      if (error) throw error;

      await createNotification({
        title: 'Workflow Status Updated',
        message: `Workflow for unit ${instance.housing_unit.unit_number} is now ${newStatus}`,
        type: 'task_updated',
        link: '/workflows'
      });

      fetchInstances();
    } catch (error: any) {
      setError(error.message);
    }
  };

  const assignContractor = async (instanceId: string, stepId: string, contractorId: string) => {
    try {
      const { error } = await supabase
        .from('workflow_step_completions')
        .update({
          completed_by: contractorId,
          status: 'in-progress',
          started_at: new Date().toISOString()
        })
        .eq('instance_id', instanceId)
        .eq('step_id', stepId);

      if (error) throw error;

      const contractor = contractors.find(c => c.id === contractorId);
      await createNotification({
        title: 'Contractor Assigned',
        message: `${contractor?.name} has been assigned to the workflow step`,
        type: 'task_updated',
        link: '/workflows'
      });

      fetchInstances();
    } catch (error: any) {
      setError(error.message);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in-progress':
        return 'bg-blue-100 text-blue-800';
      case 'blocked':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Active Workflows</h2>
          <p className="mt-1 text-sm text-gray-500">
            Monitor and manage ongoing workflow instances
          </p>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="flex-shrink-0 ml-4 text-red-500 hover:text-red-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
        {instances.map((instance) => (
          <div key={instance.id} className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center space-x-3">
                  <h3 className="text-lg font-medium text-gray-900">
                    Unit {instance.housing_unit.unit_number}
                  </h3>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    getStatusColor(instance.status)
                  }`}>
                    {instance.status}
                  </span>
                </div>
                <p className="mt-1 text-sm text-gray-500">
                  {instance.template.name}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                {instance.status === 'pending' && (
                  <button
                    onClick={() => updateInstanceStatus(instance, 'in-progress')}
                    className="p-2 text-green-600 hover:text-green-700 rounded-lg hover:bg-green-50"
                  >
                    <Play className="h-5 w-5" />
                  </button>
                )}
                {instance.status === 'in-progress' && (
                  <>
                    <button
                      onClick={() => updateInstanceStatus(instance, 'completed')}
                      className="p-2 text-green-600 hover:text-green-700 rounded-lg hover:bg-green-50"
                    >
                      <CheckCircle className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => updateInstanceStatus(instance, 'blocked')}
                      className="p-2 text-red-600 hover:text-red-700 rounded-lg hover:bg-red-50"
                    >
                      <Pause className="h-5 w-5" />
                    </button>
                  </>
                )}
              </div>
            </div>

            

            <div className="mt-4 grid grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Started</span>
                <p className="mt-1 font-medium">
                  {instance.started_at
                    ? format(new Date(instance.started_at), 'MMM d, yyyy')
                    : 'Not started'}
                </p>
              </div>
              <div>
                <span className="text-gray-500">Duration</span>
                <p className="mt-1 font-medium">
                  {instance.template.estimated_duration}
                </p>
              </div>
              <div>
                <span className="text-gray-500">Current Step</span>
                <p className="mt-1 font-medium">
                  {instance.current_step?.title || 'Not started'}
                </p>
              </div>
            </div>

            {instance.completions && (
              <div className="mt-6">
                <h4 className="text-sm font-medium text-gray-900 mb-3">Step Progress</h4>
                <div className="space-y-3">
                  {instance.completions.map((completion) => (
                    <div
                      key={completion.id}
                      className="flex items-center justify-between bg-gray-50 p-3 rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <span className={`w-2 h-2 rounded-full ${
                          completion.status === 'completed' ? 'bg-green-500' :
                          completion.status === 'in-progress' ? 'bg-blue-500' :
                          completion.status === 'blocked' ? 'bg-red-500' :
                          'bg-gray-500'
                        }`} />
                        <span className="text-sm font-medium text-gray-900">
                          Step {completion.step_id}
                        </span>
                      </div>
                      <div className="flex items-center space-x-4">
                        {completion.completed_by ? (
                          <span className="text-sm text-gray-500">
                            Assigned to {completion.completed_by.name}
                          </span>
                        ) : (
                          <select
                            onChange={(e) => assignContractor(
                              instance.id,
                              completion.step_id,
                              e.target.value
                            )}
                            className="text-sm border border-gray-300 rounded-lg px-2 py-1"
                            defaultValue=""
                          >
                            <option value="">Assign contractor</option>
                            {contractors.map((contractor) => (
                              <option key={contractor.id} value={contractor.id}>
                                {contractor.name}
                              </option>
                            ))}
                          </select>
                        )}
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          getStatusColor(completion.status)
                        }`}>
                          {completion.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default WorkflowInstances;