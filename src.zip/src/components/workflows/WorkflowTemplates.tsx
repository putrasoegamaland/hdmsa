import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { Plus, Edit2, Copy, Trash2, ChevronDown, ChevronRight, AlertTriangle, Loader2, X } from 'lucide-react';
import { createNotification } from '../../lib/notifications';

interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  house_type_id: string;
  estimated_duration: string;
  total_steps: number;
  version: number;
  is_active: boolean;
  created_at: string;
  house_type?: {
    name: string;
  };
  steps?: WorkflowStep[];
}

interface WorkflowStep {
  id: string;
  title: string;
  description: string;
  order_number: number;
  duration: string;
  progress_weight: number;
  dependencies: string[];
  required_resources: any[];
  quality_checklists?: QualityChecklistItem[];
  safety_protocols?: SafetyProtocol[];
}

interface QualityChecklistItem {
  id: string;
  item: string;
  description: string;
  required: boolean;
  order_number: number;
}

interface SafetyProtocol {
  id: string;
  protocol: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  required_equipment: any[];
}

interface HouseType {
  id: string;
  name: string;
}

const WorkflowTemplates = () => {
  const [templates, setTemplates] = useState<WorkflowTemplate[]>([]);
  const [houseTypes, setHouseTypes] = useState<HouseType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [expandedTemplate, setExpandedTemplate] = useState<string | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<WorkflowTemplate | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    house_type_id: '',
    estimated_duration: '30 days',
    steps: [
      {
        title: '',
        description: '',
        duration: '1 day',
        progress_weight: 0,
        required_resources: []
      }
    ]
  });

  useEffect(() => {
    fetchTemplates();
    fetchHouseTypes();
  }, []);

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('workflow_templates')
        .select(`
          *,
          house_type:house_type_id(name),
          steps:workflow_steps(
            *,
            quality_checklists(*),
            safety_protocols(*)
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setTemplates(data || []);
    } catch (error: any) {
      console.error('Error fetching templates:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchHouseTypes = async () => {
    try {
      const { data, error } = await supabase
        .from('house_types')
        .select('*')
        .order('name');

      if (error) throw error;
      setHouseTypes(data || []);
    } catch (error) {
      console.error('Error fetching house types:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      // Calculate total progress weight
      const totalWeight = formData.steps.reduce((sum, step) => sum + step.progress_weight, 0);
      if (totalWeight !== 100) {
        throw new Error('Total progress weight must equal 100%');
      }

      // Create template
      const { data: template, error: templateError } = await supabase
        .from('workflow_templates')
        .insert([{
          name: formData.name,
          description: formData.description,
          house_type_id: formData.house_type_id,
          estimated_duration: formData.estimated_duration,
          total_steps: formData.steps.length
        }])
        .select()
        .single();

      if (templateError) throw templateError;

      // Create steps
      const stepsToCreate = formData.steps.map((step, index) => ({
        template_id: template.id,
        title: step.title,
        description: step.description,
        order_number: index,
        duration: step.duration,
        progress_weight: step.progress_weight,
        required_resources: step.required_resources
      }));

      const { error: stepsError } = await supabase
        .from('workflow_steps')
        .insert(stepsToCreate);

      if (stepsError) throw stepsError;

      await createNotification({
        title: 'Workflow Template Created',
        message: `Template "${formData.name}" has been created with ${formData.steps.length} steps`,
        type: 'task_created',
        link: '/workflows'
      });

      setIsModalOpen(false);
      fetchTemplates();
    } catch (error: any) {
      setError(error.message);
    }
  };

  const duplicateTemplate = async (template: WorkflowTemplate) => {
    try {
      const newName = `${template.name} (Copy)`;
      const { data: duplicateId, error } = await supabase.rpc(
        'duplicate_workflow_template',
        { template_id: template.id, new_name: newName }
      );

      if (error) throw error;

      await createNotification({
        title: 'Template Duplicated',
        message: `Template "${template.name}" has been duplicated`,
        type: 'task_created',
        link: '/workflows'
      });

      fetchTemplates();
    } catch (error: any) {
      setError(error.message);
    }
  };

  const deleteTemplate = async (templateId: string) => {
    try {
      const { error } = await supabase
        .from('workflow_templates')
        .delete()
        .eq('id', templateId);

      if (error) throw error;

      setTemplates(templates.filter(t => t.id !== templateId));
    } catch (error: any) {
      setError(error.message);
    }
  };

  const addStep = () => {
    setFormData({
      ...formData,
      steps: [
        ...formData.steps,
        {
          title: '',
          description: '',
          duration: '1 day',
          progress_weight: 0,
          required_resources: []
        }
      ]
    });
  };

  const updateStep = (index: number, field: string, value: any) => {
    setFormData({
      ...formData,
      steps: formData.steps.map((step, i) => 
        i === index ? { ...step, [field]: value } : step
      )
    });
  };

  const removeStep = (index: number) => {
    setFormData({
      ...formData,
      steps: formData.steps.filter((_, i) => i !== index)
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Workflow Templates</h2>
          <p className="mt-1 text-sm text-gray-500">
            Manage and create workflow templates for different house types
          </p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Create Template
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="flex-shrink-0 ml-4 text-red-500 hover:text-red-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
        {templates.map((template) => (
          <div key={template.id} className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center">
                  <button
                    onClick={() => setExpandedTemplate(
                      expandedTemplate === template.id ? null : template.id
                    )}
                    className="text-gray-500 hover:text-gray-700 mr-2"
                  >
                    {expandedTemplate === template.id ? (
                      <ChevronDown className="h-5 w-5" />
                    ) : (
                      <ChevronRight className="h-5 w-5" />
                    )}
                  </button>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">
                      {template.name}
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      {template.house_type?.name} • {template.total_steps} steps • 
                      Version {template.version}
                    </p>
                  </div>
                </div>
                {template.description && (
                  <p className="mt-2 text-sm text-gray-600">
                    {template.description}
                  </p>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setSelectedTemplate(template)}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <Edit2 className="h-5 w-5" />
                </button>
                <button
                  onClick={() => duplicateTemplate(template)}
                  className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                >
                  <Copy className="h-5 w-5" />
                </button>
                <button
                  onClick={() => deleteTemplate(template.id)}
                  className="p-2 text-red-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>

            {expandedTemplate === template.id && template.steps && (
              <div className="mt-4 pl-8">
                <div className="space-y-4">
                  {template.steps
                    .sort((a, b) => a.order_number - b.order_number)
                    .map((step) => (
                      <div key={step.id} className="border rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-medium text-gray-900">
                              {step.title}
                            </h4>
                            <p className="mt-1 text-sm text-gray-500">
                              {step.description}
                            </p>
                          </div>
                          <span className="text-sm font-medium text-blue-600">
                            {step.progress_weight}%
                          </span>
                        </div>

                        {(step.quality_checklists?.length ?? 0) > 0 && (
                          <div className="mt-3">
                            <h5 className="text-sm font-medium text-gray-700">
                              Quality Checklist
                            </h5>
                            <ul className="mt-2 space-y-1">
                              {step.quality_checklists?.map((item) => (
                                <li
                                  key={item.id}
                                  className="text-sm text-gray-600 flex items-center"
                                >
                                  <span className="w-2 h-2 bg-blue-600 rounded-full mr-2" />
                                  {item.item}
                                  {item.required && (
                                    <span className="ml-2 text-xs text-red-600">*</span>
                                  )}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {(step.safety_protocols?.length ?? 0) > 0 && (
                          <div className="mt-3">
                            <h5 className="text-sm font-medium text-gray-700">
                              Safety Protocols
                            </h5>
                            <ul className="mt-2 space-y-1">
                              {step.safety_protocols?.map((protocol) => (
                                <li
                                  key={protocol.id}
                                  className="text-sm text-gray-600 flex items-center"
                                >
                                  <span className={`w-2 h-2 rounded-full mr-2 ${
                                    protocol.severity === 'critical' ? 'bg-red-600' :
                                    protocol.severity === 'high' ? 'bg-orange-600' :
                                    protocol.severity === 'medium' ? 'bg-yellow-600' :
                                    'bg-green-600'
                                  }`} />
                                  {protocol.protocol}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Create Template Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Create Workflow Template</h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Template Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={3}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  House Type
                </label>
                <select
                  value={formData.house_type_id}
                  onChange={(e) => setFormData({ ...formData, house_type_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  required
                >
                  <option value="">Select a house type</option>
                  {houseTypes.map((type) => (
                    <option key={type.id} value={type.id}>
                      {type.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Estimated Duration
                </label>
                <input
                  type="text"
                  value={formData.estimated_duration}
                  onChange={(e) => setFormData({ ...formData, estimated_duration: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  placeholder="e.g., 30 days"
                  required
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium">Steps</h3>
                  <button
                    type="button"
                    onClick={addStep}
                    className="text-sm text-blue-600 hover:text-blue-700"
                  >
                    + Add Step
                  </button>
                </div>

                <div className="space-y-4">
                  {formData.steps.map((step, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-4">
                        <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-sm">
                          Step {index + 1}
                        </span>
                        {formData.steps.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeStep(index)}
                            className="text-red-400 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Title
                          </label>
                          <input
                            type="text"
                            value={step.title}
                            onChange={(e) => updateStep(index, 'title', e.target.value)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Description
                          </label>
                          <textarea
                            value={step.description}
                            onChange={(e) => updateStep(index, 'description', e.target.value)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2"
                            rows={2}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Duration
                            </label>
                            <input
                              type="text"
                              value={step.duration}
                              onChange={(e) => updateStep(index, 'duration', e.target.value)}
                              className="w-full border border-gray-300 rounded-lg px-3 py-2"
                              placeholder="e.g., 1 day"
                              required
                            />
                          </div>

                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                              Progress Weight (%)
                            </label>
                            <input
                              type="number"
                              min="0"
                              max="100"
                              value={step.progress_weight}
                              onChange={(e) => updateStep(index, 'progress_weight', parseInt(e.target.value))}
                              className="w-full border border-gray-300 rounded-lg px-3 py-2"
                              required
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Create Template
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkflowTemplates;