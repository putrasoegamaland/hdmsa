import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { X, Copy, Trash2, Share2, Calendar, Loader2, Link as LinkIcon, AlertCircle } from 'lucide-react';
import { addDays, format } from 'date-fns';

interface ShareLinkProps {
  unitId: string;
  unitNumber: string;
  onClose: () => void;
}

interface ShareLink {
  id: string;
  share_token: string;
  created_at: string;
  expires_at: string | null;
}

const ShareHousingUnit: React.FC<ShareLinkProps> = ({ unitId, unitNumber, onClose }) => {
  const [shareLinks, setShareLinks] = useState<ShareLink[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [expiration, setExpiration] = useState<number>(30); // Default 30 days
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    fetchShareLinks();
  }, [unitId]);

  const fetchShareLinks = async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");
      
      const { data, error } = await supabase
        .from('housing_unit_shares_0pr47')
        .select('*')
        .eq('housing_unit_id', unitId)
        .eq('created_by', user.email)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setShareLinks(data || []);
    } catch (error: any) {
      console.error("Error fetching share links:", error.message);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const createShareLink = async () => {
    try {
      setCreating(true);
      setError(null);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");
      
      // Generate a unique token
      const shareToken = `${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 10)}`;
      
      // Calculate expiration date if set
      const expiresAt = expiration > 0 
        ? addDays(new Date(), expiration).toISOString() 
        : null;
      
      const { data, error } = await supabase
        .from('housing_unit_shares_0pr47')
        .insert([{
          housing_unit_id: unitId,
          share_token: shareToken,
          created_by: user.email,
          expires_at: expiresAt
        }])
        .select();

      if (error) throw error;
      
      if (data && data.length > 0) {
        setShareLinks([...data, ...shareLinks]);
      }
    } catch (error: any) {
      console.error("Error creating share link:", error.message);
      setError(error.message);
    } finally {
      setCreating(false);
    }
  };

  const deleteShareLink = async (id: string) => {
    try {
      setDeleting(id);
      setError(null);
      
      const { error } = await supabase
        .from('housing_unit_shares_0pr47')
        .delete()
        .eq('id', id);

      if (error) throw error;
      
      setShareLinks(shareLinks.filter(link => link.id !== id));
    } catch (error: any) {
      console.error("Error deleting share link:", error.message);
      setError(error.message);
    } finally {
      setDeleting(null);
    }
  };

  const copyToClipboard = (token: string) => {
    const shareUrl = `${window.location.origin}/shared/housing-unit/${token}`;
    
    // Try the modern clipboard API first
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(shareUrl)
        .then(() => {
          setCopied(token);
          setTimeout(() => setCopied(null), 3000);
        })
        .catch((error) => {
          console.error("Error copying to clipboard:", error);
          // Fall back to the alternate method
          fallbackCopyToClipboard(shareUrl, token);
        });
    } else {
      // Use fallback for non-secure contexts
      fallbackCopyToClipboard(shareUrl, token);
    }
  };

  const fallbackCopyToClipboard = (text: string, token: string) => {
    try {
      // Create a temporary textarea element
      const textArea = document.createElement('textarea');
      textArea.value = text;
      
      // Make it non-editable to avoid focus and style issues
      textArea.setAttribute('readonly', '');
      textArea.style.position = 'absolute';
      textArea.style.left = '-9999px';
      
      document.body.appendChild(textArea);
      
      // Select the text and copy
      const selection = document.getSelection();
      const range = document.createRange();
      textArea.select();
      
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      
      if (successful) {
        setCopied(token);
        setTimeout(() => setCopied(null), 3000);
      } else {
        // If even the fallback fails, provide the URL to manually copy
        setError(`Copy this link manually: ${text}`);
      }
    } catch (err) {
      console.error('Fallback copy method failed:', err);
      setError(`Copy this link manually: ${text}`);
    }
  };

  const formatDate = (dateString: string | null): string => {
    if (!dateString) return 'Never expires';
    const date = new Date(dateString);
    return format(date, 'MMM dd, yyyy');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div 
        className="bg-white w-full max-w-lg rounded-lg shadow-lg" 
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="text-xl font-medium">Share Unit {unitNumber}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        {/* Content */}
        <div className="p-4 max-h-[60vh] overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md flex items-center">
              <AlertCircle className="h-5 w-5 mr-2" />
              <p>{error}</p>
            </div>
          )}
          
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              Create a shareable link that allows buyers to view construction progress 
              and updates for this housing unit without requiring them to log in.
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Link expiration
                </label>
                <div className="flex items-center space-x-2">
                  <select 
                    value={expiration}
                    onChange={(e) => setExpiration(parseInt(e.target.value))}
                    className="border border-gray-300 rounded-md px-3 py-2 flex-grow"
                  >
                    <option value={7}>7 days</option>
                    <option value={14}>14 days</option>
                    <option value={30}>30 days</option>
                    <option value={60}>60 days</option>
                    <option value={90}>90 days</option>
                    <option value={0}>Never expires</option>
                  </select>
                </div>
              </div>
              
              <button
                onClick={createShareLink}
                disabled={creating}
                className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                {creating ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Share2 className="h-4 w-4 mr-2" />
                    Create Share Link
                  </>
                )}
              </button>
            </div>
          </div>
          
          <h4 className="font-medium mb-2">Active Share Links</h4>
          {loading ? (
            <div className="flex justify-center p-4">
              <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
            </div>
          ) : shareLinks.length > 0 ? (
            <div className="space-y-3">
              {shareLinks.map(link => (
                <div 
                  key={link.id} 
                  className="border border-gray-200 rounded-md p-3 flex flex-col"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="h-3.5 w-3.5 mr-1" />
                      Created: {format(new Date(link.created_at), 'MMM dd, yyyy')}
                    </div>
                    <button
                      onClick={() => deleteShareLink(link.id)}
                      disabled={deleting === link.id}
                      className="text-red-500 hover:text-red-700 p-1"
                    >
                      {deleting === link.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                  
                  <div className="bg-gray-50 rounded-md p-2 mb-2 flex items-center text-sm">
                    <LinkIcon className="h-3.5 w-3.5 text-gray-500 mr-2" />
                    <div className="truncate flex-1">
                      {`${window.location.origin}/shared/housing-unit/${link.share_token}`}
                    </div>
                    <button 
                      onClick={() => copyToClipboard(link.share_token)}
                      className="ml-2 p-1 text-blue-600 hover:text-blue-800"
                    >
                      {copied === link.share_token ? (
                        <span className="text-green-600 text-xs">Copied!</span>
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </button>
                  </div>
                  
                  <div className="text-xs text-gray-500">
                    Expires: {formatDate(link.expires_at)}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6 text-gray-500">
              No share links created yet
            </div>
          )}
        </div>
        
        {/* Footer */}
        <div className="border-t p-4 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShareHousingUnit;