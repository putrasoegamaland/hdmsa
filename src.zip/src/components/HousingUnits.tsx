import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Search, Filter, Calendar, Clock, X, Loader2, AlertTriangle, Camera, Upload, Maximize2, Trash2, Settings as SettingsIcon, LayoutGrid as Grid, Table as TableIcon, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import HousingUnitDetails from './HousingUnitDetails';
import AddHousingUnit from './AddHousingUnit';
import EditHousingUnit from './EditHousingUnit';
import HousingUnitSettings from './housing-units/Settings';
import { createNotification } from '../lib/notifications';

interface HousingUnit {
  id: string;
  project_id: string;
  unit_number: string;
  status: string;
  target_handover_date: string;
  actual_handover_date: string | null;
  payment_phase: string;
  buyer_phase: string;
  created_at: string;
  updated_at: string;
  project: {
    title: string;
  };
  tasks: {
    id: string;
    status: string;
  }[];
  progress: {
    progress_percentage: number;
    report_date: string;
  }[];
  housing_unit_contractors?: {
    contractor_id: string;
    contractor: {
      id: string;
      name: string;
      email: string;
    };
  }[];
}

interface Contractor {
  id: string;
  name: string;
  email: string;
  status: string;
}

interface DeleteConfirmation {
  unitId: string;
  unitNumber: string;
  isDeleting: boolean;
}

type ViewMode = 'grid' | 'table';
type ActiveTab = 'overview' | 'settings';

const HousingUnits = () => {
  const [units, setUnits] = useState<HousingUnit[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [editingUnit, setEditingUnit] = useState<HousingUnit | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'delayed' | 'completed'>('all');
  const [activeTab, setActiveTab] = useState<ActiveTab>('overview');
  const [deleteConfirmation, setDeleteConfirmation] = useState<DeleteConfirmation | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchHousingUnits();
    fetchContractors();
  }, []);

  async function fetchContractors() {
    try {
      const { data, error } = await supabase
        .from('contractors')
        .select('*')
        .order('name');

      if (error) throw error;
      setContractors(data || []);
    } catch (error) {
      console.error('Error fetching contractors:', error);
    }
  }

  async function fetchHousingUnits() {
    try {
      const { data, error } = await supabase
        .from('housing_units')
        .select(`
          *,
          project:project_id(title),
          tasks(id, status),
          progress:housing_unit_progress(
            progress_percentage,
            report_date
          ),
          housing_unit_contractors(
            contractor_id,
            contractor:contractor_id(
              id,
              name,
              email
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUnits(data || []);
    } catch (error) {
      console.error('Error fetching housing units:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleDeleteUnit = async () => {
    if (!deleteConfirmation) return;

    try {
      setDeleteConfirmation({ ...deleteConfirmation, isDeleting: true });

      const { data: photos, error: photosError } = await supabase
        .from('housing_unit_photos')
        .select('photo_url')
        .eq('housing_unit_id', deleteConfirmation.unitId);

      if (photosError) throw photosError;

      if (photos?.length) {
        for (const photo of photos) {
          const urlParts = photo.photo_url.split('/');
          const filePath = `${deleteConfirmation.unitId}/${urlParts[urlParts.length - 1]}`;
          
          await supabase.storage
            .from('housing-unit-photos')
            .remove([filePath]);
        }
      }

      const { error: deleteError } = await supabase
        .from('housing_units')
        .delete()
        .eq('id', deleteConfirmation.unitId);

      if (deleteError) throw deleteError;

      await createNotification({
        title: 'Housing Unit Deleted',
        message: `Housing unit ${deleteConfirmation.unitNumber} has been deleted`,
        type: 'unit_added',
        link: '/housing-units'
      });

      setUnits(units.filter(unit => unit.id !== deleteConfirmation.unitId));
      setDeleteConfirmation(null);
    } catch (error: any) {
      setError(error.message);
    }
  };

  const calculateProgress = (unit: HousingUnit) => {
    if (unit.progress && unit.progress.length > 0) {
      const latestProgress = unit.progress.sort((a, b) => 
        new Date(b.report_date).getTime() - new Date(a.report_date).getTime()
      )[0];
      return latestProgress.progress_percentage;
    }

    if (unit.tasks && unit.tasks.length > 0) {
      const completedTasks = unit.tasks.filter(task => task.status === 'completed').length;
      return Math.round((completedTasks / unit.tasks.length) * 100);
    }

    return 0;
  };

  const getStatusColor = (status: string, progress: number) => {
    if (status === 'completed') return 'bg-green-100 text-green-800';
    if (status === 'delayed') return 'bg-red-100 text-red-800';
    if (progress >= 75) return 'bg-blue-100 text-blue-800';
    return 'bg-yellow-100 text-yellow-800';
  };

  const getBuyerPhaseColor = (phase: string) => {
    switch (phase) {
      case 'Hold':
        return 'bg-purple-100 text-purple-800';
      case 'Progress Bank':
        return 'bg-orange-100 text-orange-800';
      case 'Cash':
        return 'bg-teal-100 text-teal-800';
      case 'Ready Stock':
        return 'bg-lime-100 text-lime-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredUnits = units
    .filter(unit => {
      if (filter === 'delayed') return unit.status === 'delayed';
      if (filter === 'completed') return unit.status === 'completed';
      return true;
    })
    .filter(unit => {
      const searchLower = searchTerm.toLowerCase();
      return (
        unit.unit_number.toLowerCase().includes(searchLower) ||
        unit.project?.title.toLowerCase().includes(searchLower) ||
        unit.status.toLowerCase().includes(searchLower) ||
        unit.housing_unit_contractors?.[0]?.contractor?.name?.toLowerCase().includes(searchLower) ||
        unit.payment_phase?.toLowerCase().includes(searchLower)
      );
    });

  const renderGridView = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {filteredUnits.map((unit) => {
        const progress = calculateProgress(unit);
        const statusColor = getStatusColor(unit.status, progress);
        const contractor = unit.housing_unit_contractors?.[0]?.contractor;
        
        return (
          <div
            key={unit.id}
            className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow"
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Unit {unit.unit_number}
                  </h3>
                  <p className="text-sm text-gray-500">{unit.project?.title}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColor}`}>
                    {unit.status}
                  </span>
                  <button
                    onClick={() => setDeleteConfirmation({
                      unitId: unit.id,
                      unitNumber: unit.unit_number,
                      isDeleting: false
                    })}
                    className="p-1 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-700">Progress</span>
                    <span className="text-sm text-gray-500">{progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    ></div>
                  </div>
                </div>

                {contractor && (
                  <div className="flex items-center text-sm text-gray-600">
                    <div>
                      <p className="font-medium">{contractor.name}</p>
                      <p className="text-gray-500 text-xs">{contractor.email}</p>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>Due: {format(new Date(unit.target_handover_date), 'MMM dd, yyyy')}</span>
                  </div>
                  <div className="flex items-center text-gray-500">
                    {unit.tasks?.length > 0 ? (
                      <>
                        <CheckCircle2 className="h-4 w-4 mr-1" />
                        <span>
                          {unit.tasks.filter(t => t.status === 'completed').length}/{unit.tasks.length} Tasks
                        </span>
                      </>
                    ) : (
                      <span>No tasks</span>
                    )}
                  </div>
                </div>

                {unit.status === 'delayed' && (
                  <div className="flex items-center mt-2 text-sm text-red-600">
                    <AlertTriangle className="h-4 w-4 mr-1" />
                    <span>Delayed</span>
                  </div>
                )}

                <div className="flex items-center space-x-2 mt-2">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getBuyerPhaseColor(unit.buyer_phase)}`}>
                    {unit.buyer_phase}
                  </span>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 bg-gray-50 border-t flex justify-between items-center">
              <button
                onClick={() => setSelectedUnitId(unit.id)}
                className="text-sm font-medium text-blue-600 hover:text-blue-800"
              >
                View Details
              </button>
              <button
                onClick={() => setEditingUnit(unit)}
                className="text-sm font-medium text-gray-600 hover:text-gray-800"
              >
                Edit Status
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );

  const renderTableView = () => (
    <div className="bg-white shadow-sm rounded-lg overflow-hidden">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Unit Number
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Project
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Contractor
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Progress
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Tasks
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Due Date
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Buyer Phase
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {filteredUnits.map((unit) => {
            const progress = calculateProgress(unit);
            const statusColor = getStatusColor(unit.status, progress);
            const completedTasks = unit.tasks?.filter(t => t.status === 'completed').length || 0;
            const totalTasks = unit.tasks?.length || 0;
            const contractor = unit.housing_unit_contractors?.[0]?.contractor;

            return (
              <tr key={unit.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">
                    {unit.unit_number}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">
                    {unit.project?.title}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {contractor ? (
                    <div>
                      <div className="text-sm font-medium text-gray-900">
                        {contractor.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {contractor.email}
                      </div>
                    </div>
                  ) : (
                    <span className="text-sm text-gray-500">Unassigned</span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColor}`}>
                    {unit.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="w-32">
                    <div className="flex items-center">
                      <div className="flex-1 h-2 bg-gray-200 rounded-full">
                        <div
                          className="h-2 bg-blue-600 rounded-full"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                      <span className="ml-2 text-sm text-gray-500">{progress}%</span>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {completedTasks}/{totalTasks}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(new Date(unit.target_handover_date), 'MMM dd, yyyy')}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${getBuyerPhaseColor(unit.buyer_phase)}`}>
                    {unit.buyer_phase}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <div className="flex items-center justify-end space-x-3">
                    <button
                      onClick={() => setSelectedUnitId(unit.id)}
                      className="text-blue-600 hover:text-blue-900"
                    >
                      View Details
                    </button>
                    <button
                      onClick={() => setEditingUnit(unit)}
                      className="text-gray-600 hover:text-gray-900"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => setDeleteConfirmation({
                        unitId: unit.id,
                        unitNumber: unit.unit_number,
                        isDeleting: false
                      })}
                      className="text-red-400 hover:text-red-600"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'settings':
        return <HousingUnitSettings />;
      default:
        return (
          <>
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by unit number, project, status, or contractor..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div className="flex items-center space-x-2 overflow-x-auto">
                <button
                  onClick={() => setFilter('all')}
                  className={`px-4 py-2 rounded-lg whitespace-nowrap ${
                    filter === 'all'
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilter('delayed')}
                  className={`px-4 py-2 rounded-lg whitespace-nowrap ${
                    filter === 'delayed'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Delayed
                </button>
                <button
                  onClick={() => setFilter('completed')}
                  className={`px-4 py-2 rounded-lg whitespace-nowrap ${
                    filter === 'completed'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Completed
                </button>
                <div className="border-l border-gray-200 h-8 mx-2" />
                <div className="flex items-center space-x-1 bg-gray-100 rounded-lg p-1">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={`p-2 rounded-md transition-colors ${
                      viewMode === 'grid'
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <Grid className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => setViewMode('table')}
                    className={`p-2 rounded-md transition-colors ${
                      viewMode === 'table'
                        ? 'bg-white text-blue-600 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    <TableIcon className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>

            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : viewMode === 'grid' ? (
              renderGridView()
            ) : (
              renderTableView()
            )}
          </>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Housing Units</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage and track progress of all housing units
          </p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add New Unit
        </button>
      </div>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'overview'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
              activeTab === 'settings'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <SettingsIcon className="h-4 w-4 mr-2" />
            Settings
          </button>
        </nav>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="flex-shrink-0 ml-4 text-red-500 hover:text-red-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      {renderContent()}

      {/* Add Housing Unit Modal */}
      {isAddModalOpen && (
        <AddHousingUnit
          onClose={() => setIsAddModalOpen(false)}
          onSuccess={fetchHousingUnits}
        />
      )}

      {/* Unit Details Modal */}
      {selectedUnitId && (
        <HousingUnitDetails
          unitId={selectedUnitId}
          onClose={() => setSelectedUnitId(null)}
        />
      )}

      {/* Edit Unit Modal */}
      {editingUnit && (
        <EditHousingUnit
          unit={editingUnit}
          contractors={contractors}
          onClose={() => setEditingUnit(null)}
          onSuccess={fetchHousingUnits}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-gray-900">
                  Delete Housing Unit
                </h3>
                <div className="mt-2">
                  <p className="text-sm text-gray-500">
                    Are you sure you want to delete Unit {deleteConfirmation.unitNumber}? This action cannot be undone and will also delete all associated tasks, progress reports, and photos.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setDeleteConfirmation(null)}
                disabled={deleteConfirmation.isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteUnit}
                disabled={deleteConfirmation.isDeleting}
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                {deleteConfirmation.isDeleting ? (
                  <>
                    <Loader2 className="animate-spin h-4 w-4 mr-2" />
                    Deleting...
                  </>
                ) : (
                  'Delete Unit'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HousingUnits;