import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Building2, Users, Clock, AlertTriangle, TrendingUp, ArrowUpRight, ArrowDownRight, MoreVertical, CheckCircle2, ChevronDown } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { createNotification } from '../lib/notifications';
import Weather from './Weather';

interface DashboardStats {
  totalUnits: number;
  activeContractors: number;
  inProgress: number;
  delayed: number;
  completionRate: number;
  totalValue: number;
  projectStats: {
    planning: number;
    'in-progress': number;
    'on-hold': number;
    completed: number;
  };
}

interface ProjectProgress {
  projectId: string;
  projectTitle: string;
  status: string;
  totalUnits: number;
  completedUnits: number;
  delayedUnits: number;
  progress: number;
  units: {
    id: string;
    unit_number: string;
    progress: number;
    tasks: {
      total: number;
      completed: number;
      delayed: number;
    };
  }[];
}

const Dashboard = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalUnits: 0,
    activeContractors: 0,
    inProgress: 0,
    delayed: 0,
    completionRate: 0,
    totalValue: 0,
    projectStats: {
      planning: 0,
      'in-progress': 0,
      'on-hold': 0,
      completed: 0
    }
  });
  const [projectProgress, setProjectProgress] = useState<ProjectProgress[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusMenuOpen, setStatusMenuOpen] = useState<string | null>(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  async function fetchDashboardData() {
    try {
      setLoading(true);
      
      // Fetch all projects to get status distribution
      const { data: allProjects } = await supabase
        .from('projects')
        .select('status');

      const projectStats = {
        planning: 0,
        'in-progress': 0,
        'on-hold': 0,
        completed: 0
      };

      allProjects?.forEach(project => {
        projectStats[project.status as keyof typeof projectStats]++;
      });
      
      // Fetch projects with their housing units and progress reports
      const { data: projects } = await supabase
        .from('projects')
        .select(`
          id,
          title,
          status,
          housing_units (
            id,
            unit_number,
            status,
            tasks (
              id,
              status,
              due_date
            ),
            progress:housing_unit_progress (
              progress_percentage,
              report_date
            )
          )
        `)
        .limit(5)
        .order('created_at', { ascending: false });

      if (!projects) return;

      // Calculate progress for each project
      const progressData = projects.map(project => {
        const units = project.housing_units || [];
        
        // Calculate unit-specific progress and tasks
        const unitsWithProgress = units.map(unit => {
          const tasks = unit.tasks || [];
          const latestProgress = unit.progress?.sort((a, b) => 
            new Date(b.report_date).getTime() - new Date(a.report_date).getTime()
          )[0];

          return {
            id: unit.id,
            unit_number: unit.unit_number,
            progress: latestProgress?.progress_percentage || 0,
            tasks: {
              total: tasks.length,
              completed: tasks.filter(t => t.status === 'completed').length,
              delayed: tasks.filter(t => {
                const dueDate = new Date(t.due_date);
                return t.status !== 'completed' && dueDate < new Date();
              }).length
            }
          };
        });

        const totalUnits = units.length;
        const completedUnits = units.filter(u => u.status === 'completed').length;
        const delayedUnits = units.filter(u => u.status === 'delayed').length;

        return {
          projectId: project.id,
          projectTitle: project.title,
          status: project.status,
          totalUnits,
          completedUnits,
          delayedUnits,
          progress: totalUnits ? (completedUnits / totalUnits) * 100 : 0,
          units: unitsWithProgress
        };
      });

      setProjectProgress(progressData);

      // Calculate overall stats
      const totalUnits = progressData.reduce((sum, p) => sum + p.totalUnits, 0);
      const completedUnits = progressData.reduce((sum, p) => sum + p.completedUnits, 0);
      const delayedUnits = progressData.reduce((sum, p) => sum + p.delayedUnits, 0);
      const completionRate = totalUnits ? (completedUnits / totalUnits) * 100 : 0;

      setStats({
        totalUnits,
        activeContractors: 25,
        inProgress: totalUnits - completedUnits,
        delayed: delayedUnits,
        completionRate,
        totalValue: 17643410,
        projectStats
      });

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  }

  const updateProjectStatus = async (projectId: string, newStatus: string) => {
    try {
      const { data, error } = await supabase
        .from('projects')
        .update({ status: newStatus })
        .eq('id', projectId)
        .select('title')
        .single();

      if (error) throw error;

      // Update local state
      setProjectProgress(projectProgress.map(project =>
        project.projectId === projectId ? { ...project, status: newStatus } : project
      ));

      // Update project stats
      setStats(prev => {
        const oldStatus = projectProgress.find(p => p.projectId === projectId)?.status;
        if (oldStatus) {
          return {
            ...prev,
            projectStats: {
              ...prev.projectStats,
              [oldStatus]: prev.projectStats[oldStatus as keyof typeof prev.projectStats] - 1,
              [newStatus]: prev.projectStats[newStatus as keyof typeof prev.projectStats] + 1
            }
          };
        }
        return prev;
      });

      // Create notification
      await createNotification({
        title: 'Project Status Updated',
        message: `Project "${data.title}" status has been updated to ${newStatus}`,
        type: 'project_updated',
        link: '/projects'
      });

      setStatusMenuOpen(null);
    } catch (error) {
      console.error('Error updating project status:', error);
    }
  };

  const COLORS = {
    planning: '#A78BFA', // Purple
    'in-progress': '#3B82F6', // Blue
    'on-hold': '#F59E0B', // Yellow
    completed: '#34D399' // Green
  };

  const statusColors = {
    'planning': 'bg-purple-100 text-purple-800',
    'in-progress': 'bg-blue-100 text-blue-800',
    'on-hold': 'bg-yellow-100 text-yellow-800',
    'completed': 'bg-green-100 text-green-800'
  };

  const statusOptions = ['planning', 'in-progress', 'on-hold', 'completed'];

  const projectStatusData = Object.entries(stats.projectStats).map(([status, count]) => ({
    name: status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' '),
    value: count
  }));

  return (
    <div className="space-y-6">
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <>
          {/* Portfolio Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Weather Widget */}
            <div className="col-span-2">
              <Weather />
            </div>

            {/* Project Status Distribution */}
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-semibold mb-4">Project Status</h3>
              <div className="h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={projectStatusData}
                      cx="50%"
                      cy="50%"
                      innerRadius={40}
                      outerRadius={80}
                      paddingAngle={2}
                    >
                      {projectStatusData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={COLORS[entry.name.toLowerCase().replace(' ', '-') as keyof typeof COLORS]} 
                        />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-center text-sm">
                {projectStatusData.map((status) => (
                  <div key={status.name}>
                    <div className="font-medium" style={{ color: COLORS[status.name.toLowerCase().replace(' ', '-') as keyof typeof COLORS] }}>
                      {status.value}
                    </div>
                    <div className="text-gray-500">{status.name}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Project Progress Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {projectProgress.map((project) => (
              <div key={project.projectId} className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{project.projectTitle}</h3>
                    <p className="text-sm text-gray-500">
                      {project.completedUnits} of {project.totalUnits} units completed
                    </p>
                  </div>
                  <div className="relative">
                    <button
                      onClick={() => setStatusMenuOpen(statusMenuOpen === project.projectId ? null : project.projectId)}
                      className={`flex items-center px-3 py-1 rounded-full text-sm ${statusColors[project.status as keyof typeof statusColors]}`}
                    >
                      {project.status}
                      <ChevronDown className="h-4 w-4 ml-1" />
                    </button>
                    
                    {statusMenuOpen === project.projectId && (
                      <div className="absolute right-0 mt-2 w-40 bg-white rounded-lg shadow-lg border border-gray-100 py-1 z-10">
                        {statusOptions.map((status) => (
                          <button
                            key={status}
                            onClick={() => updateProjectStatus(project.projectId, status)}
                            className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${
                              status === project.status ? 'text-blue-600 font-medium' : 'text-gray-700'
                            }`}
                          >
                            {status}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  {/* Unit Progress */}
                  <div className="mt-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">Unit Progress</span>
                      <span className="text-sm text-gray-500">{project.completedUnits}/{project.totalUnits}</span>
                    </div>
                    <div className="space-y-1">
                      {project.units.slice(0, 3).map(unit => (
                        <div key={unit.id} className="flex items-center text-sm">
                          <span className="w-16 text-gray-600">Unit {unit.unit_number}</span>
                          <div className="flex-1 mx-2">
                            <div className="h-1.5 bg-gray-200 rounded-full">
                              <div
                                className="h-1.5 bg-blue-600 rounded-full"
                                style={{ width: `${unit.progress}%` }}
                              />
                            </div>
                          </div>
                          <span className="w-8 text-right text-gray-500">{unit.progress}%</span>
                        </div>
                      ))}
                      {project.units.length > 3 && (
                        <div className="text-xs text-gray-500 text-center mt-1">
                          +{project.units.length - 3} more units
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Milestones */}
                  <div className="pt-2">
                    <div className="flex items-center text-sm">
                      <CheckCircle2 className="h-4 w-4 text-emerald-500 mr-2" />
                      <span>Foundation completed</span>
                    </div>
                    <div className="flex items-center text-sm mt-1">
                      <Clock className="h-4 w-4 text-blue-500 mr-2" />
                      <span>Framing in progress</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default Dashboard;