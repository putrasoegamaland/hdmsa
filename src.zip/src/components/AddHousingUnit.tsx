import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { X, Plus, Trash2, AlertTriangle, Loader2, GripVertical } from 'lucide-react';
import { createNotification } from '../lib/notifications';

interface HouseType {
  id: string;
  name: string;
  description: string;
  default_tasks: DefaultTask[];
}

interface DefaultTask {
  id: string;
  title: string;
  description: string;
  order_number: number;
  progress_percentage: number;
}

interface CustomTask {
  title: string;
  description: string;
  order_number: number;
  progress_percentage: number;
}

interface Project {
  id: string;
  title: string;
}

interface Contractor {
  id: string;
  name: string;
  email: string;
  status: string;
}

interface Props {
  onClose: () => void;
  onSuccess: () => void;
}

const AddHousingUnit: React.FC<Props> = ({ onClose, onSuccess }) => {
  const [houseTypes, setHouseTypes] = useState<HouseType[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedType, setSelectedType] = useState<'existing' | 'custom'>('existing');
  const [selectedHouseType, setSelectedHouseType] = useState<string>('');
  const [selectedContractor, setSelectedContractor] = useState<string>('');
  const [customTasks, setCustomTasks] = useState<CustomTask[]>([{
    title: '',
    description: '',
    order_number: 0,
    progress_percentage: 0
  }]);
  const [formData, setFormData] = useState({
    unit_number: '',
    status: 'on-schedule',
    target_handover_date: '',
    payment_phase: 'none',
    buyer_phase: 'none',
    bank_name: '',
    project_id: ''
  });
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const buyerPhases = [
    'none',
    'Hold',
    'Progress Bank',
    'Cash',
    'Ready Stock'
  ];

  useEffect(() => {
    Promise.all([fetchHouseTypes(), fetchProjects(), fetchContractors()]).then(() => {
      setLoading(false);
    });
  }, []);

  async function fetchHouseTypes() {
    try {
      const { data, error } = await supabase
        .from('house_types')
        .select(`
          *,
          default_tasks (
            id,
            title,
            description,
            order_number,
            progress_percentage
          )
        `)
        .order('name');

      if (error) throw error;
      setHouseTypes(data || []);
    } catch (error) {
      console.error('Error fetching house types:', error);
    }
  }

  async function fetchProjects() {
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('id, title, status')
        .order('title');

      if (error) throw error;
      setProjects(data || []);
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  }

  async function fetchContractors() {
    try {
      const { data, error } = await supabase
        .from('contractors')
        .select('*')
        .eq('status', 'Active')
        .order('name');

      if (error) throw error;
      setContractors(data || []);
    } catch (error) {
      console.error('Error fetching contractors:', error);
    }
  }

  const addCustomTask = () => {
    setCustomTasks([
      ...customTasks,
      {
        title: '',
        description: '',
        order_number: customTasks.length,
        progress_percentage: 0
      }
    ]);
  };

  const removeCustomTask = (index: number) => {
    setCustomTasks(customTasks.filter((_, i) => i !== index));
  };

  const updateCustomTask = (index: number, field: keyof CustomTask, value: string | number) => {
    setCustomTasks(customTasks.map((task, i) => 
      i === index ? { ...task, [field]: value } : task
    ));
  };

  const calculateTotalPercentage = () => {
    return customTasks.reduce((sum, task) => sum + task.progress_percentage, 0);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      if (!formData.project_id) {
        throw new Error('Please select a project');
      }

      // Validate total percentage for custom tasks
      if (selectedType === 'custom') {
        const totalPercentage = calculateTotalPercentage();
        if (totalPercentage !== 100) {
          throw new Error('Total progress percentage must equal 100%');
        }
      }

      // Create housing unit
      const { data: housingUnit, error: unitError } = await supabase
        .from('housing_units')
        .insert([{
          ...formData,
          house_type_id: selectedType === 'existing' ? selectedHouseType : null
        }])
        .select()
        .single();

      if (unitError) throw unitError;

      // Create contractor assignment if a contractor is selected
      if (selectedContractor) {
        const { error: contractorError } = await supabase
          .from('housing_unit_contractors')
          .insert([{
            housing_unit_id: housingUnit.id,
            contractor_id: selectedContractor
          }]);

        if (contractorError) throw contractorError;
      }

      // Create tasks based on selection
      const tasksToCreate = selectedType === 'existing'
        ? houseTypes
            .find(type => type.id === selectedHouseType)
            ?.default_tasks.map(task => ({
              title: task.title,
              description: task.description,
              status: 'todo',
              due_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
              housing_unit_id: housingUnit.id
            })) || []
        : customTasks.map(task => ({
            title: task.title,
            description: task.description,
            status: 'todo',
            due_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
            housing_unit_id: housingUnit.id
          }));

      if (tasksToCreate.length > 0) {
        const { error: tasksError } = await supabase
          .from('tasks')
          .insert(tasksToCreate);

        if (tasksError) throw tasksError;
      }

      // Create notification
      const contractor = contractors.find(c => c.id === selectedContractor);
      await createNotification({
        title: 'New Housing Unit Added',
        message: `Unit ${formData.unit_number} has been added${contractor ? ` and assigned to ${contractor.name}` : ''} with ${tasksToCreate.length} tasks`,
        type: 'unit_added',
        link: '/housing-units'
      });

      onSuccess();
      onClose();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Add New Housing Unit</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Project
            </label>
            <select
              required
              value={formData.project_id}
              onChange={(e) => setFormData({ ...formData, project_id: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              <option value="">Select a project</option>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.title}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Unit Number
            </label>
            <input
              required
              type="text"
              value={formData.unit_number}
              onChange={(e) => setFormData({ ...formData, unit_number: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
              placeholder="e.g., A-101"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              required
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              <option value="on-schedule">On Schedule</option>
              <option value="delayed">Delayed</option>
              <option value="completed">Completed</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Target Handover Date
            </label>
            <input
              required
              type="date"
              value={formData.target_handover_date}
              onChange={(e) => setFormData({ ...formData, target_handover_date: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Payment Phase
            </label>
            <select
              required
              value={formData.payment_phase}
              onChange={(e) => setFormData({ ...formData, payment_phase: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              <option value="phase-1">Phase 1</option>
              <option value="phase-2">Phase 2</option>
              <option value="phase-3">Phase 3</option>
              <option value="retensi">Retensi</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Buyer Phase
            </label>
            <select
              required
              value={formData.buyer_phase}
              onChange={(e) => setFormData({ ...formData, buyer_phase: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              {buyerPhases.map((phase) => (
                <option key={phase} value={phase}>
                  {phase}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Bank Name
            </label>
            <select
              value={formData.bank_name}
              onChange={(e) => setFormData({ ...formData, bank_name: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              <option value="">Select a bank</option>
              <option value="BCA">BCA</option>
              <option value="Mandiri">Mandiri</option>
              <option value="BNI">BNI</option>
              <option value="BTN">BTN</option>
              <option value="BRI">BRI</option>
              <option value="CIMB Niaga">CIMB Niaga</option>
              <option value="Permata">Permata</option>
              <option value="Danamon">Danamon</option>
              <option value="Panin">Panin</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Contractor
            </label>
            <select
              value={selectedContractor}
              onChange={(e) => setSelectedContractor(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              <option value="">Select a contractor</option>
              {contractors.map((contractor) => (
                <option key={contractor.id} value={contractor.id}>
                  {contractor.name} ({contractor.email})
                </option>
              ))}
            </select>
          </div>

          <div className="border-t pt-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium">Tasks Setup</h3>
              <div className="flex items-center space-x-4">
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio text-blue-600"
                    name="taskType"
                    checked={selectedType === 'existing'}
                    onChange={() => setSelectedType('existing')}
                  />
                  <span className="ml-2">Use House Type</span>
                </label>
                <label className="inline-flex items-center">
                  <input
                    type="radio"
                    className="form-radio text-blue-600"
                    name="taskType"
                    checked={selectedType === 'custom'}
                    onChange={() => setSelectedType('custom')}
                  />
                  <span className="ml-2">Custom Tasks</span>
                </label>
              </div>
            </div>

            {selectedType === 'existing' ? (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  House Type
                </label>
                <select
                  required
                  value={selectedHouseType}
                  onChange={(e) => setSelectedHouseType(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="">Select a house type</option>
                  {houseTypes.map((type) => (
                    <option key={type.id} value={type.id}>
                      {type.name}
                    </option>
                  ))}
                </select>

                {selectedHouseType && (
                  <div className="mt-4 space-y-2">
                    <h4 className="text-sm font-medium text-gray-700">Default Tasks:</h4>
                    {houseTypes
                      .find(type => type.id === selectedHouseType)
                      ?.default_tasks.map((task) => (
                        <div key={task.id} className="bg-gray-50 p-3 rounded-lg">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">{task.title}</span>
                            <span className="text-sm text-blue-600">{task.progress_percentage}%</span>
                          </div>
                          {task.description && (
                            <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                          )}
                        </div>
                      ))}
                  </div>
                )}
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-center mb-2">
                  <div className="text-sm">
                    Total: <span className={`font-medium ${calculateTotalPercentage() === 100 ? 'text-green-600' : 'text-red-600'}`}>
                      {calculateTotalPercentage()}%
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={addCustomTask}
                    className="text-sm text-blue-600 hover:text-blue-700"
                  >
                    + Add Task
                  </button>
                </div>

                {calculateTotalPercentage() !== 100 && (
                  <div className="mb-4 flex items-center text-sm text-yellow-700 bg-yellow-50 p-3 rounded-lg">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Total progress percentage must equal 100%
                  </div>
                )}

                <div className="space-y-4">
                  {customTasks.map((task, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <input
                          required
                          type="text"
                          value={task.title}
                          onChange={(e) => updateCustomTask(index, 'title', e.target.value)}
                          className="flex-1 border border-gray-300 rounded-lg px-3 py-2"
                          placeholder="Task title"
                        />
                        <div className="flex items-center ml-4">
                          <input
                            required
                            type="number"
                            min="0"
                            max="100"
                            value={task.progress_percentage}
                            onChange={(e) => updateCustomTask(index, 'progress_percentage', parseInt(e.target.value) || 0)}
                            className="w-20 border border-gray-300 rounded-lg px-3 py-2"
                            placeholder="%"
                          />
                          {customTasks.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeCustomTask(index)}
                              className="ml-2 p-2 text-red-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          )}
                        </div>
                      </div>
                      <textarea
                        value={task.description}
                        onChange={(e) => updateCustomTask(index, 'description', e.target.value)}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2"
                        placeholder="Task description (optional)"
                        rows={2}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || (selectedType === 'custom' && calculateTotalPercentage() !== 100)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Adding...
                </>
              ) : (
                'Add Unit'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddHousingUnit;