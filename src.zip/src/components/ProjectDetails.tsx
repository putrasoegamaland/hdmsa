import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { X, Loader2, AlertTriangle, Building2, Calendar, MapPin, Clock, TrendingUp, Users } from 'lucide-react';
import { format } from 'date-fns';

interface Project {
  id: string;
  title: string;
  description: string;
  status: string;
  address: string;
  start_date: string;
  target_completion_date: string;
  estimated_completion_date: string;
  handover_date: string | null;
  payment_total: number;
  payment_received: number;
  payment_percentage: number;
  total_units: number;
  delayed_units: number;
  created_at: string;
  updated_at: string;
  housing_units: {
    id: string;
    unit_number: string;
    status: string;
    payment_phase: string;
    contractor: {
      name: string;
    };
  }[];
}

interface Props {
  projectId: string | null;
  onClose: () => void;
}

const ProjectDetails: React.FC<Props> = ({ projectId, onClose }) => {
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProject = async () => {
      try {
        setLoading(true);
        const { data, error } = await supabase
          .from('projects')
          .select(`
            *,
            housing_units (
              id,
              unit_number,
              status,
              payment_phase,
              contractor:housing_unit_contractors (
                contractor:contractor_id (
                  name
                )
              )
            )
          `)
          .eq('id', projectId)
          .single();

        if (error) throw error;
        setProject(data);
      } catch (error: any) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    if (projectId) {
      fetchProject();
    }
  }, [projectId]);

  if (!projectId) return null;

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-6 w-full max-w-md">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Project Details</h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            {error}
          </div>
        </div>
      </div>
    );
  }

  if (!project) return null;

  const statusColors = {
    'planning': 'bg-purple-100 text-purple-800',
    'in-progress': 'bg-blue-100 text-blue-800',
    'on-hold': 'bg-yellow-100 text-yellow-800',
    'completed': 'bg-green-100 text-green-800'
  };

  const unitStatusColors = {
    'completed': 'bg-green-100 text-green-800',
    'delayed': 'bg-red-100 text-red-800',
    'on-schedule': 'bg-blue-100 text-blue-800'
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <div className="flex justify-between items-start p-6 border-b border-gray-200">
          <div>
            <div className="flex items-center space-x-3">
              <h2 className="text-2xl font-semibold text-gray-900">{project.title}</h2>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColors[project.status as keyof typeof statusColors]}`}>
                {project.status}
              </span>
            </div>
            <p className="mt-1 text-gray-500">{project.description}</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-6">
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h3 className="text-lg font-medium mb-4">Project Information</h3>
                <div className="space-y-3">
                  <div className="flex items-center text-sm">
                    <MapPin className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-gray-600">{project.address}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-gray-600">
                      Started: {format(new Date(project.start_date), 'MMM dd, yyyy')}
                    </span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Clock className="h-5 w-5 text-gray-400 mr-2" />
                    <span className="text-gray-600">
                      Target Completion: {format(new Date(project.target_completion_date), 'MMM dd, yyyy')}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h3 className="text-lg font-medium mb-4">Financial Overview</h3>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm text-gray-500">Payment Progress</span>
                      <span className="text-sm font-medium">{project.payment_percentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{ width: `${project.payment_percentage}%` }}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Total Value</p>
                      <p className="text-lg font-medium">
                        {new Intl.NumberFormat('id-ID', {
                          style: 'currency',
                          currency: 'IDR',
                          minimumFractionDigits: 0
                        }).format(project.payment_total * project.total_units)}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Received</p>
                      <p className="text-lg font-medium">
                        {new Intl.NumberFormat('id-ID', {
                          style: 'currency',
                          currency: 'IDR',
                          minimumFractionDigits: 0
                        }).format(project.payment_received)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-medium">Housing Units</h3>
                  <div className="flex items-center space-x-2">
                    <Building2 className="h-5 w-5 text-gray-400" />
                    <span className="text-sm font-medium">{project.total_units} Units</span>
                  </div>
                </div>
                <div className="space-y-3">
                  {project.housing_units?.map((unit) => (
                    <div
                      key={unit.id}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                    >
                      <div>
                        <p className="font-medium text-gray-900">Unit {unit.unit_number}</p>
                        {unit.contractor?.[0]?.contractor?.name && (
                          <p className="text-sm text-gray-500">
                            {unit.contractor[0].contractor.name}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          unitStatusColors[unit.status as keyof typeof unitStatusColors]
                        }`}>
                          {unit.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h3 className="text-lg font-medium mb-4">Project Metrics</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center text-green-600 mb-1">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span className="text-sm font-medium">Completion Rate</span>
                    </div>
                    <p className="text-2xl font-semibold text-green-700">
                      {Math.round((project.housing_units?.filter(u => u.status === 'completed').length || 0) / project.total_units * 100)}%
                    </p>
                  </div>
                  <div className="p-3 bg-red-50 rounded-lg">
                    <div className="flex items-center text-red-600 mb-1">
                      <Clock className="h-4 w-4 mr-1" />
                      <span className="text-sm font-medium">Delayed Units</span>
                    </div>
                    <p className="text-2xl font-semibold text-red-700">
                      {project.delayed_units}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDetails;