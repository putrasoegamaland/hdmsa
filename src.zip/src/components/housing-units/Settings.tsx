import React, { useState } from 'react';
import { Save, AlertTriangle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { createNotification } from '../../lib/notifications';

const Settings = () => {
  const [settings, setSettings] = useState({
    defaultDueDays: 7,
    autoAssignContractors: false,
    notifyOnDelays: true,
    notifyOnCompletion: true,
    progressThreshold: 80,
    delayThreshold: 3
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);

      // In a real application, this would save to the database
      // For now, we'll just simulate a save
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Create a notification
      await createNotification({
        title: 'Settings Updated',
        message: 'Housing unit settings have been updated successfully',
        type: 'unit_added',
        link: '/housing-units/settings'
      });

    } catch (error: any) {
      setError(error.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <h2 className="text-lg font-medium">Housing Unit Settings</h2>
          <p className="mt-1 text-sm text-gray-500">
            Configure default settings for housing units
          </p>
        </div>

        {error && (
          <div className="p-4 bg-red-50 border-l-4 border-red-400">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-5 w-5 text-red-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        <div className="p-6 space-y-6">
          {/* Task Settings */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-4">Task Settings</h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Default Due Days
                </label>
                <input
                  type="number"
                  value={settings.defaultDueDays}
                  onChange={(e) => setSettings({ ...settings, defaultDueDays: parseInt(e.target.value) })}
                  className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Default number of days for task completion
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Progress Threshold for Completion
                </label>
                <input
                  type="number"
                  value={settings.progressThreshold}
                  onChange={(e) => setSettings({ ...settings, progressThreshold: parseInt(e.target.value) })}
                  className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Percentage threshold for marking tasks as complete
                </p>
              </div>
            </div>
          </div>

          {/* Contractor Settings */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-4">Contractor Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={settings.autoAssignContractors}
                  onChange={(e) => setSettings({ ...settings, autoAssignContractors: e.target.checked })}
                  className="h-4 w-4 text-blue-600 rounded border-gray-300"
                />
                <label className="ml-2 block text-sm text-gray-700">
                  Automatically assign contractors based on availability
                </label>
              </div>
            </div>
          </div>

          {/* Notification Settings */}
          <div>
            <h3 className="text-sm font-medium text-gray-900 mb-4">Notification Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={settings.notifyOnDelays}
                  onChange={(e) => setSettings({ ...settings, notifyOnDelays: e.target.checked })}
                  className="h-4 w-4 text-blue-600 rounded border-gray-300"
                />
                <label className="ml-2 block text-sm text-gray-700">
                  Notify when units are delayed
                </label>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  checked={settings.notifyOnCompletion}
                  onChange={(e) => setSettings({ ...settings, notifyOnCompletion: e.target.checked })}
                  className="h-4 w-4 text-blue-600 rounded border-gray-300"
                />
                <label className="ml-2 block text-sm text-gray-700">
                  Notify when units are completed
                </label>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Delay Threshold (days)
                </label>
                <input
                  type="number"
                  value={settings.delayThreshold}
                  onChange={(e) => setSettings({ ...settings, delayThreshold: parseInt(e.target.value) })}
                  className="mt-1 block w-full border border-gray-300 rounded-lg px-3 py-2"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Number of days before marking a unit as delayed
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          >
            <Save className="h-5 w-5 mr-2" />
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;