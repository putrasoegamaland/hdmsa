import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { format, subMonths } from 'date-fns';
import { calculateProgress } from '../../lib/progressCalculation';

interface Props {
  units: any[];
}

const Analytics: React.FC<Props> = ({ units }) => {
  // Calculate status distribution
  const statusData = units.reduce((acc: any, unit: any) => {
    acc[unit.status] = (acc[unit.status] || 0) + 1;
    return acc;
  }, {});

  const statusChartData = Object.entries(statusData).map(([status, count]) => ({
    name: status,
    value: count
  }));

  // Calculate progress distribution
  const progressData = units.reduce((acc: any[], unit: any) => {
    const progressRange = Math.floor(calculateProgress(unit) / 20) * 20;
    const existingRange = acc.find(item => item.range === progressRange);
    if (existingRange) {
      existingRange.count++;
    } else {
      acc.push({ range: progressRange, count: 1 });
    }
    return acc;
  }, []).sort((a, b) => a.range - b.range);

  // Generate monthly completion trend
  const monthlyData = Array.from({ length: 6 }, (_, i) => {
    const month = subMonths(new Date(), i);
    return {
      month: format(month, 'MMM yyyy'),
      completed: units.filter(unit => 
        unit.status === 'completed' && 
        new Date(unit.updated_at).getMonth() === month.getMonth()
      ).length
    };
  }).reverse();

  const COLORS = ['#3B82F6', '#34D399', '#F87171', '#A78BFA'];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Status Distribution */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-lg font-medium mb-4">Status Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {statusChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {statusChartData.map((entry, index) => (
              <div key={entry.name} className="flex items-center">
                <div
                  className="w-3 h-3 rounded-full mr-2"
                  style={{ backgroundColor: COLORS[index % COLORS.length] }}
                />
                <span className="text-sm text-gray-600">
                  {entry.name}: {entry.value}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Progress Distribution */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-lg font-medium mb-4">Progress Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={progressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="range"
                  tickFormatter={(value) => `${value}%`}
                />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Monthly Completion Trend */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h3 className="text-lg font-medium mb-4">Monthly Completions</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="completed"
                  stroke="#3B82F6"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h4 className="text-sm font-medium text-gray-500">Total Units</h4>
          <p className="mt-2 text-3xl font-semibold">{units.length}</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h4 className="text-sm font-medium text-gray-500">Completed</h4>
          <p className="mt-2 text-3xl font-semibold text-green-600">
            {units.filter(unit => unit.status === 'completed').length}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h4 className="text-sm font-medium text-gray-500">In Progress</h4>
          <p className="mt-2 text-3xl font-semibold text-blue-600">
            {units.filter(unit => unit.status === 'in-progress').length}
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <h4 className="text-sm font-medium text-gray-500">Delayed</h4>
          <p className="mt-2 text-3xl font-semibold text-red-600">
            {units.filter(unit => unit.status === 'delayed').length}
          </p>
        </div>
      </div>
    </div>
  );
};

export default Analytics;