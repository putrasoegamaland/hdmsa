import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Building2, Users, Clipboard, BarChart3, FolderKanban, Settings, LogOut, LayoutTemplate, GitBranch, X } from 'lucide-react';
import { useAuth } from './AuthProvider';

interface Props {
  onClose: () => void;
}

const Sidebar: React.FC<Props> = ({ onClose }) => {
  const { signOut } = useAuth();
  
  const navigation = [
    { name: 'Overview', icon: Home, path: '/' },
    { name: 'Housing Units', icon: Building2, path: '/housing-units' },
    { name: 'House Types', icon: LayoutTemplate, path: '/house-types' },
    { name: 'Workflows', icon: GitBranch, path: '/workflows' },
    { name: 'Contractors', icon: Users, path: '/contractors' },
    { name: 'Tasks', icon: Clipboard, path: '/tasks' },
    { name: 'Reports', icon: BarChart3, path: '/reports' },
    { name: 'Projects', icon: FolderKanban, path: '/projects' },
  ];

  return (
    <div className="h-full flex flex-col bg-white">
      <div className="h-[72px] flex items-center justify-between px-8 border-b border-gray-100">
        <div className="flex items-center">
          <Building2 className="h-8 w-8 text-blue-600" />
          <span className="ml-3 text-xl font-semibold text-gray-900">HDMS</span>
        </div>
        <button
          onClick={onClose}
          className="p-2 text-gray-500 hover:text-gray-700 lg:hidden"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
      
      <div className="flex-1 flex flex-col min-h-0">
        <nav className="flex-1 px-4 py-6 overflow-y-auto">
          <div className="space-y-1">
            {navigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.path}
                onClick={onClose}
                className={({ isActive }) => `
                  flex items-center px-4 py-3 text-sm font-medium rounded-xl transition-colors
                  ${isActive 
                    ? 'bg-blue-50 text-blue-600' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }
                `}
              >
                <item.icon className="h-5 w-5 mr-3" />
                {item.name}
              </NavLink>
            ))}
          </div>
        </nav>

        <div className="p-4 border-t border-gray-100">
          <div className="space-y-1">
            <button className="w-full flex items-center px-4 py-3 text-sm font-medium text-gray-600 rounded-xl hover:bg-gray-50 hover:text-gray-900 transition-colors">
              <Settings className="h-5 w-5 mr-3" />
              Settings
            </button>
            <button 
              onClick={signOut}
              className="w-full flex items-center px-4 py-3 text-sm font-medium text-gray-600 rounded-xl hover:bg-gray-50 hover:text-gray-900 transition-colors"
            >
              <LogOut className="h-5 w-5 mr-3" />
              Log out
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;