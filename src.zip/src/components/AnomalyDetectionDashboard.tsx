import React, { useEffect, useState } from 'react';
import { AlertTriangle, Clock, Users, TrendingUp, Loader2 } from 'lucide-react';
import { detectAnomalies } from '../lib/anomalyDetection';
import { format } from 'date-fns';

interface AnomalyReport {
  type: 'task_duration' | 'contractor_performance' | 'progress_deviation';
  severity: 'low' | 'medium' | 'high';
  message: string;
  details: any;
}

const AnomalyDetectionDashboard = () => {
  const [anomalies, setAnomalies] = useState<AnomalyReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAnomalies();
    // Refresh anomalies every 30 minutes
    const interval = setInterval(fetchAnomalies, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchAnomalies = async () => {
    try {
      setLoading(true);
      const data = await detectAnomalies();
      setAnomalies(data);
      setLastUpdate(new Date());
      setError(null);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getAnomalyIcon = (type: string) => {
    switch (type) {
      case 'task_duration':
        return <Clock className="h-5 w-5" />;
      case 'contractor_performance':
        return <Users className="h-5 w-5" />;
      case 'progress_deviation':
        return <TrendingUp className="h-5 w-5" />;
      default:
        return <AlertTriangle className="h-5 w-5" />;
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
          <span className="text-gray-600">Analyzing data...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-gray-900">Anomaly Detection</h2>
          <p className="text-sm text-gray-500">
            Last updated: {format(lastUpdate, 'MMM d, yyyy HH:mm')}
          </p>
        </div>
        <button
          onClick={fetchAnomalies}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          Refresh Analysis
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 text-red-700 rounded-lg flex items-center">
          <AlertTriangle className="h-5 w-5 mr-2" />
          {error}
        </div>
      )}

      {anomalies.length === 0 ? (
        <div className="bg-green-50 p-4 rounded-lg">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-5 w-5 text-green-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-green-800">
                No anomalies detected
              </h3>
              <div className="mt-2 text-sm text-green-700">
                <p>All metrics are within expected ranges.</p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {anomalies.map((anomaly, index) => (
            <div
              key={index}
              className={`bg-white rounded-lg shadow-sm overflow-hidden border-l-4 ${
                anomaly.severity === 'high'
                  ? 'border-red-500'
                  : anomaly.severity === 'medium'
                  ? 'border-yellow-500'
                  : 'border-blue-500'
              }`}
            >
              <div className="p-6">
                <div className="flex items-start">
                  <div className={`p-2 rounded-lg ${getSeverityColor(anomaly.severity)}`}>
                    {getAnomalyIcon(anomaly.type)}
                  </div>
                  <div className="ml-4 flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium text-gray-900">
                        {anomaly.message}
                      </h3>
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${getSeverityColor(
                          anomaly.severity
                        )}`}
                      >
                        {anomaly.severity.toUpperCase()}
                      </span>
                    </div>
                    <div className="mt-2 text-sm text-gray-600">
                      {anomaly.type === 'task_duration' && (
                        <p>
                          Task duration: {anomaly.details.duration.toFixed(1)} days
                          <br />
                          Average duration: {anomaly.details.avgDuration.toFixed(1)} days
                          <br />
                          Deviation score: {anomaly.details.zScore.toFixed(2)}
                        </p>
                      )}
                      {anomaly.type === 'contractor_performance' && (
                        <p>
                          Completion rate: {(anomaly.details.completionRate * 100).toFixed(1)}%
                          <br />
                          Average rate: {(anomaly.details.avgRate * 100).toFixed(1)}%
                          <br />
                          Deviation score: {anomaly.details.zScore.toFixed(2)}
                        </p>
                      )}
                      {anomaly.type === 'progress_deviation' && (
                        <p>
                          Progress rate: {anomaly.details.progressRate.toFixed(1)}% per day
                          <br />
                          Median rate: {anomaly.details.median.toFixed(1)}% per day
                          <br />
                          IQR: {anomaly.details.iqr.toFixed(2)}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AnomalyDetectionDashboard;