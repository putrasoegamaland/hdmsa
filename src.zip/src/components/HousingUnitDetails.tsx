import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { X, Upload, Plus, Loader2, Trash2, Maximize2, ChevronLeft, CheckCircle2, Clock, Activity, Share2 } from 'lucide-react';
import { format, isValid, formatDistanceToNow } from 'date-fns';
import { createNotification } from '../lib/notifications';
import ComplaintsSection from './ComplaintsSection';
import ShareHousingUnit from './ShareHousingUnit';

interface HousingUnitDetails {
  id: string;
  unit_number: string;
  status: string;
  target_handover_date: string;
  actual_handover_date: string | null;
  payment_phase: string;
  bank_name: string | null;
  contractor: {
    contractor: {
      name: string;
      email: string;
    };
  }[];
}

interface ProgressReport {
  id: string;
  progress_percentage: number;
  report_date: string;
  description: string;
  tasks?: {
    completed: string[];
    total: string[];
  };
}

interface Photo {
  id: string;
  photo_url: string;
  caption: string;
  created_at: string;
}

interface Task {
  id: string;
  title: string;
  status: string;
  created_at: string;
  updated_at: string;
}

interface Complaint {
  id: string;
  description: string;
  status: 'open' | 'in-progress' | 'resolved';
  created_at: string;
  updated_at: string;
}

interface Changelog {
  id: string;
  change_type: string;
  change_details: Record<string, {from: string, to: string}>;
  user_email: string;
  created_at: string;
}

interface Props {
  unitId: string;
  onClose: () => void;
}

const HousingUnitDetails: React.FC<Props> = ({ unitId, onClose }) => {
  const [unit, setUnit] = useState<HousingUnitDetails | null>(null);
  const [progressReports, setProgressReports] = useState<ProgressReport[]>([]);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [changelogs, setChangelogs] = useState<Changelog[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [previewPhoto, setPreviewPhoto] = useState<Photo | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const [photoUpload, setPhotoUpload] = useState<{
    file: File | null;
    caption: string;
    isUploading: boolean;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'progress' | 'photos' | 'complaints' | 'changelog' | 'share'>('details');

  useEffect(() => {
    fetchUnitDetails();
  }, [unitId]);

  const formatDate = (dateString: string | null | undefined): string => {
    if (!dateString) return 'Not set';
    const date = new Date(dateString);
    return isValid(date) ? format(date, 'MMM dd, yyyy') : 'Invalid date';
  };

  async function fetchUnitDetails() {
    try {
      // Fetch unit details with contractor information
      const { data: unitData, error: unitError } = await supabase
        .from('housing_units')
        .select(`
          *,
          contractor:housing_unit_contractors(
            contractor:contractor_id(
              name,
              email
            )
          )
        `)
        .eq('id', unitId)
        .single();

      if (unitError) throw unitError;
      setUnit(unitData);

      // Fetch tasks
      const { data: taskData, error: taskError } = await supabase
        .from('tasks')
        .select('*')
        .eq('housing_unit_id', unitId)
        .order('created_at', { ascending: true });

      if (taskError) throw taskError;
      setTasks(taskData || []);

      // Fetch progress reports with task information
      const { data: progressData, error: progressError } = await supabase
        .from('housing_unit_progress')
        .select('*')
        .eq('housing_unit_id', unitId)
        .order('report_date', { ascending: false });

      if (progressError) throw progressError;

      // Enhance progress reports with task information
      const enhancedProgressReports = progressData?.map(report => {
        const reportDate = new Date(report.report_date);
        const completedTasks = taskData?.filter(task => 
          task.status === 'completed' && new Date(task.updated_at) <= reportDate
        ) || [];
        
        return {
          ...report,
          tasks: {
            completed: completedTasks.map(task => task.title),
            total: taskData?.map(task => task.title) || []
          }
        };
      }) || [];

      setProgressReports(enhancedProgressReports);

      // Fetch photos
      const { data: photoData, error: photoError } = await supabase
        .from('housing_unit_photos_0pr47')
        .select('*')
        .eq('housing_unit_id', unitId)
        .order('created_at', { ascending: false });

      if (photoError) throw photoError;
      setPhotos(photoData || []);

      // Fetch complaints
      const { data: complaintData, error: complaintError } = await supabase
        .from('complaints')
        .select('*')
        .eq('housing_unit_id', unitId)
        .order('created_at', { ascending: false });

      if (complaintError) throw complaintError;
      setComplaints(complaintData || []);
      
      // Fetch changelogs
      const { data: changelogData, error: changelogError } = await supabase
        .from('housing_unit_changelogs_0pr47')
        .select('*')
        .eq('housing_unit_id', unitId)
        .order('created_at', { ascending: false })
        .limit(5);
        
      if (changelogError) throw changelogError;
      setChangelogs(changelogData || []);
    } catch (error) {
      console.error('Error fetching unit details:', error);
    } finally {
      setLoading(false);
    }
  }

  const handlePhotoUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoUpload?.file) {
      setError('No photo selected');
      return;
    }

    try {
      setError(null);
      setUploading(true);
      setPhotoUpload(prev => prev ? { ...prev, isUploading: true } : null);

      // Get current user's email
      const { data: { session } } = await supabase.auth.getSession();
      const userEmail = session?.user?.email;
      
      if (!userEmail) {
        throw new Error('You must be logged in to upload photos');
      }

      // Create a unique file name
      const fileExt = photoUpload.file.name.split('.').pop() || 'jpg';
      const timestamp = Date.now();
      const randomValue = Math.floor(Math.random() * 10000);
      const fileName = `photo_${timestamp}_${randomValue}.${fileExt}`;
      const filePath = `${unitId}/${fileName}`;

      console.log('Uploading photo to housing-unit-photos bucket, path:', filePath);

      // Upload to Supabase storage
      const { error: uploadError } = await supabase.storage
        .from('housing-unit-photos')
        .upload(filePath, photoUpload.file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('Storage upload error:', uploadError);
        throw new Error(`Failed to upload photo: ${uploadError.message}`);
      }

      // Get the public URL for the uploaded file
      const { data: { publicUrl } } = supabase.storage
        .from('housing-unit-photos')
        .getPublicUrl(filePath);

      console.log('Public URL generated:', publicUrl);

      // Save photo reference in the database
      const { data: photo, error: dbError } = await supabase
        .from('housing_unit_photos_0pr47')
        .insert([{
          housing_unit_id: unitId,
          photo_url: publicUrl,
          caption: photoUpload.caption || '',
          user_email: userEmail
        }])
        .select()
        .single();

      if (dbError) {
        console.error('Database error when saving photo reference:', dbError);
        throw new Error(`Database error: ${dbError.message}`);
      }

      // Create a notification
      if (unit) {
        await createNotification({
          title: 'New Photo Added',
          message: `A new photo has been added for unit ${unit.unit_number}`,
          type: 'photo_added',
          link: '/housing-units'
        });
      }

      // Add the new photo to the local state
      setPhotos([photo, ...photos]);

      // Clear photo upload form
      setPhotoUpload(null);
      
      // Show success message
      setError('Photo uploaded successfully');
      
      // Clear success message after 2 seconds
      setTimeout(() => {
        setError(current => current === 'Photo uploaded successfully' ? null : current);
      }, 2000);
    } catch (error: any) {
      console.error('Error in handlePhotoUpload:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setError(`Failed to upload photo: ${errorMessage}`);
    } finally {
      setUploading(false);
    }
  };

  // Helper function to reliably extract storage path from photo URL
  const extractStoragePathFromUrl = (url: string, unitId: string): string => {
    try {
      console.log('Extracting path from URL:', url);
      
      // Clean the URL if it's encoded
      const decodedUrl = decodeURIComponent(url);
      console.log('Decoded URL:', decodedUrl);
      
      // Method 1: Direct extraction using URL parsing
      try {
        const urlObj = new URL(decodedUrl);
        const pathname = urlObj.pathname;
        
        // Look for the 'housing-unit-photos/' path segment
        const regex = /\/storage\/v1\/object\/public\/housing-unit-photos\/(.*)/;
        const match = pathname.match(regex);
        
        if (match && match[1]) {
          console.log('Method 1: Extracted path using regex:', match[1]);
          return match[1]; // This is the most reliable method when it works
        }
      } catch (e) {
        console.warn('URL parsing failed:', e);
      }
      
      // Method 2: String index-based extraction
      const photosIndex = decodedUrl.indexOf('housing-unit-photos/');
      if (photosIndex !== -1) {
        const path = decodedUrl.substring(photosIndex + 'housing-unit-photos/'.length);
        console.log('Method 2: Extracted path using string index:', path);
        return path;
      }
      
      // Method 3: Filename extraction with unitId prefix
      const urlParts = decodedUrl.split('/');
      const filename = urlParts[urlParts.length - 1];
      if (filename && filename.includes('.')) { // Basic check that it looks like a filename
        const constructedPath = `${unitId}/${filename}`;
        console.log('Method 3: Constructed path from unitId/filename:', constructedPath);
        return constructedPath;
      }
      
      // If all methods fail, return empty string
      console.error('Could not extract storage path from URL:', url);
      return '';
    } catch (error) {
      console.error('Error in extractStoragePathFromUrl:', error);
      return ''; // Return empty if all extraction methods fail
    }
  };

  const deletePhoto = async (unitId: string, photo: Photo) => {
    try {
      setError(null); // Clear any previous errors
      setDeleting(photo.id); // Set deleting state for UI feedback
      
      // Show loading/progress feedback
      const loadingMessage = `Deleting photo...`;
      setError(loadingMessage);
      
      console.log('Starting photo deletion for:', photo);
      console.log('Photo URL:', photo.photo_url);
      
      // Safety check - ensure we have a photo ID
      if (!photo.id) {
        console.error('No photo ID provided for deletion');
        throw new Error('Photo ID missing - cannot delete');
      }

      // First extract the storage path consistently
      const filePath = extractStoragePathFromUrl(photo.photo_url, unitId);
      
      // Safety check - don't proceed if we couldn't determine a file path
      if (!filePath) {
        console.error('Could not determine storage file path from URL:', photo.photo_url);
        throw new Error('Failed to determine file path for deletion');
      }
      
      console.log('Using storage path for deletion:', filePath);
      
      // Begin transaction - first, delete from database
      console.log('Deleting from database, photo ID:', photo.id);
      const { error: dbError } = await supabase
        .from('housing_unit_photos_0pr47')
        .delete()
        .eq('id', photo.id);

      if (dbError) {
        console.error('Error deleting from database:', dbError);
        throw new Error(`Database error: ${dbError.message}`);
      }
      console.log('Database deletion successful');
      
      // Then, delete from Supabase storage
      console.log('Deleting from storage, path:', filePath);
      const { data: storageData, error: storageError } = await supabase.storage
        .from('housing-unit-photos')
        .remove([filePath]);

      console.log('Storage deletion response:', storageData, 'Error:', storageError);
        
      if (storageError) {
        console.error('Error deleting from storage:', storageError);
        // Create a more useful error message but don't throw since DB is already updated
        console.warn('Storage deletion failed but continuing since DB record is removed');
        console.warn('Storage error details:', storageError.message);
      } else {
        console.log('Storage deletion successful');
      }
      
      // Update local state immediately for better UX
      setPhotos(photos.filter(p => p.id !== photo.id));

      // Close the preview if the deleted photo was being previewed
      if (previewPhoto?.id === photo.id) {
        setPreviewPhoto(null);
      }
      
      // Show success message
      const successMessage = 'Photo deleted successfully';
      setError(successMessage); // Brief success message
      
      // Clear success message after 2 seconds
      setTimeout(() => {
        setError(current => current === successMessage ? null : current);
      }, 2000);
      
      // Fetch fresh details to ensure UI is in sync with backend
      await fetchUnitDetails();
    } catch (error: unknown) {
      console.error('Error in deletePhoto function:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setError(`Failed to delete photo: ${errorMessage}`);
      
      // Clear error message after 5 seconds
      setTimeout(() => {
        setError(current => current === `Failed to delete photo: ${errorMessage}` ? null : current);
      }, 5000);
    } finally {
      setDeleting(null); // Clear deleting state
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'details':
        return (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium mb-2">Unit Information</h3>
              <div className="space-y-2">
                <p><span className="font-medium">Status:</span> {unit?.status}</p>
                <p><span className="font-medium">Payment Phase:</span> {unit?.payment_phase}</p>
                <p><span className="font-medium">Bank Name:</span> {unit?.bank_name || 'Not specified'}</p>
                <p><span className="font-medium">Target Handover:</span> {formatDate(unit?.target_handover_date)}</p>
                {unit?.actual_handover_date && (
                  <p><span className="font-medium">Actual Handover:</span> {formatDate(unit.actual_handover_date)}</p>
                )}
                {unit?.contractor && unit.contractor.length > 0 && (
                  <>
                    <p><span className="font-medium">Assigned Contractor:</span> {unit.contractor[0].contractor.name}</p>
                    <p><span className="font-medium">Contractor Email:</span> {unit.contractor[0].contractor.email}</p>
                  </>
                )}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Latest Progress</h3>
              {progressReports[0] ? (
                <div className="space-y-2">
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div
                      className="bg-blue-600 h-2.5 rounded-full"
                      style={{ width: `${progressReports[0].progress_percentage}%` }}
                    ></div>
                  </div>
                  {progressReports[0].tasks && (
                    <div className="mt-2">
                      <p className="text-sm font-medium text-gray-700">Completed Tasks:</p>
                      <div className="mt-1 space-y-1">
                        {progressReports[0].tasks.completed.map((task, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-600">
                            <CheckCircle2 className="h-4 w-4 text-green-500 mr-2" />
                            {task}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-gray-500">No progress reports yet</p>
              )}
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Recent Activity</h3>
              <div className="space-y-2">
                {changelogs.length > 0 ? (
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <p className="text-sm text-gray-700">
                        Last {changelogs.length} changes
                      </p>
                      <button
                        onClick={() => setActiveTab('changelog')}
                        className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
                      >
                        View all <ChevronLeft className="h-4 w-4 rotate-180 ml-1" />
                      </button>
                    </div>
                    <div className="text-sm text-gray-500">
                      {changelogs[0] && (
                        <div className="flex items-center mb-1">
                          <Activity className="h-4 w-4 text-blue-500 mr-2" />
                          <span>
                            {changelogs[0].user_email.split('@')[0]} modified {changelogs[0].change_type} {' '}
                            {formatDistanceToNow(new Date(changelogs[0].created_at), { addSuffix: true })}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-500">No recent changes recorded</p>
                )}
              </div>
            </div>
            
            <div className="mt-6 pt-4 border-t">
              <button
                onClick={() => setActiveTab('share')}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Share2 className="h-4 w-4 mr-2" />
                Share with Buyer
              </button>
              <p className="mt-2 text-sm text-gray-500">
                Create a shareable link for buyers to view unit progress without logging in.
              </p>
            </div>
          </div>
        );

      case 'progress':
        return (
          <div className="space-y-4">
            <div className="space-y-4">
              {progressReports.map((report) => (
                <div key={report.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-medium">{report.progress_percentage}% Complete</span>
                    <span className="text-sm text-gray-500">
                      {formatDate(report.report_date)}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-3">{report.description}</p>
                  
                  {report.tasks && (
                    <div className="mt-2">
                      <p className="text-sm font-medium text-gray-700 mb-2">Tasks Status:</p>
                      <div className="space-y-1">
                        {report.tasks.completed.map((task, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-600">
                            <CheckCircle2 className="h-4 w-4 text-green-500 mr-2" />
                            {task}
                          </div>
                        ))}
                        {report.tasks.total
                          .filter(task => !report.tasks?.completed.includes(task))
                          .map((task, index) => (
                            <div key={index} className="flex items-center text-sm text-gray-500">
                              <div className="h-4 w-4 border-2 border-gray-300 rounded-full mr-2" />
                              {task}
                            </div>
                          ))
                        }
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );

      case 'photos':
        return (
          <div className="space-y-4">
            {error && (
              <div className="p-3 bg-red-100 text-red-700 rounded-lg">
                {error}
              </div>
            )}

            <form onSubmit={handlePhotoUpload} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Photo</label>
                <input
                  id="photo-upload"
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      // Initialize the photoUpload state properly if it's null
                      if (!photoUpload) {
                        setPhotoUpload({
                          file: file,
                          caption: '',
                          isUploading: false
                        });
                      } else {
                        setPhotoUpload({
                          ...photoUpload,
                          file: file
                        });
                      }
                    }
                  }}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Caption</label>
                <input
                  type="text"
                  value={photoUpload?.caption || ''}
                  onChange={(e) => {
                    // Initialize the photoUpload state properly if it's null
                    if (!photoUpload) {
                      setPhotoUpload({
                        file: null,
                        caption: e.target.value,
                        isUploading: false
                      });
                    } else {
                      setPhotoUpload({
                        ...photoUpload,
                        caption: e.target.value
                      });
                    }
                  }}
                  placeholder="Enter a caption"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>
              <button
                type="submit"
                disabled={uploading || !photoUpload?.file}
                className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {uploading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Photo
                  </>
                )}
              </button>
            </form>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {photos.map((photo) => (
                <div key={photo.id} className="relative group">
                  <img
                    src={photo.photo_url}
                    alt={photo.caption}
                    className="w-full aspect-square object-cover rounded-lg cursor-pointer"
                    onClick={() => setPreviewPhoto(photo)}
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setPreviewPhoto(photo)}
                        className="p-2 bg-white text-gray-900 rounded-full hover:bg-gray-100"
                      >
                        <Maximize2 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => deletePhoto(unitId, photo)}
                        disabled={deleting === photo.id}
                        className="p-2 bg-red-600 text-white rounded-full hover:bg-red-700"
                      >
                        {deleting === photo.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Trash2 className="h-4 w-4" />
                        )}
                      </button>
                    </div>
                  </div>
                  {photo.caption && (
                    <p className="mt-1 text-sm text-gray-600 truncate">{photo.caption}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        );

      case 'complaints':
        return (
          <ComplaintsSection
            unitId={unitId}
            unitNumber={unit?.unit_number || ''}
            complaints={complaints}
            onComplaintAdded={fetchUnitDetails}
          />
        );
      
      case 'changelog':
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium mb-2">Recent Changes</h3>
            
            {changelogs.length > 0 ? (
              <div className="space-y-4">
                {changelogs.map((changelog) => {
                  const changeDate = new Date(changelog.created_at);
                  return (
                    <div key={changelog.id} className="border rounded-lg p-4 bg-gray-50">
                      <div className="flex items-start gap-4">
                        <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                          <Activity className="h-5 w-5 text-blue-600" />
                        </div>
                        <div className="flex-grow">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <span className="font-medium">
                                {changelog.user_email.split('@')[0]}
                              </span>
                              <span className="text-gray-500 ml-2">modified {changelog.change_type}</span>
                            </div>
                            <div className="text-sm text-gray-500 flex items-center">
                              <Clock className="h-3.5 w-3.5 mr-1" />
                              {formatDistanceToNow(changeDate, { addSuffix: true })}
                            </div>
                          </div>
                          
                          <div className="space-y-2 mt-2">
                            {Object.entries(changelog.change_details).map(([field, values], index) => (
                              <div key={index} className="text-sm bg-white p-2 rounded border border-gray-100">
                                <span className="font-medium capitalize">{field.replace('_', ' ')}: </span>
                                <div className="flex mt-1">
                                  <div className="flex-1">
                                    <span className="text-red-500 line-through mr-1">{values.from || 'None'}</span>
                                  </div>
                                  <div className="flex-1">
                                    <span className="text-green-600">{values.to || 'None'}</span>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-gray-500">No recent changes recorded</p>
            )}
          </div>
        );
        
      case 'share':
        return (
          <div>
            <h3 className="text-lg font-medium mb-4">Share with Buyer</h3>
            <p className="text-gray-600 mb-4">
              Create a shareable link that allows buyers to view construction progress 
              and updates for this housing unit without requiring them to log in.
            </p>
            <button
              onClick={() => setShowShareModal(true)}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Share2 className="h-4 w-4 mr-2" />
              Manage Share Links
            </button>
          </div>
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onClick={onClose}>
      <div 
        className="bg-white w-full h-full md:h-auto md:max-h-[90vh] md:w-[800px] md:rounded-lg flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-4 border-b border-gray-200">
          <button
            onClick={onClose}
            className="p-2 -ml-2 text-gray-500 hover:text-gray-700 md:hidden"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <h2 className="text-xl font-semibold flex-1 text-center md:text-left">
            Unit {unit?.unit_number}
          </h2>
          <button
            onClick={onClose}
            className="hidden md:block text-gray-500 hover:text-gray-700"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <div className="flex px-4 overflow-x-auto">
            <button
              onClick={() => setActiveTab('details')}
              className={`px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${
                activeTab === 'details'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Details
            </button>
            <button
              onClick={() => setActiveTab('progress')}
              className={`px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${
                activeTab === 'progress'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Progress
            </button>
            <button
              onClick={() => setActiveTab('photos')}
              className={`px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${
                activeTab === 'photos'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Photos
            </button>
            <button
              onClick={() => setActiveTab('complaints')}
              className={`px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${
                activeTab === 'complaints'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Complaints
            </button>
            <button
              onClick={() => setActiveTab('changelog')}
              className={`px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${
                activeTab === 'changelog'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Recent Changes
            </button>
            <button
              onClick={() => setActiveTab('share')}
              className={`px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${
                activeTab === 'share'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Share
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {renderContent()}
        </div>
      </div>

      {/* Photo Preview Modal */}
      {previewPhoto && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-[60]"
          onClick={() => setPreviewPhoto(null)}
        >
          <div className="relative max-w-[90vw] max-h-[90vh]" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => setPreviewPhoto(null)}
              className="absolute top-4 right-4 text-white hover:text-gray-300"
            >
              <X className="h-6 w-6" />
            </button>
            <img
              src={previewPhoto.photo_url}
              alt={previewPhoto.caption}
              className="max-w-full max-h-[90vh] object-contain"
            />
            {previewPhoto.caption && (
              <div className="absolute bottom-4 left-0 right-0 text-center text-white bg-black bg-opacity-50 py-2">
                {previewPhoto.caption}
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Share Housing Unit Modal */}
      {showShareModal && unit && (
        <ShareHousingUnit
          unitId={unitId}
          unitNumber={unit.unit_number}
          onClose={() => setShowShareModal(false)}
        />
      )}
    </div>
  );
};

export default HousingUnitDetails;