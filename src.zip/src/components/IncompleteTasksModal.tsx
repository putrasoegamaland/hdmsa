import React from 'react';
import { X, AlertTriangle } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  status: string;
  description?: string;
}

interface Props {
  tasks: Task[];
  onClose: () => void;
}

const IncompleteTasksModal: React.FC<Props> = ({ tasks, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[60]">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex items-start">
          <div className="flex-shrink-0">
            <AlertTriangle className="h-6 w-6 text-yellow-500" />
          </div>
          <div className="ml-3 w-full">
            <div className="flex justify-between items-start">
              <h3 className="text-lg font-medium text-gray-900">
                Cannot Mark as Completed
              </h3>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="mt-2">
              <p className="text-sm text-gray-500">
                The following tasks must be completed before marking this unit as completed:
              </p>
              <div className="mt-4 space-y-3">
                {tasks.map((task) => (
                  <div key={task.id} className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-medium text-gray-900">{task.title}</h4>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        task.status === 'blocked' 
                          ? 'bg-red-100 text-red-800'
                          : task.status === 'in-progress'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {task.status}
                      </span>
                    </div>
                    {task.description && (
                      <p className="mt-1 text-sm text-gray-500">{task.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-6">
              <button
                onClick={onClose}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                I Understand
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IncompleteTasksModal;