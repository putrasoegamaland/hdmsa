import React from 'react';
import { checkPermission } from '../lib/auth';

interface Props {
  action: string;
  fallback?: React.ReactNode;
  children: React.ReactNode;
}

const PermissionGuard: React.FC<Props> = ({ action, fallback = null, children }) => {
  const [hasPermission, setHasPermission] = React.useState(false);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    checkPermission(action)
      .then(setHasPermission)
      .finally(() => setLoading(false));
  }, [action]);

  if (loading) {
    return null;
  }

  return hasPermission ? <>{children}</> : <>{fallback}</>;
};

export default PermissionGuard;