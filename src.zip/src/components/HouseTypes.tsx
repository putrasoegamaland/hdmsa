import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Edit2, Copy, Trash2, ChevronDown, ChevronRight, AlertTriangle, Loader2, X } from 'lucide-react';
import { createNotification } from '../lib/notifications';

interface HouseType {
  id: string;
  name: string;
  description: string;
  created_at: string;
  default_tasks: DefaultTask[];
}

interface DefaultTask {
  id: string;
  title: string;
  description: string;
  order_number: number;
  progress_percentage: number;
}

interface TaskFormData {
  title: string;
  description: string;
  order_number: number;
  progress_percentage: number;
}

const HouseTypes = () => {
  const [houseTypes, setHouseTypes] = useState<HouseType[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<HouseType | null>(null);
  const [expandedType, setExpandedType] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    tasks: [{ title: '', description: '', order_number: 0, progress_percentage: 0 }] as TaskFormData[]
  });
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchHouseTypes();
  }, []);

  async function fetchHouseTypes() {
    try {
      const { data, error } = await supabase
        .from('house_types')
        .select(`
          *,
          default_tasks (
            id,
            title,
            description,
            order_number,
            progress_percentage
          )
        `)
        .order('name');

      if (error) throw error;
      setHouseTypes(data || []);
    } catch (error) {
      console.error('Error fetching house types:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      // Validate total percentage equals 100
      const totalPercentage = formData.tasks.reduce((sum, task) => sum + task.progress_percentage, 0);
      if (totalPercentage !== 100) {
        throw new Error('Total progress percentage must equal 100%');
      }

      if (selectedType) {
        // Update existing house type
        const { error: updateError } = await supabase
          .from('house_types')
          .update({
            name: formData.name,
            description: formData.description
          })
          .eq('id', selectedType.id);

        if (updateError) throw updateError;

        // Delete existing tasks
        const { error: deleteError } = await supabase
          .from('default_tasks')
          .delete()
          .eq('house_type_id', selectedType.id);

        if (deleteError) throw deleteError;

        // Insert new tasks
        const tasksToInsert = formData.tasks.map((task, index) => ({
          house_type_id: selectedType.id,
          title: task.title,
          description: task.description,
          order_number: index,
          progress_percentage: task.progress_percentage
        }));

        const { error: tasksError } = await supabase
          .from('default_tasks')
          .insert(tasksToInsert);

        if (tasksError) throw tasksError;

        await createNotification({
          title: 'House Type Updated',
          message: `House type "${formData.name}" has been updated successfully`,
          type: 'task_updated',
          link: '/house-types'
        });
      } else {
        // Insert new house type
        const { data: houseType, error: houseTypeError } = await supabase
          .from('house_types')
          .insert([{
            name: formData.name,
            description: formData.description
          }])
          .select()
          .single();

        if (houseTypeError) throw houseTypeError;

        // Insert tasks
        const tasksToInsert = formData.tasks.map((task, index) => ({
          house_type_id: houseType.id,
          title: task.title,
          description: task.description,
          order_number: index,
          progress_percentage: task.progress_percentage
        }));

        const { error: tasksError } = await supabase
          .from('default_tasks')
          .insert(tasksToInsert);

        if (tasksError) throw tasksError;

        await createNotification({
          title: 'House Type Created',
          message: `House type "${formData.name}" has been created successfully`,
          type: 'task_created',
          link: '/house-types'
        });
      }

      setIsModalOpen(false);
      setSelectedType(null);
      resetForm();
      fetchHouseTypes();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      tasks: [{ title: '', description: '', order_number: 0, progress_percentage: 0 }]
    });
  };

  const handleEdit = (type: HouseType) => {
    setSelectedType(type);
    setFormData({
      name: type.name,
      description: type.description || '',
      tasks: type.default_tasks?.map(task => ({
        title: task.title,
        description: task.description || '',
        order_number: task.order_number,
        progress_percentage: task.progress_percentage
      })) || []
    });
    setIsModalOpen(true);
  };

  const addTask = () => {
    setFormData(prev => ({
      ...prev,
      tasks: [
        ...prev.tasks,
        { title: '', description: '', order_number: prev.tasks.length, progress_percentage: 0 }
      ]
    }));
  };

  const removeTask = (index: number) => {
    setFormData(prev => ({
      ...prev,
      tasks: prev.tasks.filter((_, i) => i !== index)
    }));
  };

  const updateTask = (index: number, field: string, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      tasks: prev.tasks.map((task, i) => 
        i === index ? { ...task, [field]: value } : task
      )
    }));
  };

  const duplicateTemplate = async (template: HouseType) => {
    try {
      const newName = `${template.name} (Copy)`;
      
      // Create new house type
      const { data: newType, error: typeError } = await supabase
        .from('house_types')
        .insert([{
          name: newName,
          description: template.description
        }])
        .select()
        .single();

      if (typeError) throw typeError;

      // Duplicate tasks
      const tasksToInsert = template.default_tasks?.map(task => ({
        house_type_id: newType.id,
        title: task.title,
        description: task.description,
        order_number: task.order_number,
        progress_percentage: task.progress_percentage
      }));

      if (tasksToInsert?.length) {
        const { error: tasksError } = await supabase
          .from('default_tasks')
          .insert(tasksToInsert);

        if (tasksError) throw tasksError;
      }

      await createNotification({
        title: 'House Type Duplicated',
        message: `House type "${template.name}" has been duplicated`,
        type: 'task_created',
        link: '/house-types'
      });

      fetchHouseTypes();
    } catch (error: any) {
      setError(error.message);
    }
  };

  const deleteHouseType = async (id: string) => {
    try {
      const { error } = await supabase
        .from('house_types')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await createNotification({
        title: 'House Type Deleted',
        message: 'House type has been deleted successfully',
        type: 'task_updated',
        link: '/house-types'
      });

      fetchHouseTypes();
    } catch (error: any) {
      setError(error.message);
    }
  };

  const calculateTotalPercentage = () => {
    return formData.tasks.reduce((sum, task) => sum + task.progress_percentage, 0);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">House Types</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage house types and their default tasks
          </p>
        </div>
        <button
          onClick={() => {
            setSelectedType(null);
            resetForm();
            setIsModalOpen(true);
          }}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add House Type
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="flex-shrink-0 ml-4 text-red-500 hover:text-red-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {houseTypes.map((type) => (
          <div key={type.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{type.name}</h3>
                  <p className="mt-1 text-sm text-gray-500">{type.description}</p>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleEdit(type)}
                    className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                  >
                    <Edit2 className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => duplicateTemplate(type)}
                    className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
                  >
                    <Copy className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => deleteHouseType(type.id)}
                    className="p-2 text-red-400 hover:text-red-600 rounded-lg hover:bg-red-50"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>

              <div className="mt-4">
                <button
                  onClick={() => setExpandedType(expandedType === type.id ? null : type.id)}
                  className="flex items-center text-sm font-medium text-gray-900 mb-2"
                >
                  {expandedType === type.id ? (
                    <ChevronDown className="h-4 w-4 mr-2" />
                  ) : (
                    <ChevronRight className="h-4 w-4 mr-2" />
                  )}
                  Default Tasks
                </button>
                {expandedType === type.id && type.default_tasks && (
                  <div className="space-y-2">
                    {type.default_tasks
                      .sort((a, b) => a.order_number - b.order_number)
                      .map((task) => (
                        <div
                          key={task.id}
                          className="flex items-center p-3 bg-gray-50 rounded-lg"
                        >
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <p className="text-sm font-medium text-gray-900">{task.title}</p>
                              <span className="text-sm font-medium text-blue-600">
                                {task.progress_percentage}%
                              </span>
                            </div>
                            {task.description && (
                              <p className="text-sm text-gray-500 mt-1">{task.description}</p>
                            )}
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add/Edit House Type Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">
                {selectedType ? 'Edit House Type' : 'Add New House Type'}
              </h2>
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setSelectedType(null);
                  resetForm();
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Name
                </label>
                <input
                  required
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  placeholder="e.g., Type A"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={3}
                  placeholder="Describe the house type..."
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block text-sm font-medium text-gray-700">
                    Default Tasks
                  </label>
                  <div className="flex items-center space-x-4">
                    <div className="text-sm">
                      Total: <span className={`font-medium ${calculateTotalPercentage() === 100 ? 'text-green-600' : 'text-red-600'}`}>
                        {calculateTotalPercentage()}%
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={addTask}
                      className="text-sm text-blue-600 hover:text-blue-700"
                    >
                      + Add Task
                    </button>
                  </div>
                </div>

                {calculateTotalPercentage() !== 100 && (
                  <div className="mb-4 flex items-center text-sm text-yellow-700 bg-yellow-50 p-3 rounded-lg">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Total progress percentage must equal 100%
                  </div>
                )}

                <div className="space-y-4">
                  {formData.tasks.map((task, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-4">
                        <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-sm">
                          Step {index + 1}
                        </span>
                        {formData.tasks.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeTask(index)}
                            className="text-red-400 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </div>

                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Title
                          </label>
                          <input
                            required
                            type="text"
                            value={task.title}
                            onChange={(e) => updateTask(index, 'title', e.target.value)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2"
                            placeholder="Task title"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Description
                          </label>
                          <textarea
                            value={task.description}
                            onChange={(e) => updateTask(index, 'description', e.target.value)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2"
                            rows={2}
                            placeholder="Task description (optional)"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">
                            Progress Weight (%)
                          </label>
                          <input
                            required
                            type="number"
                            min="0"
                            max="100"
                            value={task.progress_percentage}
                            onChange={(e) => updateTask(index, 'progress_percentage', parseInt(e.target.value) || 0)}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsModalOpen(false);
                    setSelectedType(null);
                    resetForm();
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting || calculateTotalPercentage() !== 100}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {submitting ? (
                    <div className="flex items-center">
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      {selectedType ? 'Saving...' : 'Creating...'}
                    </div>
                  ) : (
                    selectedType ? 'Save Changes' : 'Create House Type'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default HouseTypes;