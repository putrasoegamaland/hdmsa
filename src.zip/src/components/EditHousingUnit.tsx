import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { X, Loader2, AlertTriangle } from 'lucide-react';
import IncompleteTasksModal from './IncompleteTasksModal';
import { createNotification } from '../lib/notifications';
import { useAuth } from '../components/AuthProvider';

interface Props {
  unit: {
    id: string;
    unit_number: string;
    status: string;
    payment_phase: string;
    buyer_phase: string;
    bank_name?: string;
    housing_unit_contractors?: {
      contractor_id: string;
      contractor: {
        id: string;
        name: string;
        email: string;
      };
    }[];
  };
  contractors: {
    id: string;
    name: string;
    email: string;
    status: string;
  }[];
  onClose: () => void;
  onSuccess: () => void;
}

const EditHousingUnit: React.FC<Props> = ({ unit, contractors, onClose, onSuccess }) => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    status: unit.status,
    payment_phase: unit.payment_phase,
    buyer_phase: unit.buyer_phase,
    bank_name: unit.bank_name || ''
  });

  // Initialize with current contractor if exists
  const [selectedContractor, setSelectedContractor] = useState<string | null>(
    unit.housing_unit_contractors?.[0]?.contractor_id || null
  );

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showIncompleteTasksModal, setShowIncompleteTasksModal] = useState(false);
  const [incompleteTasks, setIncompleteTasks] = useState<any[]>([]);

  const statusOptions = ['on-schedule', 'delayed', 'completed'];
  const paymentPhases = ['phase-1', 'phase-2', 'phase-3', 'retensi'];
  const buyerPhases = ['none', 'Hold', 'Progress Bank', 'Cash', 'Ready Stock'];

  const checkIncompleteTasks = async (unitId: string) => {
    try {
      const { data: tasks, error: tasksError } = await supabase
        .from('tasks')
        .select('*')
        .eq('housing_unit_id', unitId)
        .neq('status', 'completed');

      if (tasksError) throw tasksError;

      if (tasks && tasks.length > 0) {
        setIncompleteTasks(tasks);
        setShowIncompleteTasksModal(true);
        return true;
      }
    } catch (error: any) {
      setError(error.message);
    }
    return false;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      // Check for incomplete tasks if trying to mark as completed
      if (formData.status === 'completed' && unit.status !== 'completed') {
        const hasIncompleteTasks = await checkIncompleteTasks(unit.id);
        if (hasIncompleteTasks) {
          setSubmitting(false);
          return;
        }
      }

      // Create changelog entry to track changes
      const changes = {};
      if (formData.status !== unit.status) changes['status'] = { from: unit.status, to: formData.status };
      if (formData.payment_phase !== unit.payment_phase) changes['payment_phase'] = { from: unit.payment_phase, to: formData.payment_phase };
      if (formData.buyer_phase !== unit.buyer_phase) changes['buyer_phase'] = { from: unit.buyer_phase, to: formData.buyer_phase };
      if (formData.bank_name !== unit.bank_name) changes['bank_name'] = { from: unit.bank_name || '', to: formData.bank_name };
      
      // Track contractor changes
      const currentContractorId = unit.housing_unit_contractors?.[0]?.contractor_id || null;
      if (selectedContractor !== currentContractorId) {
        const currentContractor = contractors.find(c => c.id === currentContractorId);
        const newContractor = contractors.find(c => c.id === selectedContractor);
        changes['contractor'] = { 
          from: currentContractor ? currentContractor.name : 'None', 
          to: newContractor ? newContractor.name : 'None' 
        };
      }
      
      // Update housing unit
      const { error: updateError } = await supabase
        .from('housing_units')
        .update({
          status: formData.status,
          payment_phase: formData.payment_phase,
          buyer_phase: formData.buyer_phase,
          bank_name: formData.bank_name
        })
        .eq('id', unit.id);

      if (updateError) throw updateError;
      
      // Add to changelog if there were changes
      if (Object.keys(changes).length > 0) {
        const changeType = Object.keys(changes).join(', ');
        await supabase
          .from('housing_unit_changelogs_0pr47')
          .insert({
            housing_unit_id: unit.id,
            user_email: user?.email || 'system',
            change_type: changeType,
            change_details: changes
          });
      }

      // Handle contractor assignment
      const { data: existingAssignment, error: selectError } = await supabase
        .from('housing_unit_contractors')
        .select('*')
        .eq('housing_unit_id', unit.id)
        .single();

      if (selectError && selectError.code !== 'PGRST116') throw selectError;

      if (selectedContractor) {
        if (existingAssignment) {
          // Update existing assignment
          const { error: updateContractorError } = await supabase
            .from('housing_unit_contractors')
            .update({ contractor_id: selectedContractor })
            .eq('housing_unit_id', unit.id);

          if (updateContractorError) throw updateContractorError;
        } else {
          // Create new assignment
          const { error: insertContractorError } = await supabase
            .from('housing_unit_contractors')
            .insert([{
              housing_unit_id: unit.id,
              contractor_id: selectedContractor
            }]);

          if (insertContractorError) throw insertContractorError;
        }
      } else if (existingAssignment) {
        // Remove existing assignment if no contractor selected
        const { error: deleteError } = await supabase
          .from('housing_unit_contractors')
          .delete()
          .eq('housing_unit_id', unit.id);

        if (deleteError) throw deleteError;
      }

      // Get contractor name for notification
      const contractor = contractors.find(c => c.id === selectedContractor);

      // Create notification with status change information
      const statusMessage = unit.status !== formData.status 
        ? `status changed from ${unit.status} to ${formData.status}` 
        : 'status updated';

      await createNotification({
        title: 'Housing Unit Updated',
        message: `Unit ${unit.unit_number} ${statusMessage}${contractor ? ` and assigned to ${contractor.name}` : ''}`,
        type: 'unit_added',
        link: '/housing-units'
      });

      onSuccess();
      onClose();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Edit Unit {unit.unit_number}</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              required
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              {statusOptions.map((status) => (
                <option key={status} value={status}>
                  {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Payment Phase
            </label>
            <select
              required
              value={formData.payment_phase}
              onChange={(e) => setFormData({ ...formData, payment_phase: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              {paymentPhases.map((phase) => (
                <option key={phase} value={phase}>
                  {phase.charAt(0).toUpperCase() + phase.slice(1).replace('-', ' ')}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Buyer Phase
            </label>
            <select
              required
              value={formData.buyer_phase}
              onChange={(e) => setFormData({ ...formData, buyer_phase: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              {buyerPhases.map((phase) => (
                <option key={phase} value={phase}>
                  {phase}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Bank Name
            </label>
            <select
              value={formData.bank_name}
              onChange={(e) => setFormData({ ...formData, bank_name: e.target.value })}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              <option value="">Select a bank</option>
              <option value="BCA">BCA</option>
              <option value="Mandiri">Mandiri</option>
              <option value="BNI">BNI</option>
              <option value="BTN">BTN</option>
              <option value="BRI">BRI</option>
              <option value="CIMB Niaga">CIMB Niaga</option>
              <option value="Permata">Permata</option>
              <option value="Danamon">Danamon</option>
              <option value="Panin">Panin</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Assigned Contractor
            </label>
            <select
              value={selectedContractor || ''}
              onChange={(e) => setSelectedContractor(e.target.value || null)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2"
            >
              <option value="">No contractor assigned</option>
              {contractors
                .filter(c => c.status === 'Active')
                .map((contractor) => (
                  <option key={contractor.id} value={contractor.id}>
                    {contractor.name} ({contractor.email})
                  </option>
                ))}
            </select>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </button>
          </div>
        </form>
      </div>

      {showIncompleteTasksModal && (
        <IncompleteTasksModal
          tasks={incompleteTasks}
          onClose={() => setShowIncompleteTasksModal(false)}
        />
      )}
    </div>
  );
};

export default EditHousingUnit;