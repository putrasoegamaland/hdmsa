import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Check, X, Loader2, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { createNotification } from '../lib/notifications';

interface Complaint {
  id: string;
  description: string;
  status: 'open' | 'in-progress' | 'resolved';
  created_at: string;
  updated_at: string;
}

interface Props {
  unitId: string;
  unitNumber: string;
  complaints: Complaint[];
  onComplaintAdded: () => void;
}

const ComplaintsSection: React.FC<Props> = ({ unitId, unitNumber, complaints, onComplaintAdded }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDescription, setEditDescription] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      const { data, error: submitError } = await supabase
        .from('complaints')
        .insert([{
          housing_unit_id: unitId,
          description: description.trim()
        }])
        .select()
        .single();

      if (submitError) throw submitError;

      await createNotification({
        title: 'New Complaint Added',
        message: `A new complaint has been added for unit ${unitNumber}`,
        type: 'task_created',
        link: '/housing-units'
      });

      setDescription('');
      setIsAdding(false);
      onComplaintAdded();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (complaintId: string, newStatus: 'open' | 'in-progress' | 'resolved') => {
    try {
      const { error: updateError } = await supabase
        .from('complaints')
        .update({ status: newStatus })
        .eq('id', complaintId);

      if (updateError) throw updateError;

      await createNotification({
        title: 'Complaint Status Updated',
        message: `Complaint status for unit ${unitNumber} has been updated to ${newStatus}`,
        type: 'task_updated',
        link: '/housing-units'
      });

      onComplaintAdded();
    } catch (error: any) {
      setError(error.message);
    }
  };

  const handleEdit = async (complaintId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('complaints')
        .update({ description: editDescription })
        .eq('id', complaintId);

      if (updateError) throw updateError;

      setEditingId(null);
      setEditDescription('');
      onComplaintAdded();
    } catch (error: any) {
      setError(error.message);
    }
  };

  const statusColors = {
    'open': 'bg-red-100 text-red-800',
    'in-progress': 'bg-yellow-100 text-yellow-800',
    'resolved': 'bg-green-100 text-green-800'
  };

  return (
    <div className="mt-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">Complaints</h3>
        <button
          onClick={() => setIsAdding(true)}
          className="flex items-center text-sm text-blue-600 hover:text-blue-800"
        >
          <Plus className="h-4 w-4 mr-1" />
          Add Complaint
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg flex items-center">
          <AlertTriangle className="h-5 w-5 mr-2" />
          {error}
        </div>
      )}

      {isAdding && (
        <form onSubmit={handleSubmit} className="mb-4">
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-3 py-2 mb-2"
            rows={3}
            placeholder="Describe the complaint..."
            required
          />
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting || !description.trim()}
              className="flex items-center px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit'
              )}
            </button>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {complaints.map((complaint) => (
          <div key={complaint.id} className="border rounded-lg p-4">
            {editingId === complaint.id ? (
              <div className="space-y-2">
                <textarea
                  value={editDescription}
                  onChange={(e) => setEditDescription(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={2}
                />
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => setEditingId(null)}
                    className="text-sm text-gray-600 hover:text-gray-800"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleEdit(complaint.id)}
                    className="text-sm text-blue-600 hover:text-blue-800"
                  >
                    Save
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex justify-between items-start mb-2">
                  <p className="text-gray-700">{complaint.description}</p>
                  <button
                    onClick={() => {
                      setEditingId(complaint.id);
                      setEditDescription(complaint.description);
                    }}
                    className="text-sm text-gray-500 hover:text-gray-700"
                  >
                    Edit
                  </button>
                </div>
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center space-x-4">
                    <span className="text-sm text-gray-500">
                      {format(new Date(complaint.created_at), 'MMM dd, yyyy HH:mm')}
                    </span>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      statusColors[complaint.status]
                    }`}>
                      {complaint.status}
                    </span>
                  </div>
                  <select
                    value={complaint.status}
                    onChange={(e) => handleStatusChange(
                      complaint.id,
                      e.target.value as 'open' | 'in-progress' | 'resolved'
                    )}
                    className="text-sm border border-gray-300 rounded-lg px-2 py-1"
                  >
                    <option value="open">Open</option>
                    <option value="in-progress">In Progress</option>
                    <option value="resolved">Resolved</option>
                  </select>
                </div>
              </>
            )}
          </div>
        ))}
        {complaints.length === 0 && (
          <p className="text-sm text-gray-500 text-center py-4">
            No complaints yet
          </p>
        )}
      </div>
    </div>
  );
};

export default ComplaintsSection;