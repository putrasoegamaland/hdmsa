import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Search, Filter, Loader2, AlertTriangle, X, Trash2 } from 'lucide-react';
import AddContractor from './AddContractor';
import EditContractor from './EditContractor';
import { createNotification } from '../lib/notifications';

interface Project {
  id: string;
  title: string;
}

interface Contractor {
  id: string;
  name: string;
  email: string;
  company: string | null;
  status: string;
  created_at: string;
  unit_count: number;
  completed_units: number;
  in_progress_units: number;
  delayed_units: number;
}

interface DeleteConfirmation {
  contractorId: string;
  contractorName: string;
  isDeleting: boolean;
}

const Contractors = () => {
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingContractor, setEditingContractor] = useState<Contractor | null>(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState<DeleteConfirmation | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchContractors();
  }, []);

  async function fetchContractors() {
    try {
      console.log('Fetching contractors...');
      
      // First get all contractors
      const { data: contractorsData, error: contractorsError } = await supabase
        .from('contractors')
        .select('*')
        .order('created_at', { ascending: false });

      if (contractorsError) throw contractorsError;
      console.log('Received contractors data:', contractorsData);

      if (!contractorsData) {
        setContractors([]);
        return;
      }

      // Then get housing unit data for each contractor
      const contractorsWithStats = await Promise.all(
        contractorsData.map(async (contractor) => {
          const { data: housingUnits, error: unitsError } = await supabase
            .from('housing_unit_contractors')
            .select(`
              housing_unit:housing_unit_id (
                id,
                status,
                tasks (
                  id,
                  status
                )
              )
            `)
            .eq('contractor_id', contractor.id);

          if (unitsError) {
            console.error('Error fetching units for contractor:', unitsError);
            return {
              ...contractor,
              unit_count: 0,
              completed_units: 0,
              in_progress_units: 0,
              delayed_units: 0
            };
          }

          const units = housingUnits?.map(huc => huc.housing_unit) || [];
          const completed = units.filter(unit => unit?.status === 'completed').length;
          const delayed = units.filter(unit => unit?.status === 'delayed').length;
          const inProgress = units.length - completed - delayed;

          return {
            ...contractor,
            unit_count: units.length,
            completed_units: completed,
            in_progress_units: inProgress,
            delayed_units: delayed
          };
        })
      );

      console.log('Transformed contractors data:', contractorsWithStats);
      setContractors(contractorsWithStats);
    } catch (error: any) {
      console.error('Error fetching contractors:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  }

  const handleDeleteContractor = async () => {
    if (!deleteConfirmation) return;

    try {
      setDeleteConfirmation({ ...deleteConfirmation, isDeleting: true });

      // Delete tasks first
      const { error: tasksError } = await supabase
        .from('tasks')
        .delete()
        .eq('assigned_to', deleteConfirmation.contractorId);

      if (tasksError) throw tasksError;

      // Delete crew movements
      const { error: crewMovementsError } = await supabase
        .from('crew_movements')
        .delete()
        .eq('contractor_id', deleteConfirmation.contractorId);

      if (crewMovementsError) throw crewMovementsError;

      // Delete quality metrics
      const { error: qualityMetricsError } = await supabase
        .from('quality_metrics')
        .delete()
        .eq('measured_by', deleteConfirmation.contractorId);

      if (qualityMetricsError) throw qualityMetricsError;

      // Delete workflow step completions
      const { error: workflowStepCompletionsError } = await supabase
        .from('workflow_step_completions')
        .delete()
        .eq('completed_by', deleteConfirmation.contractorId);

      if (workflowStepCompletionsError) throw workflowStepCompletionsError;

      // Delete unit inspections
      const { error: inspectionsError } = await supabase
        .from('unit_inspections')
        .delete()
        .eq('inspector_id', deleteConfirmation.contractorId);

      if (inspectionsError) throw inspectionsError;

      // Delete housing unit contractors
      const { error: housingUnitContractorsError } = await supabase
        .from('housing_unit_contractors')
        .delete()
        .eq('contractor_id', deleteConfirmation.contractorId);

      if (housingUnitContractorsError) throw housingUnitContractorsError;

      // Finally delete the contractor
      const { error: contractorError } = await supabase
        .from('contractors')
        .delete()
        .eq('id', deleteConfirmation.contractorId);

      if (contractorError) throw contractorError;

      await createNotification({
        title: 'Contractor Deleted',
        message: `Contractor "${deleteConfirmation.contractorName}" has been deleted successfully`,
        type: 'unit_added',
        link: '/contractors'
      });

      setContractors(contractors.filter(c => c.id !== deleteConfirmation.contractorId));
      setDeleteConfirmation(null);
    } catch (error: any) {
      console.error('Error deleting contractor:', error);
      setError(`Failed to delete contractor: ${error.message}`);
    }
  };

  const filteredContractors = contractors.filter(contractor =>
    contractor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (contractor.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (contractor.company || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const statusColors = {
    'Active': 'bg-green-100 text-green-800',
    'Inactive': 'bg-gray-100 text-gray-800',
    'Suspended': 'bg-red-100 text-red-800'
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Contractors</h1>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add New Contractor
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
          <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-sm font-medium text-red-800">Error</h3>
            <p className="text-sm text-red-700 mt-1">{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className="flex-shrink-0 ml-4 text-red-500 hover:text-red-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      <div className="flex space-x-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search contractors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
          <Filter className="h-5 w-5 mr-2" />
          Filter
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="bg-white shadow rounded-lg overflow-auto max-h-[70vh]">
          <table className="min-w-full divide-y divide-gray-200 table-fixed">
            <thead className="bg-gray-50 sticky top-0 z-10">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                  Name
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                  Email
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                  Company
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-48">
                  Units Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                  Created At
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredContractors.map((contractor) => (
                <tr key={contractor.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{contractor.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{contractor.email}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{contractor.company || '-'}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColors[contractor.status as keyof typeof statusColors]}`}>
                      {contractor.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex flex-col space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">Total:</span>
                        <span className="text-sm font-medium text-gray-900">{contractor.unit_count}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">Completed:</span>
                        <span className="text-sm font-medium text-green-600">{contractor.completed_units}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">In Progress:</span>
                        <span className="text-sm font-medium text-blue-600">{contractor.in_progress_units}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">Delayed:</span>
                        <span className="text-sm font-medium text-red-600">{contractor.delayed_units}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(contractor.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex items-center justify-end space-x-3">
                      <button
                        onClick={() => setEditingContractor(contractor)}
                        className="text-blue-600 hover:text-blue-900"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => setDeleteConfirmation({
                          contractorId: contractor.id,
                          contractorName: contractor.name,
                          isDeleting: false
                        })}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Contractor Modal */}
      {isAddModalOpen && (
        <AddContractor
          onClose={() => setIsAddModalOpen(false)}
          onSuccess={fetchContractors}
        />
      )}

      {/* Edit Contractor Modal */}
      {editingContractor && (
        <EditContractor
          contractor={editingContractor}
          onClose={() => setEditingContractor(null)}
          onSuccess={fetchContractors}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-gray-900">
                  Delete Contractor
                </h3>
                <div className="mt-2">
                  <p className="text-sm text-gray-500">
                    Are you sure you want to delete "{deleteConfirmation.contractorName}"? This action cannot be undone and will remove all associated tasks, assignments, and records.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setDeleteConfirmation(null)}
                disabled={deleteConfirmation.isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteContractor}
                disabled={deleteConfirmation.isDeleting}
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                {deleteConfirmation.isDeleting ? (
                  <>
                    <Loader2 className="animate-spin h-4 w-4 mr-2" />
                    Deleting...
                  </>
                ) : (
                  'Delete Contractor'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Contractors;