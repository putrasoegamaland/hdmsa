import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Cloud, CloudRain, CloudSnow, Sun, CloudLightning, Loader2, ChevronRight, ChevronLeft, Search, X } from 'lucide-react';
import { format } from 'date-fns';

interface WeatherData {
  list: Array<{
    dt: number;
    main: {
      temp: number;
      feels_like: number;
      temp_min: number;
      temp_max: number;
      humidity: number;
      pressure: number;
    };
    weather: Array<{
      id: number;
      main: string;
      description: string;
      icon: string;
    }>;
    wind: {
      speed: number;
      deg: number;
    };
    clouds: {
      all: number;
    };
    pop: number;
    dt_txt: string;
  }>;
  city: {
    name: string;
    country: string;
    sunrise: number;
    sunset: number;
  };
}

interface DailyForecast {
  date: Date;
  temp_max: number;
  temp_min: number;
  main: string;
  description: string;
  icon: string;
  pop: number;
  humidity: number;
  wind_speed: number;
  readings: Array<{
    time: Date;
    temp: number;
    main: string;
    description: string;
  }>;
}

const Weather = () => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [dailyForecasts, setDailyForecasts] = useState<DailyForecast[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentDay, setCurrentDay] = useState(0);
  const [city, setCity] = useState('Tangerang');
  const [country, setCountry] = useState('ID');
  const [isSearching, setIsSearching] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchWeather = async (location: string) => {
    try {
      setLoading(true);
      setError(null);
      
      const API_KEY = import.meta.env.VITE_OPENWEATHER_API_KEY;
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/forecast?q=${location}&appid=${API_KEY}&units=metric`
      );
      
      setWeather(response.data);
      setCity(response.data.city.name);
      setCountry(response.data.city.country);

      // Process the 3-hour forecasts into daily forecasts
      const dailyData: { [key: string]: DailyForecast } = {};
      
      response.data.list.forEach((reading: any) => {
        const date = new Date(reading.dt * 1000);
        const dateKey = format(date, 'yyyy-MM-dd');
        
        if (!dailyData[dateKey]) {
          dailyData[dateKey] = {
            date,
            temp_max: reading.main.temp_max,
            temp_min: reading.main.temp_min,
            main: reading.weather[0].main,
            description: reading.weather[0].description,
            icon: reading.weather[0].icon,
            pop: reading.pop,
            humidity: reading.main.humidity,
            wind_speed: reading.wind.speed,
            readings: []
          };
        } else {
          dailyData[dateKey].temp_max = Math.max(dailyData[dateKey].temp_max, reading.main.temp_max);
          dailyData[dateKey].temp_min = Math.min(dailyData[dateKey].temp_min, reading.main.temp_min);
          dailyData[dateKey].pop = Math.max(dailyData[dateKey].pop, reading.pop);
        }

        dailyData[dateKey].readings.push({
          time: date,
          temp: reading.main.temp,
          main: reading.weather[0].main,
          description: reading.weather[0].description
        });
      });

      setDailyForecasts(Object.values(dailyData));
      setError(null);
    } catch (err: any) {
      if (err.response?.status === 404) {
        setError('City not found. Please try another location.');
      } else {
        setError('Failed to load weather data');
        console.error('Weather API Error:', err);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather(`${city},${country}`);
    // Refresh weather data every 12 hours (12 * 60 * 60 * 1000 ms)
    const interval = setInterval(() => fetchWeather(`${city},${country}`), 12 * 60 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    
    await fetchWeather(searchQuery);
    setSearchQuery('');
    setIsSearching(false);
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'clear':
        return <Sun className="h-8 w-8 text-yellow-400" />;
      case 'rain':
      case 'drizzle':
        return <CloudRain className="h-8 w-8 text-blue-400" />;
      case 'snow':
        return <CloudSnow className="h-8 w-8 text-blue-200" />;
      case 'thunderstorm':
        return <CloudLightning className="h-8 w-8 text-yellow-400" />;
      default:
        return <Cloud className="h-8 w-8 text-gray-400" />;
    }
  };

  if (loading) {
    return (
      <div className="bg-white p-6 rounded-xl shadow-sm flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error || !weather || dailyForecasts.length === 0) {
    return (
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <p className="text-red-500 text-sm">{error || 'Unable to load weather data'}</p>
          <button
            onClick={() => fetchWeather(`${city},${country}`)}
            className="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  const currentForecast = dailyForecasts[currentDay];

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex-1">
          {isSearching ? (
            <form onSubmit={handleSearch} className="flex items-center">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search city..."
                  className="w-full pr-8 pl-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
              <button
                type="button"
                onClick={() => setIsSearching(false)}
                className="ml-2 px-3 py-2 text-gray-600 hover:text-gray-800"
              >
                Cancel
              </button>
            </form>
          ) : (
            <div className="flex items-center">
              <div>
                <h3 className="text-lg font-medium text-gray-900">
                  {weather.city.name}, {weather.city.country}
                </h3>
                <p className="text-sm text-gray-500">
                  {format(currentForecast.date, 'EEEE, MMM d')}
                </p>
              </div>
              <button
                onClick={() => setIsSearching(true)}
                className="ml-4 p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
              >
                <Search className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>
        {!isSearching && getWeatherIcon(currentForecast.main)}
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <p className="text-sm text-gray-500">High / Low</p>
          <p className="text-2xl font-semibold text-gray-900">
            {Math.round(currentForecast.temp_max)}° / {Math.round(currentForecast.temp_min)}°
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Precipitation</p>
          <p className="text-2xl font-semibold text-gray-900">
            {Math.round(currentForecast.pop * 100)}%
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Humidity</p>
          <p className="text-2xl font-semibold text-gray-900">
            {currentForecast.humidity}%
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-500">Wind Speed</p>
          <p className="text-2xl font-semibold text-gray-900">
            {Math.round(currentForecast.wind_speed)} m/s
          </p>
        </div>
      </div>

      {/* Hourly forecast for selected day */}
      <div className="mb-6">
        <h4 className="text-sm font-medium text-gray-900 mb-2">Hourly Forecast</h4>
        <div className="grid grid-cols-4 gap-2">
          {currentForecast.readings.map((reading, index) => (
            <div key={index} className="text-center p-2 bg-gray-50 rounded-lg">
              <div className="text-xs font-medium text-gray-500">
                {format(reading.time, 'HH:mm')}
              </div>
              <div className="my-1">
                {getWeatherIcon(reading.main)}
              </div>
              <div className="text-sm font-medium text-gray-900">
                {Math.round(reading.temp)}°
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 5-day forecast */}
      <div className="border-t border-gray-100 pt-4">
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-sm font-medium text-gray-900">5-Day Forecast</h4>
          <div className="flex space-x-2">
            <button
              onClick={() => setCurrentDay(Math.max(0, currentDay - 1))}
              disabled={currentDay === 0}
              className="p-1 text-gray-500 hover:text-gray-700 disabled:opacity-50"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => setCurrentDay(Math.min(dailyForecasts.length - 1, currentDay + 1))}
              disabled={currentDay === dailyForecasts.length - 1}
              className="p-1 text-gray-500 hover:text-gray-700 disabled:opacity-50"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
        <div className="grid grid-cols-5 gap-2">
          {dailyForecasts.map((day, index) => (
            <button
              key={format(day.date, 'yyyy-MM-dd')}
              onClick={() => setCurrentDay(index)}
              className={`text-center p-2 rounded-lg transition-colors ${
                currentDay === index
                  ? 'bg-blue-50 ring-1 ring-blue-500'
                  : 'hover:bg-gray-50'
              }`}
            >
              <div className="text-xs font-medium text-gray-500">
                {format(day.date, 'EEE')}
              </div>
              <div className="my-1">
                {getWeatherIcon(day.main)}
              </div>
              <div className="text-xs">
                <span className="font-medium text-gray-900">{Math.round(day.temp_max)}°</span>
                <span className="text-gray-500"> / {Math.round(day.temp_min)}°</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 pt-4 border-t border-gray-100">
        <p className="text-sm text-gray-500">
          {currentForecast.description.charAt(0).toUpperCase() + 
           currentForecast.description.slice(1)}
        </p>
      </div>
    </div>
  );
};

export default Weather;