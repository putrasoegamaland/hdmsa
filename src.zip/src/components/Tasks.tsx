import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Plus, Search, Filter, Calendar, Clock, X, Loader2, CheckCircle2, AlertTriangle, Camera, Upload, Maximize2, Trash2 } from 'lucide-react';
import { format, isAfter } from 'date-fns';
import { createNotification } from '../lib/notifications';
import { updateHousingUnitProgress } from '../lib/progressCalculation';

interface Task {
  id: string;
  title: string;
  description: string;
  status: string;
  due_date: string;
  housing_unit_id: string;
  assigned_to: string | null;
  created_at: string;
  updated_at: string;
  housing_unit?: {
    unit_number: string;
    status: string;
  };
  contractor?: {
    name: string;
  };
  photos?: TaskPhoto[];
}

interface TaskPhoto {
  id: string;
  photo_url: string;
  caption: string;
  created_at: string;
}

interface HousingUnit {
  id: string;
  unit_number: string;
  status: string;
}

interface Contractor {
  id: string;
  name: string;
}

interface PhotoUpload {
  taskId: string;
  file: File | null;
  caption: string;
  isUploading: boolean;
  captureMode: 'upload' | 'camera';
  captureStream: MediaStream | null;
}

interface DeleteConfirmation {
  taskId: string;
  taskTitle: string;
  isDeleting: boolean;
}

const Tasks = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [housingUnits, setHousingUnits] = useState<HousingUnit[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'todo',
    due_date: '',
    housing_unit_id: '',
    assigned_to: null as string | null
  });
  const [error, setError] = useState<string | null>(null);
  const [validationModal, setValidationModal] = useState<{message: string, taskId: string} | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [filter, setFilter] = useState<'all' | 'todo' | 'in-progress' | 'completed' | 'blocked'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [photoUpload, setPhotoUpload] = useState<PhotoUpload | null>(null);
  const [uploading, setUploading] = useState<boolean>(false);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const [previewPhoto, setPreviewPhoto] = useState<TaskPhoto | null>(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState<DeleteConfirmation | null>(null);
  // Track when the component becomes visible to force refresh
  const [pageVisible, setPageVisible] = useState<boolean>(true);

  useEffect(() => {
    console.log('Tasks component mounted');
    
    // Set initial loading state
    setLoading(true);
    setError(null);
    
    // Load all required data
    const loadInitialData = async () => {
      try {
        console.log('Loading initial data...');
        await Promise.all([
          fetchTasks(),
          fetchHousingUnits(),
          fetchContractors()
        ]);
        console.log('Initial data loaded successfully');
      } catch (err) {
        console.error('Error loading initial data:', err);
      }
    };
    
    loadInitialData();
    
    // Set up visibility change event listeners to refresh data when the user returns to the page
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        console.log('Page became visible, refreshing data');
        setPageVisible(true);
        fetchTasks().catch(err => {
          console.error('Error refreshing tasks on visibility change:', err);
        });
      } else {
        setPageVisible(false);
      }
    };
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Clean up event listener on component unmount
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);
  
  // Also refresh the task data when route changes are detected
  useEffect(() => {
    // Add event listeners for route changes
    const handleRouteChange = () => {
      fetchTasks(); // Refresh tasks when returning to this component
    };
    
    window.addEventListener('popstate', handleRouteChange);
    
    // Clean up
    return () => {
      window.removeEventListener('popstate', handleRouteChange);
    };
  }, []);

  async function fetchTasks() {
    try {
      setLoading(true);
      console.log('Fetching fresh task data...');
      
      // Remove the cache-busting approach that was causing issues
      const { data, error } = await supabase
        .from('tasks')
        .select(`
          *,
          housing_unit:housing_unit_id(unit_number, status),
          contractor:assigned_to(name),
          photos:task_photos(*)
        `)
        .order('due_date', { ascending: true });

      if (error) {
        console.error('Database error when fetching tasks:', error);
        setError(`Failed to load tasks: ${error.message}`);
        throw error;
      }
      
      console.log(`Fetched ${data?.length || 0} tasks with photos`);
      
      // Enhanced debugging to see what we're getting from DB
      if (data) {
        for (const task of data) {
          if (task.photos && task.photos.length > 0) {
            console.log(`Task ${task.id} has ${task.photos.length} photos:`, 
                        JSON.stringify(task.photos.map(p => ({ id: p.id, url: p.photo_url }))));
          }
        }
      }
      
      setTasks(data || []);
    } catch (error: any) {
      console.error('Error fetching tasks:', error);
      setError(`Error loading tasks: ${error.message || 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  }

  async function fetchHousingUnits() {
    try {
      const { data, error } = await supabase
        .from('housing_units')
        .select('id, unit_number, status')
        .order('unit_number', { ascending: true });

      if (error) throw error;
      setHousingUnits(data || []);
    } catch (error) {
      console.error('Error fetching housing units:', error);
    }
  }

  async function fetchContractors() {
    try {
      const { data, error } = await supabase
        .from('contractors')
        .select('id, name')
        .order('name', { ascending: true });

      if (error) throw error;
      setContractors(data || []);
    } catch (error) {
      console.error('Error fetching contractors:', error);
    }
  }

  // Photo upload is handled by the main handlePhotoUpload function below

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    // Prevent creating a completed task directly (must have photos)
    if (formData.status === 'completed') {
      setError('Kamu harus mengupload bukti gambar terlebih dahulu, sebelum merubah status task menjadi completed');
      return;
    }
    
    setSubmitting(true);

    try {
      const taskData = {
        ...formData,
        assigned_to: formData.assigned_to || null
      };

      const { data, error } = await supabase
        .from('tasks')
        .insert([taskData])
        .select(`
          *,
          housing_unit:housing_unit_id(unit_number, status),
          contractor:assigned_to(name),
          photos:task_photos(*)
        `)
        .single();

      if (error) throw error;

      await createNotification({
        title: 'New Task Created',
        message: `Task "${formData.title}" has been created for unit ${data.housing_unit.unit_number}`,
        type: 'task_created',
        link: '/tasks'
      });

      setTasks([data, ...tasks]);
      setIsModalOpen(false);
      setFormData({
        title: '',
        description: '',
        status: 'todo',
        due_date: '',
        housing_unit_id: '',
        assigned_to: null
      });

      // Update housing unit progress when task is created
      if (data.housing_unit_id) {
        await updateHousingUnitProgress(data.housing_unit_id);
      }
    } catch (error: any) {
      setError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteTask = async () => {
    if (!deleteConfirmation) return;

    try {
      setDeleteConfirmation({ ...deleteConfirmation, isDeleting: true });

      const task = tasks.find(t => t.id === deleteConfirmation.taskId);
      if (task?.photos?.length) {
        for (const photo of task.photos) {
          const urlParts = photo.photo_url.split('/');
          const filePath = `${task.id}/${urlParts[urlParts.length - 1]}`;
          
          await supabase.storage
            .from('task-photos')
            .remove([filePath]);
        }
      }

      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', deleteConfirmation.taskId);

      if (error) throw error;

      await createNotification({
        title: 'Task Deleted',
        message: `Task "${deleteConfirmation.taskTitle}" has been deleted`,
        type: 'task_updated',
        link: '/tasks'
      });

      // Store housing_unit_id before removing the task
      const housingUnitId = task?.housing_unit_id;

      setTasks(tasks.filter(task => task.id !== deleteConfirmation.taskId));
      setDeleteConfirmation(null);

      // Update housing unit progress after task deletion
      if (housingUnitId) {
        await updateHousingUnitProgress(housingUnitId);
      }
    } catch (error: any) {
      setError(error.message);
    }
  };

  const updateTaskStatus = async (taskId: string, newStatus: string) => {
    // If trying to set status to 'completed', check if task has photos
    if (newStatus === 'completed') {
      const task = tasks.find(t => t.id === taskId);
      
      // If the task has no photos or empty photos array, show error message
      if (!task?.photos || task.photos.length === 0) {
        // Show validation modal instead of just setting error state
        setValidationModal({
          message: 'Kamu harus mengupload bukti gambar terlebih dahulu, sebelum merubah status task menjadi completed',
          taskId: taskId
        });
        
        // Return early, preventing status update
        return;
      }
    }
    
    try {
      const { data, error } = await supabase
        .from('tasks')
        .update({ status: newStatus })
        .eq('id', taskId)
        .select(`
          *,
          housing_unit:housing_unit_id(unit_number, status),
          contractor:assigned_to(name)
        `)
        .single();

      if (error) throw error;

      // Always update housing unit progress when task status changes
      if (data.housing_unit_id) {
        await updateHousingUnitProgress(data.housing_unit_id);
      }

      await createNotification({
        title: 'Task Status Updated',
        message: `Task "${data.title}" for unit ${data.housing_unit.unit_number} is now ${newStatus}`,
        type: 'task_updated',
        link: '/tasks'
      });

      setTasks(tasks.map(task => 
        task.id === taskId ? { ...task, status: newStatus } : task
      ));
    } catch (error) {
      console.error('Error updating task status:', error);
    }
  };

  const handlePhotoUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset error state
    setError(null);
    
    // Validate required data
    if (!photoUpload?.file) {
      setError('No photo selected for upload');
      return;
    }
    
    if (!photoUpload.taskId) {
      setError('No task selected for this photo');
      return;
    }

    try {
      // Show loading state immediately for better user feedback
      setError('Uploading photo...');
      
      console.log('Starting photo upload for task:', photoUpload.taskId);
      console.log('File:', photoUpload.file.name, 'Size:', Math.round(photoUpload.file.size / 1024), 'KB');
      
      // Stop camera stream if it exists
      if (photoUpload.captureStream) {
        photoUpload.captureStream.getTracks().forEach(track => track.stop());
        console.log('Camera stream stopped');
      }
      
      setPhotoUpload(prev => prev ? { ...prev, isUploading: true, captureStream: null } : null);

      // Create a unique file name with timestamp and random value for better uniqueness
      const fileExt = photoUpload.file.name.split('.').pop() || 'jpg';
      const timestamp = Date.now();
      const randomValue = Math.floor(Math.random() * 10000);
      const fileName = `photo_${timestamp}_${randomValue}.${fileExt}`;
      
      // Use taskId as a subfolder to organize files
      const filePath = `${photoUpload.taskId}/${fileName}`;
      console.log('Uploading to storage path:', filePath);

      // Step 1: Upload to Supabase storage with specific error handling
      setError('Step 1/2: Uploading file to storage...');
      const { data: storageData, error: uploadError } = await supabase.storage
        .from('task-photos')
        .upload(filePath, photoUpload.file, {
          cacheControl: '3600',
          upsert: false // Don't overwrite existing files with the same name
        });

      if (uploadError) {
        console.error('Storage upload error:', uploadError);
        throw new Error(`Storage error: ${uploadError.message}`);
      }
      
      console.log('Storage upload successful:', storageData);

      // Step 2: Get the public URL for the uploaded file
      const { data: { publicUrl } } = supabase.storage
        .from('task-photos')
        .getPublicUrl(filePath);
        
      console.log('Public URL generated:', publicUrl);

      // Step 3: Save photo reference in the database with improved error handling
      setError('Step 2/2: Saving photo details to database...');
      const { data: photo, error: dbError } = await supabase
        .from('task_photos')
        .insert([{
          task_id: photoUpload.taskId,
          photo_url: publicUrl,
          caption: photoUpload.caption || '' // Ensure caption is never null
          // Note: user_email field is not in task_photos table
        }])
        .select()
        .single();

      if (dbError) {
        console.error('Database error when saving photo reference:', dbError);
        
        // If database insert fails, we should clean up the uploaded file
        console.log('Attempting to delete orphaned file from storage due to database error');
        await supabase.storage
          .from('task-photos')
          .remove([filePath])
          .then(({data, error}) => {
            if (error) {
              console.error('Error cleaning up orphaned file:', error);
            } else {
              console.log('Successfully removed orphaned file from storage');
            }
          });
        
        // Throw a specific error for database failure
        throw new Error(`Database error: ${dbError.message}`);
      }
      
      console.log('Photo reference saved to database with ID:', photo.id);

      // Create a notification for the new photo
      const task = tasks.find(t => t.id === photoUpload.taskId);
      if (task?.housing_unit) {
        await createNotification({
          title: 'New Photo Added',
          message: `A new photo has been added to task "${task.title}" for unit ${task.housing_unit.unit_number}`,
          type: 'photo_added',
          link: '/tasks'
        });
        console.log('Notification created for new photo');
      }

      console.log('Adding photo to task in local state, photo:', JSON.stringify(photo));
      
      // Immediately call fetchTasks to refresh all tasks with their photos
      await fetchTasks();
      
      console.log('Task data refreshed with new photos');
      
      // Clear photo upload form
      setPhotoUpload(null);
      
      // Show success message
      setError('Photo uploaded successfully');
      
      // Clear success message after 2 seconds
      setTimeout(() => {
        setError(current => current === 'Photo uploaded successfully' ? null : current);
      }, 2000);

      // Fetch fresh data to ensure UI is consistent with backend
      await fetchTasks();
    } catch (error: any) {
      console.error('Error in handlePhotoUpload:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      // More specific error messages based on error type
      let userMessage = 'Failed to upload photo';
      
      if (errorMessage.includes('Storage error')) {
        userMessage = 'Failed to upload photo to storage. Please check your internet connection and try again.';
      } else if (errorMessage.includes('Database error')) {
        userMessage = 'Photo uploaded but failed to save details. Please contact administrator.';
        // Add suggestion about RLS policy if applicable
        if (errorMessage.includes('permission denied')) {
          userMessage += ' (Database permission error detected)';
        }
      }
      
      setError(`${userMessage}: ${errorMessage}`);
      
      // Clear error message after 8 seconds
      setTimeout(() => {
        setError(current => current === `${userMessage}: ${errorMessage}` ? null : current);
      }, 8000); // Longer timeout for more complex errors
      
      // Reset uploading state but keep the form open for retry
      setPhotoUpload(prev => prev ? { ...prev, isUploading: false } : null);
      
      // Reset uploading state but keep the form open for retry
      setPhotoUpload(prev => prev ? { ...prev, isUploading: false } : null);
    }
  };

  const deletePhoto = async (taskId: string, photo: TaskPhoto) => {
    try {
      setError(null); // Clear any previous errors
      
      // Show loading/progress feedback
      const loadingMessage = `Deleting photo...`;
      setError(loadingMessage); // Use error state to show progress (non-error)
      
      console.log('Starting photo deletion for:', photo);
      console.log('Photo URL:', photo.photo_url);
      
      // Safety check - ensure we have a photo ID
      if (!photo.id) {
        console.error('No photo ID provided for deletion');
        throw new Error('Photo ID missing - cannot delete');
      }

      // First extract the storage path consistently
      const filePath = extractStoragePathFromUrl(photo.photo_url, taskId);
      
      // Safety check - don't proceed if we couldn't determine a file path
      if (!filePath) {
        console.error('Could not determine storage file path from URL:', photo.photo_url);
        throw new Error('Failed to determine file path for deletion');
      }
      
      console.log('Using storage path for deletion:', filePath);
      
      // Find the current task to check its status and remaining photos
      const currentTask = tasks.find(t => t.id === taskId);
      if (!currentTask) {
        throw new Error('Task not found');
      }
      
      // Check how many photos will be left after this deletion
      const willHaveRemainingPhotos = currentTask.photos && 
        currentTask.photos.filter(p => p.id !== photo.id).length > 0;
      
      // Begin transaction - first, delete from database
      console.log('Deleting from database, photo ID:', photo.id);
      const { error: dbError } = await supabase
        .from('task_photos')
        .delete()
        .eq('id', photo.id);

      if (dbError) {
        console.error('Error deleting from database:', dbError);
        throw new Error(`Database error: ${dbError.message}`);
      }
      console.log('Database deletion successful');
      
      // Then, delete from Supabase storage
      console.log('Deleting from storage, path:', filePath);
      const { data: storageData, error: storageError } = await supabase.storage
        .from('task-photos')
        .remove([filePath]);

      console.log('Storage deletion response:', storageData, 'Error:', storageError);
        
      if (storageError) {
        console.error('Error deleting from storage:', storageError);
        // Create a more useful error message but don't throw since DB is already updated
        console.warn('Storage deletion failed but continuing since DB record is removed');
        console.warn('Storage error details:', storageError.message);
      } else {
        console.log('Storage deletion successful');
      }
      
      // Check if we need to update task status (if this was the last photo and task was completed)
      if (!willHaveRemainingPhotos && currentTask.status === 'completed') {
        console.log('No photos remaining and task was completed - changing status to in-progress');
        
        // Update task status in the database
        const { data: updatedTask, error: statusError } = await supabase
          .from('tasks')
          .update({ status: 'in-progress' })
          .eq('id', taskId)
          .select()
          .single();
          
        if (statusError) {
          console.error('Error updating task status:', statusError);
          throw new Error(`Failed to update task status: ${statusError.message}`);
        }
        
        // Create notification about status change
        if (currentTask.housing_unit) {
          await createNotification({
            title: 'Task Status Updated',
            message: `Task "${currentTask.title}" for unit ${currentTask.housing_unit.unit_number} changed to In Progress (photos deleted)`,
            type: 'task_updated',
            link: '/tasks'
          });
        }
        
        // Update housing unit progress
        if (currentTask.housing_unit_id) {
          await updateHousingUnitProgress(currentTask.housing_unit_id);
        }
      }
      
      // Update local state immediately for better UX
      setTasks(tasks.map(task =>
        task.id === taskId
          ? { 
              ...task, 
              photos: task.photos?.filter(p => p.id !== photo.id),
              // If this was the last photo and task was completed, update the status
              status: (!willHaveRemainingPhotos && task.status === 'completed') ? 'in-progress' : task.status
            }
          : task
      ));

      // Close the preview if the deleted photo was being previewed
      if (previewPhoto?.id === photo.id) {
        setPreviewPhoto(null);
      }
      
      // Show success message
      const successMessage = 'Photo deleted successfully';
      setError(successMessage); // Brief success message
      
      // Clear success message after 2 seconds
      setTimeout(() => {
        setError(current => current === successMessage ? null : current);
      }, 2000);
      
      // Fetch fresh task data to ensure UI is in sync with backend
      await fetchTasks();
    } catch (error: unknown) {
      console.error('Error in deletePhoto function:', error);
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      setError(`Failed to delete photo: ${errorMessage}`);
      
      // Revert the optimistic UI update since the operation failed
      await fetchTasks();
      
      // Clear error message after 5 seconds
      setTimeout(() => {
        setError(current => current === `Failed to delete photo: ${errorMessage}` ? null : current);
      }, 5000);
    }
  };
  
  // Helper function to reliably extract storage path from photo URL
  const extractStoragePathFromUrl = (url: string, taskId: string): string => {
    try {
      console.log('Extracting path from URL:', url);
      
      // Clean the URL if it's encoded
      const decodedUrl = decodeURIComponent(url);
      console.log('Decoded URL:', decodedUrl);
      
      // Method 1: Direct extraction using URL parsing
      try {
        const urlObj = new URL(decodedUrl);
        const pathname = urlObj.pathname;
        
        // Look for the 'task-photos/' path segment
        const regex = /\/storage\/v1\/object\/public\/task-photos\/(.*)/;
        const match = pathname.match(regex);
        
        if (match && match[1]) {
          console.log('Method 1: Extracted path using regex:', match[1]);
          return match[1]; // This is the most reliable method when it works
        }
      } catch (e) {
        console.warn('URL parsing failed:', e);
      }
      
      // Method 2: String index-based extraction
      const photosIndex = decodedUrl.indexOf('task-photos/');
      if (photosIndex !== -1) {
        const path = decodedUrl.substring(photosIndex + 'task-photos/'.length);
        console.log('Method 2: Extracted path using string index:', path);
        return path;
      }
      
      // Method 3: Filename extraction with taskId prefix
      const urlParts = decodedUrl.split('/');
      const filename = urlParts[urlParts.length - 1];
      if (filename && filename.includes('.')) { // Basic check that it looks like a filename
        const constructedPath = `${taskId}/${filename}`;
        console.log('Method 3: Constructed path from taskId/filename:', constructedPath);
        return constructedPath;
      }
      
      // Method 4: Extract just the filename from the URL and make a best guess
      // This is a last resort approach
      try {
        // Parse the URL for query parameters
        const questionMarkIndex = decodedUrl.indexOf('?');
        let cleanUrl = decodedUrl;
        if (questionMarkIndex !== -1) {
          cleanUrl = decodedUrl.substring(0, questionMarkIndex);
        }
        
        // Get the last part after final slash
        const lastPartMatch = cleanUrl.match(/[^\/]+$/);
        if (lastPartMatch && lastPartMatch[0]) {
          const filenamePart = lastPartMatch[0];
          if (filenamePart.includes('.')) {
            const bestGuessPath = `${taskId}/${filenamePart}`;
            console.log('Method 4: Last resort filename extraction:', bestGuessPath);
            return bestGuessPath;
          }
        }
      } catch (e) {
        console.warn('Method 4 extraction failed:', e);
      }
      
      // If all methods fail, return empty string
      console.error('Could not extract storage path from URL:', url);
      return '';
    } catch (error) {
      console.error('Error in extractStoragePathFromUrl:', error);
      return ''; // Return empty if all extraction methods fail
    }
  };

  const statusColors = {
    'todo': 'bg-gray-100 text-gray-800',
    'in-progress': 'bg-yellow-100 text-yellow-800',
    'completed': 'bg-green-100 text-green-800',
    'blocked': 'bg-red-100 text-red-800'
  };

  const filteredTasks = tasks
    .filter(task => {
      if (filter === 'all') return true;
      return task.status === filter;
    })
    .filter(task =>
      task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.housing_unit?.unit_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.contractor?.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const isTaskOverdue = (task: Task) => {
    return isAfter(new Date(), new Date(task.due_date)) && task.status !== 'completed';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Tasks</h1>
          <p className="mt-1 text-sm text-gray-500">
            Manage and track tasks for all housing units
          </p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="h-5 w-5 mr-2" />
          Add New Task
        </button>
      </div>

      {/* Add a manual refresh button for users */}
      <div className="p-2 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-between">
        <p className="text-xs text-blue-600">
          {loading ? 'Loading tasks...' : `Loaded ${tasks.length} tasks`}
        </p>
        <button 
          onClick={() => {
            setError(null);
            fetchTasks();
          }}
          className="px-2 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700"
          disabled={loading}
        >
          {loading ? 'Loading...' : 'Refresh Tasks'}
        </button>
      </div>

      {error && (
        <div className={`p-4 border rounded-lg flex items-start ${
          error.startsWith('Deleting photo') ? 'bg-blue-50 border-blue-200' :
          error.startsWith('Photo deleted') ? 'bg-green-50 border-green-200' :
          'bg-red-50 border-red-200'
        }`}>
          {error.startsWith('Deleting photo') ? (
            <Loader2 className="h-5 w-5 text-blue-500 mr-2 flex-shrink-0 mt-0.5 animate-spin" />
          ) : error.startsWith('Photo deleted') ? (
            <CheckCircle2 className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="h-5 w-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
          )}
          <div className="flex-1">
            <h3 className={`text-sm font-medium ${
              error.startsWith('Deleting photo') ? 'text-blue-800' :
              error.startsWith('Photo deleted') ? 'text-green-800' :
              'text-red-800'
            }`}>
              {error.startsWith('Deleting photo') ? 'In Progress' :
               error.startsWith('Photo deleted') ? 'Success' : 'Error'}
            </h3>
            <p className={`text-sm mt-1 ${
              error.startsWith('Deleting photo') ? 'text-blue-700' :
              error.startsWith('Photo deleted') ? 'text-green-700' :
              'text-red-700'
            }`}>{error}</p>
          </div>
          <button
            onClick={() => setError(null)}
            className={`flex-shrink-0 ml-4 ${
              error.startsWith('Deleting photo') ? 'text-blue-500 hover:text-blue-700' :
              error.startsWith('Photo deleted') ? 'text-green-500 hover:text-green-700' :
              'text-red-500 hover:text-red-700'
            }`}
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        <div className="flex-1 relative">
          <input
            type="text"
            placeholder="Search tasks..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        <div className="flex items-center space-x-2 overflow-x-auto">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap ${
              filter === 'all'
                ? 'bg-blue-100 text-blue-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('todo')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap ${
              filter === 'todo'
                ? 'bg-gray-200 text-gray-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Todo
          </button>
          <button
            onClick={() => setFilter('in-progress')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap ${
              filter === 'in-progress'
                ? 'bg-yellow-100 text-yellow-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            In Progress
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap ${
              filter === 'completed'
                ? 'bg-green-100 text-green-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Completed
          </button>
          <button
            onClick={() => setFilter('blocked')}
            className={`px-4 py-2 rounded-lg whitespace-nowrap ${
              filter === 'blocked'
                ? 'bg-red-100 text-red-800'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Blocked
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow ${
                isTaskOverdue(task) ? 'border-l-4 border-red-500' : ''
              }`}
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{task.title}</h3>
                    <p className="text-sm text-gray-500 mt-1">{task.description}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <select
                      value={task.status}
                      onChange={(e) => updateTaskStatus(task.id, e.target.value)}
                      className={`text-xs font-semibold rounded-full px-3 py-1 ${
                        statusColors[task.status as keyof typeof statusColors]
                      }`}
                    >
                      <option value="todo">Todo</option>
                      <option value="in-progress">In Progress</option>
                      <option value="completed">Completed</option>
                      <option value="blocked">Blocked</option>
                    </select>
                    <button
                      onClick={() => setDeleteConfirmation({
                        taskId: task.id,
                        taskTitle: task.title,
                        isDeleting: false
                      })}
                      className="p-1 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  {task.housing_unit && (
                    <div className="flex items-center text-sm">
                      <span className="font-medium text-gray-700">Unit:</span>
                      <span className="ml-2 text-gray-600">{task.housing_unit.unit_number}</span>
                      <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                        task.housing_unit.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : task.housing_unit.status === 'delayed'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {task.housing_unit.status}
                      </span>
                    </div>
                  )}

                  {task.contractor && (
                    <div className="flex items-center text-sm">
                      <span className="font-medium text-gray-700">Assigned to:</span>
                      <span className="ml-2 text-gray-600">{task.contractor.name}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center text-gray-500">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>Due: {format(new Date(task.due_date), 'MMM dd, yyyy')}</span>
                    </div>
                    <div className="flex items-center text-gray-500">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>Created: {format(new Date(task.created_at), 'MMM dd')}</span>
                    </div>
                  </div>

                  {isTaskOverdue(task) && (
                    <div className="flex items-center mt-2 text-sm text-red-600">
                      <AlertTriangle className="h-4 w-4 mr-1" />
                      <span>Overdue</span>
                    </div>
                  )}

                  <div className="mt-4 pt-4 border-t">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="text-sm font-medium text-gray-900">Photos</h4>
                      <button
                        onClick={() => setPhotoUpload({
                          taskId: task.id,
                          file: null,
                          caption: '',
                          isUploading: false,
                          captureMode: 'upload',
                          captureStream: null
                        })}
                        className="flex items-center gap-1.5 px-2.5 py-1.5 bg-blue-500 text-white text-xs rounded-md hover:bg-blue-600 transition-colors shadow-sm font-medium"
                      >
                        <Camera className="h-5 w-5" />
                        <span>Upload Photo</span>
                      </button>
                    </div>
                    {task.photos && task.photos.length > 0 && (
                      <div className="grid grid-cols-3 gap-2">
                        {task.photos.map((photo) => (
                          <div key={photo.id} className="relative group">
                            <img
                              src={photo.photo_url}
                              alt={photo.caption}
                              className="w-full h-20 object-cover rounded-lg"
                            />
                            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-opacity flex items-center justify-center opacity-0 group-hover:opacity-100">
                              <div className="flex gap-2">
                                <button
                                  onClick={() => setPreviewPhoto(photo)}
                                  className="p-1.5 bg-blue-600 text-white rounded-full hover:bg-blue-700"
                                  title="View Photo"
                                >
                                  <Maximize2 className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => deletePhoto(task.id, photo)}
                                  className="p-1.5 bg-red-600 text-white rounded-full hover:bg-red-700"
                                  title="Delete Photo"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                            <div className="absolute bottom-0 left-0 right-0 py-1 px-2 bg-gradient-to-t from-black to-transparent">
                              <div className="flex justify-between items-center">
                                <button 
                                  className="text-white text-xs font-medium hover:underline"
                                  onClick={() => setPreviewPhoto(photo)}
                                >
                                  View
                                </button>
                                <button 
                                  className="text-white text-xs font-medium hover:underline"
                                  onClick={() => deletePhoto(task.id, photo)}
                                >
                                  Delete
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {task.status === 'completed' && (
                <div className="px-6 py-2 bg-green-50 border-t border-green-100">
                  <div className="flex items-center text-sm text-green-700">
                    <CheckCircle2 className="h-4 w-4 mr-1" />
                    <span>Completed on {format(new Date(task.updated_at), 'MMM dd, yyyy')}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Add Task Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Add New Task</h2>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {error && (
              <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Title
                </label>
                <input
                  required
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  placeholder="Enter task title"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows={3}
                  placeholder="Enter task description"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Housing Unit
                </label>
                <select
                  required
                  value={formData.housing_unit_id}
                  onChange={(e) => setFormData({ ...formData, housing_unit_id: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="">Select a unit</option>
                  {housingUnits.map((unit) => (
                    <option key={unit.id} value={unit.id}>
                      {unit.unit_number} ({unit.status})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assigned To
                </label>
                <select
                  value={formData.assigned_to || ''}
                  onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value || null })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="">Select a contractor</option>
                  {contractors.map((contractor) => (
                    <option key={contractor.id} value={contractor.id}>
                      {contractor.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date
                </label>
                <input
                  required
                  type="datetime-local"
                  value={formData.due_date}
                  onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  required
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                  <option value="todo">Todo</option>
                  <option value="in-progress">In Progress</option>
                  <option value="completed">Completed</option>
                  <option value="blocked">Blocked</option>
                </select>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {submitting ? (
                    <div className="flex items-center">
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Adding...
                    </div>
                  ) : (
                    'Add Task'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Photo Upload Modal */}
      {photoUpload && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Add Photo</h2>
              <button
                onClick={() => {
                  if (photoUpload.captureStream) {
                    // Stop all tracks if camera is active
                    photoUpload.captureStream.getTracks().forEach(track => track.stop());
                  }
                  setPhotoUpload(null);
                }}
                className="text-gray-500 hover:text-gray-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="mb-4 flex justify-center gap-4">
              <button
                onClick={() => setPhotoUpload(prev => prev ? { ...prev, captureMode: 'upload', captureStream: null } : null)}
                className={`px-3 py-2 rounded-lg ${photoUpload.captureMode === 'upload' ? 'bg-blue-100 text-blue-700 border-blue-300 border' : 'bg-gray-100 text-gray-700'}`}
              >
                <div className="flex items-center">
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Photo
                </div>
              </button>
              
              <button
                onClick={async () => {
                  try {
                    // Stop any existing stream first
                    if (photoUpload.captureStream) {
                      photoUpload.captureStream.getTracks().forEach(track => track.stop());
                    }
                    
                    // Request camera access - use rear camera by default
                    const stream = await navigator.mediaDevices.getUserMedia({ 
                      video: { 
                        facingMode: "environment" // Use rear camera on mobile devices
                      } 
                    });
                    setPhotoUpload(prev => prev ? { ...prev, captureMode: 'camera', captureStream: stream } : null);
                    
                    // Connect stream to video element when it's ready
                    setTimeout(() => {
                      if (videoRef.current && stream) {
                        videoRef.current.srcObject = stream;
                      }
                    }, 100);
                  } catch (err) {
                    console.error('Error accessing camera:', err);
                    setError('Unable to access camera. Please ensure you have given permission.');
                  }
                }}
                className={`px-3 py-2 rounded-lg ${photoUpload.captureMode === 'camera' ? 'bg-blue-100 text-blue-700 border-blue-300 border' : 'bg-gray-100 text-gray-700'}`}
              >
                <div className="flex items-center">
                  <Camera className="h-4 w-4 mr-2" />
                  Take Photo
                </div>
              </button>
            </div>

            <form onSubmit={handlePhotoUpload} className="space-y-4">
              {photoUpload.captureMode === 'upload' ? (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Photo
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setPhotoUpload(prev => prev ? {
                      ...prev,
                      file: e.target.files?.[0] || null
                    } : null)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="relative border rounded-lg overflow-hidden bg-gray-100 w-full aspect-video flex justify-center items-center">
                    {photoUpload.file && photoUpload.captureMode === 'camera' ? (
                      <div className="relative w-full h-full">
                        <img 
                          src={URL.createObjectURL(photoUpload.file)} 
                          alt="Captured photo" 
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-0 right-0 m-2 bg-green-500 text-white p-2 rounded-lg shadow-lg flex items-center">
                          <CheckCircle2 className="h-4 w-4 mr-1" />
                          <span className="text-sm font-medium">Photo captured!</span>
                        </div>
                      </div>
                    ) : (
                      <video 
                        ref={videoRef} 
                        autoPlay 
                        playsInline 
                        className="w-full h-full object-cover"
                      />
                    )}
                    <canvas 
                      ref={canvasRef} 
                      className="hidden" 
                      width="640" 
                      height="480"
                    />
                  </div>
                  
                  {photoUpload.file && photoUpload.captureMode === 'camera' ? (
                    <div className="flex gap-2 mt-2">
                      <button
                        type="button"
                        onClick={() => {
                          // Reset file to retake photo
                          setPhotoUpload(prev => prev ? {
                            ...prev,
                            file: null
                          } : null);
                        }}
                        className="w-1/2 bg-gray-600 text-white py-2 rounded-lg hover:bg-gray-700 flex items-center justify-center"
                      >
                        <Camera className="h-4 w-4 mr-2" />
                        Retake Photo
                      </button>
                      <button
                        type="button" 
                        onClick={() => {
                          // Keep existing file, just show confirmation
                          // Already have the file in state
                        }}
                        className="w-1/2 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 flex items-center justify-center"
                      >
                        <CheckCircle2 className="h-4 w-4 mr-2" />
                        Use This Photo
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        if (canvasRef.current && videoRef.current) {
                          const canvas = canvasRef.current;
                          const video = videoRef.current;
                          const context = canvas.getContext('2d');
                          
                          if (!context) return;
                          
                          // Set canvas dimensions to match the video
                          canvas.width = video.videoWidth;
                          canvas.height = video.videoHeight;
                          
                          // Draw the current video frame to the canvas
                          context.drawImage(video, 0, 0, canvas.width, canvas.height);
                          
                          // Convert the canvas to a Blob
                          canvas.toBlob((blob) => {
                            if (blob) {
                              // Create a File object from the Blob
                              const file = new File([blob], `camera_${Date.now()}.jpg`, { type: 'image/jpeg' });
                              
                              // Update state with the captured image
                              setPhotoUpload(prev => prev ? {
                                ...prev,
                                file: file
                              } : null);
                            }
                          }, 'image/jpeg');
                        }
                      }}
                      className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 flex items-center justify-center"
                    >
                      <Camera className="h-4 w-4 mr-2" />
                      Capture Photo
                    </button>
                  )}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Caption
                </label>
                <input
                  type="text"
                  value={photoUpload.caption}
                  onChange={(e) => setPhotoUpload(prev => prev ? {
                    ...prev,
                    caption: e.target.value
                  } : null)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  placeholder="Enter a caption for the photo"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    if (photoUpload.captureStream) {
                      // Stop all tracks if camera is active
                      photoUpload.captureStream.getTracks().forEach(track => track.stop());
                    }
                    setPhotoUpload(null);
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!photoUpload.file || photoUpload.isUploading}
                  className="flex items-center px-3 py-1.5 text-sm bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 shadow-sm"
                >
                  {photoUpload.isUploading ? (
                    <div className="flex items-center">
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Uploading...
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <Upload className="h-4 w-4 mr-2" />
                      Upload Photo
                    </div>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Photo Preview Modal */}
      {previewPhoto && (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-[60]">
          <div className="relative max-w-[90vw] max-h-[90vh] w-full">
            <div className="absolute top-4 right-4 flex space-x-3">
              {/* Delete button in the preview */}
              <button
                onClick={async () => {
                  // Show deletion message immediately for feedback
                  setError('Deleting photo from preview...');
                  
                  // Find the corresponding task for this photo
                  const taskWithPhoto = tasks.find(task => 
                    task.photos?.some(p => p.id === previewPhoto.id)
                  );
                  
                  if (taskWithPhoto) {
                    // Close the preview first for better UI feedback
                    setPreviewPhoto(null);
                    // Then delete the photo
                    await deletePhoto(taskWithPhoto.id, previewPhoto);
                  } else {
                    setError('Could not find the task associated with this photo');
                  }
                }}
                className="bg-red-600 text-white p-2 rounded-full hover:bg-red-700 flex items-center justify-center"
                title="Delete Photo"
              >
                <Trash2 className="h-5 w-5" />
              </button>
              
              {/* Close button */}
              <button
                onClick={() => setPreviewPhoto(null)}
                className="bg-gray-800 text-white p-2 rounded-full hover:bg-gray-700 flex items-center justify-center"
                title="Close"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="flex items-center justify-center h-full">
              <img
                src={previewPhoto.photo_url}
                alt={previewPhoto.caption}
                className="max-w-full max-h-[80vh] object-contain rounded-lg shadow-2xl"
              />
            </div>
            
            {previewPhoto.caption && (
              <div className="mt-4 bg-gray-800 bg-opacity-80 rounded-lg px-4 py-3 text-center text-white">
                <p className="font-medium">{previewPhoto.caption}</p>
                <p className="text-sm text-gray-300 mt-1">
                  Uploaded on {new Date(previewPhoto.created_at).toLocaleDateString()} at {new Date(previewPhoto.created_at).toLocaleTimeString()}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Validation Error Modal */}
      {validationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-red-800">
                  Validation Error
                </h3>
                <div className="mt-2">
                  <p className="text-sm text-gray-700">
                    {validationModal.message}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-between items-center">
              <button
                type="button"
                onClick={() => setValidationModal(null)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Dismiss
              </button>
              
              <button
                type="button"
                onClick={() => {
                  // Open photo upload modal for this task
                  setPhotoUpload({
                    taskId: validationModal.taskId,
                    file: null,
                    caption: '',
                    isUploading: false,
                    captureMode: 'upload',
                    captureStream: null
                  });
                  setValidationModal(null); // Close the validation modal
                }}
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <Camera className="h-4 w-4 mr-2" />
                Add Photo Now
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {deleteConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex items-start">
              <div className="flex-shrink-0">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-3">
                <h3 className="text-lg font-medium text-gray-900">
                  Delete Task
                </h3>
                <div className="mt-2">
                  <p className="text-sm text-gray-500">
                    Are you sure you want to delete "{deleteConfirmation.taskTitle}"? This action cannot be undone and will also delete all associated photos.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-3">
              <button
                type="button"
                onClick={() => setDeleteConfirmation(null)}
                disabled={deleteConfirmation.isDeleting}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteTask}
                disabled={deleteConfirmation.isDeleting}
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-red-600 border border-transparent rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                {deleteConfirmation.isDeleting ? (
                  <div className="flex items-center">
                    <Loader2 className="animate-spin h-4 w-4 mr-2" />
                    Deleting...
                  </div>
                ) : (
                  'Delete Task'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Tasks;
