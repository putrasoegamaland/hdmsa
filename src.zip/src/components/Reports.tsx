import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Download, Filter, Calendar, Search, Loader2, BarChart2, FileText } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { format, subMonths, startOfMonth, endOfMonth } from 'date-fns';
import { calculateProgress } from '../lib/progressCalculation';
import { downloadCSV } from '../lib/exportUtils';
import { createNotification } from '../lib/notifications';

interface ContractorPerformance {
  name: string;
  onTime: number;
  delayed: number;
  total: number;
}

interface UnitStatusData {
  name: string;
  completed: number;
  inProgress: number;
  delayed: number;
}

const Reports = () => {
  const [loading, setLoading] = useState(true);
  const [units, setUnits] = useState([]);
  const [contractorPerformance, setContractorPerformance] = useState<ContractorPerformance[]>([]);
  const [unitStatusData, setUnitStatusData] = useState<UnitStatusData[]>([]);
  const [stats, setStats] = useState({
    totalUnits: 0,
    activeContractors: 0,
    completionRate: 0,
    delayedUnits: 0
  });
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'reports'>('overview');
  const [dateRange, setDateRange] = useState('last30');
  const [reportType, setReportType] = useState('progress');
  const [searchTerm, setSearchTerm] = useState('');
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);

      // Fetch housing units with their tasks and contractors
      const { data: housingUnits, error: unitsError } = await supabase
        .from('housing_units')
        .select(`
          id,
          unit_number,
          project_id,
          status,
          payment_phase,
          buyer_phase,
          target_handover_date,
          actual_handover_date,
          created_at,
          updated_at,
          tasks (
            id,
            status,
            due_date
          ),
          project:project_id(title),
          progress:housing_unit_progress(
            progress_percentage,
            report_date
          ),
          housing_unit_contractors (
            contractor:contractor_id (
              id,
              name,
              email,
              status
            )
          )
        `);

      if (unitsError) throw unitsError;
      
      // Set the units state for use in housing unit reports and analytics
      setUnits(housingUnits || []);

      // Calculate housing unit statistics
      const totalUnits = housingUnits?.length || 0;
      const delayedUnits = housingUnits?.filter(unit => unit.status === 'delayed').length || 0;
      const completedUnits = housingUnits?.filter(unit => unit.status === 'completed').length || 0;
      const completionRate = totalUnits > 0 ? (completedUnits / totalUnits) * 100 : 0;

      // Get unique active contractors
      const uniqueContractors = new Set();
      housingUnits?.forEach(unit => {
        unit.housing_unit_contractors?.forEach(huc => {
          if (huc.contractor?.status === 'Active') {
            uniqueContractors.add(huc.contractor.id);
          }
        });
      });

      // Calculate contractor performance
      const contractorStats = new Map();
      housingUnits?.forEach(unit => {
        unit.housing_unit_contractors?.forEach(huc => {
          if (!huc.contractor) return;

          const contractorId = huc.contractor.id;
          if (!contractorStats.has(contractorId)) {
            contractorStats.set(contractorId, {
              name: huc.contractor.name,
              onTime: 0,
              delayed: 0,
              total: 0
            });
          }

          const stats = contractorStats.get(contractorId);
          stats.total++;
          if (unit.status === 'delayed') {
            stats.delayed++;
          } else {
            stats.onTime++;
          }
        });
      });

      // Calculate monthly unit status data for the last 5 months
      const monthlyData: UnitStatusData[] = [];
      for (let i = 4; i >= 0; i--) {
        const monthStart = startOfMonth(subMonths(new Date(), i));
        const monthEnd = endOfMonth(subMonths(new Date(), i));
        
        const monthUnits = housingUnits?.filter(unit => {
          const updateDate = new Date(unit.updated_at);
          return updateDate >= monthStart && updateDate <= monthEnd;
        });

        monthlyData.push({
          name: format(monthStart, 'MMM'),
          completed: monthUnits?.filter(u => u.status === 'completed').length || 0,
          inProgress: monthUnits?.filter(u => u.status === 'on-schedule').length || 0,
          delayed: monthUnits?.filter(u => u.status === 'delayed').length || 0
        });
      }

      setStats({
        totalUnits,
        activeContractors: uniqueContractors.size,
        completionRate,
        delayedUnits
      });

      setContractorPerformance(Array.from(contractorStats.values()));
      setUnitStatusData(monthlyData);
    } catch (error) {
      console.error('Error fetching report data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Generate Housing Unit Reports
  const generateUnitReport = async () => {
    if (units.filter(unit => unit.unit_number.toLowerCase().includes(searchTerm.toLowerCase())).length === 0) {
      await createNotification({
        title: 'Export Failed',
        message: 'No data available to export',
        type: 'unit_added',
        link: '/reports'
      });
      return;
    }

    try {
      setExporting(true);

      // Prepare report data based on type
      let reportData;
      let filename;

      const filteredUnits = units.filter(unit =>
        unit.unit_number.toLowerCase().includes(searchTerm.toLowerCase())
      );

      switch (reportType) {
        case 'progress':
          reportData = filteredUnits.map(unit => ({
            'Unit Number': unit.unit_number,
            'Status': unit.status,
            'Progress': `${calculateProgress(unit)}%`,
            'Last Updated': format(new Date(unit.updated_at), 'yyyy-MM-dd'),
            'Date Added': format(new Date(unit.created_at), 'yyyy-MM-dd'),
            'Contractor': unit.housing_unit_contractors?.[0]?.contractor?.name || 'Unassigned'
          }));
          filename = 'housing-units-progress-report';
          break;

        case 'status':
          reportData = filteredUnits.map(unit => ({
            'Unit Number': unit.unit_number,
            'Status': unit.status,
            'Progress': `${calculateProgress(unit)}%`,
            'Last Updated': format(new Date(unit.updated_at), 'yyyy-MM-dd'),
            'Date Added': format(new Date(unit.created_at), 'yyyy-MM-dd'),
            'Contractor': unit.housing_unit_contractors?.[0]?.contractor?.name || 'Unassigned'
          }));
          filename = 'housing-units-status-report';
          break;

        case 'contractors':
          reportData = filteredUnits.map(unit => ({
            'Unit Number': unit.unit_number,
            'Status': unit.status,
            'Progress': `${calculateProgress(unit)}%`,
            'Last Updated': format(new Date(unit.updated_at), 'yyyy-MM-dd'),
            'Date Added': format(new Date(unit.created_at), 'yyyy-MM-dd'),
            'Contractor': unit.housing_unit_contractors?.[0]?.contractor?.name || 'Unassigned'
          }));
          filename = 'housing-units-contractor-report';
          break;

        case 'full':
          reportData = filteredUnits
            .map(unit => ({
              'Unit Number': unit.unit_number,
              'Status': unit.status,
              'Progress': `${calculateProgress(unit)}%`,
              'Payment Phase': unit.payment_phase || 'Not set',
              'Buyer Phase': unit.buyer_phase || 'Not set',
              'Target Handover': unit.target_handover_date ? format(new Date(unit.target_handover_date), 'yyyy-MM-dd') : 'Not set',
              'Actual Handover': unit.actual_handover_date ? format(new Date(unit.actual_handover_date), 'yyyy-MM-dd') : 'Not set',
              'Last Updated': format(new Date(unit.updated_at), 'yyyy-MM-dd'),
              'Date Added': format(new Date(unit.created_at), 'yyyy-MM-dd'),
              'Contractor': unit.housing_unit_contractors?.[0]?.contractor?.name || 'Unassigned'
            }));
          filename = 'housing-units-full-report';
          break;
          
        case 'payment':
          reportData = filteredUnits.map(unit => ({
            'Unit Number': unit.unit_number,
            'Status': unit.status,
            'Payment Phase': unit.payment_phase || 'Not set',
            'Progress': `${calculateProgress(unit)}%`,
            'Last Updated': format(new Date(unit.updated_at), 'yyyy-MM-dd'),
            'Date Added': format(new Date(unit.created_at), 'yyyy-MM-dd')
          }));
          filename = 'housing-units-payment-phase-report';
          break;


        default:
          throw new Error('Invalid report type');
      }

      if (reportData.length === 0) {
        throw new Error('No data available for the selected report type');
      }

      // Add timestamp to filename
      filename = `${filename}-${format(new Date(), 'yyyy-MM-dd')}`;

      // Download the CSV
      downloadCSV(reportData, filename);

      // Create success notification
      await createNotification({
        title: 'Report Generated',
        message: `${reportType.charAt(0).toUpperCase() + reportType.slice(1)} report has been generated successfully`,
        type: 'unit_added',
        link: '/reports'
      });

    } catch (err: any) {
      console.error('Error generating report:', err);
      
      // Create error notification
      await createNotification({
        title: 'Report Generation Failed',
        message: err.message || 'There was an error generating the report. Please try again.',
        type: 'unit_added',
        link: '/reports'
      });
    } finally {
      setExporting(false);
    }
  };

  // Render Housing Unit Analytics component
  const renderAnalytics = () => {
    // Calculate status distribution
    const statusData = units.reduce((acc: any, unit: any) => {
      acc[unit.status] = (acc[unit.status] || 0) + 1;
      return acc;
    }, {});
  
    const statusChartData = Object.entries(statusData).map(([status, count]) => ({
      name: status,
      value: count
    }));
  
    // Calculate payment phase distribution
    const paymentData = units.reduce((acc: any, unit: any) => {
      const phase = unit.payment_phase || 'Not set';
      acc[phase] = (acc[phase] || 0) + 1;
      return acc;
    }, {});
  
    const paymentChartData = Object.entries(paymentData).map(([phase, count]) => ({
      name: phase,
      value: count
    }));
  
    // Calculate progress distribution
    const progressData = units.reduce((acc: any[], unit: any) => {
      const progressRange = Math.floor(calculateProgress(unit) / 20) * 20;
      const existingRange = acc.find(item => item.range === progressRange);
      if (existingRange) {
        existingRange.count++;
      } else {
        acc.push({ range: progressRange, count: 1 });
      }
      return acc;
    }, []).sort((a, b) => a.range - b.range);
  
    // Generate monthly completion trend
    const monthlyData = Array.from({ length: 6 }, (_, i) => {
      const month = subMonths(new Date(), i);
      return {
        month: format(month, 'MMM yyyy'),
        completed: units.filter(unit => 
          unit.status === 'completed' && 
          new Date(unit.updated_at).getMonth() === month.getMonth()
        ).length
      };
    }).reverse();
  
    const COLORS = ['#3B82F6', '#34D399', '#F87171', '#A78BFA', '#FB923C', '#94A3B8'];
  
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Status Distribution */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-lg font-medium mb-4">Status Distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={statusChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {statusChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {statusChartData.map((entry: any, index) => (
                <div key={entry.name} className="flex items-center">
                  <div
                    className="w-3 h-3 rounded-full mr-2"
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span className="text-sm text-gray-600">
                    {entry.name}: {entry.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Payment Phase Distribution */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-lg font-medium mb-4">Payment Phase Distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={paymentChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {paymentChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[(index + 3) % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {paymentChartData.map((entry: any, index) => (
                <div key={entry.name} className="flex items-center">
                  <div
                    className="w-3 h-3 rounded-full mr-2"
                    style={{ backgroundColor: COLORS[(index + 3) % COLORS.length] }}
                  />
                  <span className="text-sm text-gray-600 truncate">
                    {entry.name}: {entry.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Progress Distribution */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-lg font-medium mb-4">Progress Distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={progressData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis
                    dataKey="range"
                    tickFormatter={(value) => `${value}%`}
                  />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3B82F6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
  
          {/* Monthly Completion Trend */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h3 className="text-lg font-medium mb-4">Monthly Completions</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="completed"
                    stroke="#3B82F6"
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
  
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h4 className="text-sm font-medium text-gray-500">Total Units</h4>
            <p className="mt-2 text-3xl font-semibold">{units.length}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h4 className="text-sm font-medium text-gray-500">Completed</h4>
            <p className="mt-2 text-3xl font-semibold text-green-600">
              {units.filter(unit => unit.status === 'completed').length}
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h4 className="text-sm font-medium text-gray-500">In Progress</h4>
            <p className="mt-2 text-3xl font-semibold text-blue-600">
              {units.filter(unit => unit.status === 'in-progress' || unit.status === 'on-schedule').length}
            </p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h4 className="text-sm font-medium text-gray-500">Delayed</h4>
            <p className="mt-2 text-3xl font-semibold text-red-600">
              {units.filter(unit => unit.status === 'delayed').length}
            </p>
          </div>
        </div>
      </div>
    );
  };

  // Render Housing Unit Reports component
  const renderUnitReports = () => {
    const filteredUnits = units.filter(unit =>
      unit.unit_number.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
      <div className="space-y-6">
        {/* Report Controls */}
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date Range
              </label>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
              >
                <option value="last7">Last 7 Days</option>
                <option value="last30">Last 30 Days</option>
                <option value="last90">Last 90 Days</option>
                <option value="custom">Custom Range</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Report Type
              </label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2"
              >
                <option value="progress">Progress Report</option>
                <option value="status">Status Report</option>
                <option value="contractors">Contractor Report</option>
                <option value="full">Full Report</option>
                <option value="payment">Payment Phase Report</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Search Units
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by unit number..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>

            <div className="flex items-end">
              <button
                onClick={generateUnitReport}
                disabled={exporting || filteredUnits.length === 0}
                className="w-full flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                {exporting ? (
                  <>
                    <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Download className="h-5 w-5 mr-2" />
                    Export Report
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Report Preview */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-medium">Report Preview</h2>
            <p className="mt-1 text-sm text-gray-500">
              {filteredUnits.length} units found
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Unit Number
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Progress
                  </th>
                  {reportType === 'full' && (
                    <>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Payment Phase
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Buyer Phase
                      </th>
                    </>
                  )}
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Last Updated
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date Added
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    {reportType === 'payment' ? 'Payment Phase' : 'Contractor'}
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredUnits.map((unit) => (
                    <tr key={unit.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {unit.unit_number}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          unit.status === 'completed'
                            ? 'bg-green-100 text-green-800'
                            : unit.status === 'delayed'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {unit.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                            <div
                              className="bg-blue-600 h-2 rounded-full"
                              style={{ width: `${calculateProgress(unit)}%` }}
                            />
                          </div>
                          <span className="text-sm text-gray-500">
                            {calculateProgress(unit)}%
                          </span>
                        </div>
                      </td>
                      {reportType === 'full' && (
                        <>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800`}>
                              {unit.payment_phase || 'Not set'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800`}>
                              {unit.buyer_phase || 'Not set'}
                            </span>
                          </td>
                        </>
                      )}
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {format(new Date(unit.updated_at), 'MMM dd, yyyy')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {format(new Date(unit.created_at), 'MMM dd, yyyy')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {reportType === 'payment' ? (
                          <span className={`px-2 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800`}>
                            {unit.payment_phase || 'Not set'}
                          </span>
                        ) : (
                          unit.housing_unit_contractors?.[0]?.contractor?.name || 'Unassigned'
                        )}
                      </td>
                    </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Reports & Analytics</h1>
        <div className="flex space-x-4">
          <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="h-5 w-5 mr-2" />
            Filter
          </button>
          <button 
            onClick={activeTab === 'reports' ? generateUnitReport : () => {}}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Download className="h-5 w-5 mr-2" />
            Export Report
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'overview'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'analytics'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'reports'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Report
          </button>
        </nav>
      </div>

      {activeTab === 'overview' && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Unit Status Chart */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Unit Status Overview</h2>
              {loading ? (
                <div className="h-80 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={unitStatusData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="completed" fill="#16A34A" name="Completed" />
                      <Bar dataKey="inProgress" fill="#F59E0B" name="In Progress" />
                      <Bar dataKey="delayed" fill="#DC2626" name="Delayed" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* Contractor Performance Chart */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Contractor Performance</h2>
              {loading ? (
                <div className="h-80 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                <>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={contractorPerformance} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="name" type="category" width={100} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="onTime" fill="#16A34A" name="On Time" stackId="stack" />
                        <Bar dataKey="delayed" fill="#DC2626" name="Delayed" stackId="stack" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-4 space-y-2">
                    {contractorPerformance.map((contractor) => (
                      <div key={contractor.name} className="text-sm text-gray-600">
                        <span className="font-medium">{contractor.name}:</span>{' '}
                        {contractor.total} tasks ({Math.round((contractor.onTime / contractor.total) * 100)}% on time)
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Payment Phase Status Chart */}
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment Phase Status</h2>
              {loading ? (
                <div className="h-80 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                <>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={units.reduce((acc, unit) => {
                            const phase = unit.payment_phase || 'Not set';
                            const found = acc.find(item => item.name === phase);
                            if (found) {
                              found.value++;
                            } else {
                              acc.push({ name: phase, value: 1 });
                            }
                            return acc;
                          }, [])}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={2}
                          dataKey="value"
                        >
                          {units.reduce((acc, unit) => {
                            const phase = unit.payment_phase || 'Not set';
                            if (!acc.includes(phase)) acc.push(phase);
                            return acc;
                          }, []).map((_, index) => (
                            <Cell key={`cell-${index}`} fill={['#16A34A', '#F59E0B', '#DC2626', '#3B82F6', '#A78BFA', '#FB923C'][index % 6]} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </>
              )}
            </div>
          </div>



          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-sm font-medium text-gray-500">Total Units</h3>
              <p className="mt-2 text-3xl font-semibold text-gray-900">{stats.totalUnits}</p>
              <p className="mt-1 text-sm text-green-600">Updated in real-time</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-sm font-medium text-gray-500">Completion Rate</h3>
              <p className="mt-2 text-3xl font-semibold text-gray-900">{Math.round(stats.completionRate)}%</p>
              <p className="mt-1 text-sm text-green-600">Based on completed units</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-sm font-medium text-gray-500">Active Contractors</h3>
              <p className="mt-2 text-3xl font-semibold text-gray-900">{stats.activeContractors}</p>
              <p className="mt-1 text-sm text-blue-600">Currently assigned</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h3 className="text-sm font-medium text-gray-500">Delayed Units</h3>
              <p className="mt-2 text-3xl font-semibold text-gray-900">{stats.delayedUnits}</p>
              <p className="mt-1 text-sm text-red-600">Needs attention</p>
            </div>
          </div>
        </>
      )}

      {activeTab === 'analytics' && renderAnalytics()}
      {activeTab === 'reports' && renderUnitReports()}
    </div>
  );
};

export default Reports;