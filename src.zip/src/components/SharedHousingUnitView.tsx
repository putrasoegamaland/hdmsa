import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { format, formatDistanceToNow } from 'date-fns';
import { Loader2, CheckCircle2, Calendar, BarChart2, Camera, Home } from 'lucide-react';

interface HousingUnit {
  id: string;
  unit_number: string;
  status: string;
  target_handover_date: string;
  actual_handover_date: string | null;
  payment_phase: string;
}

interface ProgressReport {
  id: string;
  progress_percentage: number;
  report_date: string;
  description: string;
}

interface Photo {
  id: string;
  photo_url: string;
  caption: string;
  created_at: string;
}

interface Task {
  id: string;
  title: string;
  status: string;
}

const SharedHousingUnitView: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  const [unit, setUnit] = useState<HousingUnit | null>(null);
  const [progressReports, setProgressReports] = useState<ProgressReport[]>([]);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [previewPhoto, setPreviewPhoto] = useState<Photo | null>(null);
  const [shareDetails, setShareDetails] = useState<{ created_at: string, expires_at: string | null } | null>(null);

  useEffect(() => {
    if (token) {
      fetchSharedUnitDetails();
    }
  }, [token]);

  const fetchSharedUnitDetails = async () => {
    try {
      setLoading(true);
      setError(null);

      // Step 1: Validate the share token and get the housing unit ID
      const { data: shareData, error: shareError } = await supabase
        .from('housing_unit_shares_0pr47')
        .select('housing_unit_id, created_at, expires_at')
        .eq('share_token', token)
        .eq('is_active', true)
        .single();

      if (shareError) throw new Error('Invalid or expired share link');
      if (!shareData) throw new Error('Share link not found');
      
      // Check if the share link has expired
      if (shareData.expires_at && new Date(shareData.expires_at) < new Date()) {
        throw new Error('This share link has expired');
      }

      setShareDetails({
        created_at: shareData.created_at,
        expires_at: shareData.expires_at
      });

      const unitId = shareData.housing_unit_id;

      // Step 2: Fetch the housing unit details
      const { data: unitData, error: unitError } = await supabase
        .from('housing_units')
        .select('*')
        .eq('id', unitId)
        .single();

      if (unitError) throw unitError;
      setUnit(unitData);

      // Step 3: Fetch progress reports
      const { data: progressData, error: progressError } = await supabase
        .from('housing_unit_progress')
        .select('*')
        .eq('housing_unit_id', unitId)
        .order('report_date', { ascending: false });

      if (progressError) throw progressError;
      setProgressReports(progressData || []);

      // Step 4: Fetch tasks
      const { data: taskData, error: taskError } = await supabase
        .from('tasks')
        .select('*')
        .eq('housing_unit_id', unitId)
        .order('created_at', { ascending: true });

      if (taskError) throw taskError;
      setTasks(taskData || []);

      // Step 5: Fetch photos
      const { data: photoData, error: photoError } = await supabase
        .from('housing_unit_photos')
        .select('*')
        .eq('housing_unit_id', unitId)
        .order('created_at', { ascending: false });

      if (photoError) throw photoError;
      setPhotos(photoData || []);

    } catch (err: any) {
      console.error('Error fetching shared unit details:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string | null | undefined): string => {
    if (!dateString) return 'Not set';
    const date = new Date(dateString);
    return format(date, 'MMM dd, yyyy');
  };

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <h2 className="text-lg font-medium text-gray-900">Loading unit details...</h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-gray-50 p-4">
        <div className="max-w-md w-full bg-white p-6 rounded-lg shadow-lg text-center">
          <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-red-100 mb-4">
            <svg className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h2 className="text-lg font-medium text-gray-900 mb-2">Error</h2>
          <p className="text-gray-500">{error}</p>
        </div>
      </div>
    );
  }

  if (!unit) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-lg font-medium text-gray-900">Unit not found</h2>
        </div>
      </div>
    );
  }

  const currentProgress = progressReports.length > 0 ? progressReports[0].progress_percentage : 0;
  const completedTasks = tasks.filter(task => task.status === 'completed');
  
  return (
    <>
      <div className="bg-white min-h-screen">
        {/* Header */}
        <header className="bg-blue-600 text-white">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center">
              <Home className="h-6 w-6 mr-2" />
              <h1 className="text-2xl font-bold">Housing Unit Progress</h1>
            </div>
            <div className="mt-1 text-blue-100">
              Unit {unit.unit_number} • Shared View
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-8 max-w-3xl">
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h2 className="text-xl font-bold mb-1">Unit {unit.unit_number}</h2>
                <p className="text-gray-500">Status: <span className="text-gray-700 font-medium">{unit.status}</span></p>
              </div>
              
              {shareDetails && (
                <div className="text-xs text-gray-500">
                  <p>Shared: {formatDistanceToNow(new Date(shareDetails.created_at), { addSuffix: true })}</p>
                  {shareDetails.expires_at && (
                    <p>Expires: {formatDate(shareDetails.expires_at)}</p>
                  )}
                </div>
              )}
            </div>
            
            <div className="border-t pt-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Target Handover</h3>
                  <p className="mt-1">{formatDate(unit.target_handover_date)}</p>
                </div>
                {unit.actual_handover_date && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Actual Handover</h3>
                    <p className="mt-1">{formatDate(unit.actual_handover_date)}</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Progress Section */}
          <section className="mb-10">
            <div className="flex items-center mb-4">
              <BarChart2 className="h-5 w-5 text-blue-600 mr-2" />
              <h2 className="text-lg font-semibold">Construction Progress</h2>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <div className="mb-4">
                <div className="flex justify-between mb-1">
                  <p className="font-medium">Overall Progress</p>
                  <p className="text-blue-600 font-bold">{currentProgress}%</p>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className="bg-blue-600 h-2.5 rounded-full"
                    style={{ width: `${currentProgress}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="mt-6 space-y-4">
                <h3 className="font-medium mb-2">Latest Updates</h3>
                {progressReports.slice(0, 3).map((report) => (
                  <div key={report.id} className="border rounded-lg p-4 bg-gray-50">
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{report.progress_percentage}% Complete</span>
                      <div className="flex items-center text-sm text-gray-500">
                        <Calendar className="h-3.5 w-3.5 mr-1" />
                        {formatDate(report.report_date)}
                      </div>
                    </div>
                    <p className="text-gray-600">{report.description}</p>
                  </div>
                ))}
                
                {progressReports.length === 0 && (
                  <p className="text-center py-4 text-gray-500">
                    No progress reports available yet
                  </p>
                )}
              </div>
            </div>
          </section>

          {/* Completed Tasks Section */}
          <section className="mb-10">
            <div className="flex items-center mb-4">
              <CheckCircle2 className="h-5 w-5 text-blue-600 mr-2" />
              <h2 className="text-lg font-semibold">Completed Tasks</h2>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <p className="text-sm text-gray-600 mb-4">
                {completedTasks.length} of {tasks.length} tasks completed
                ({tasks.length > 0 ? Math.round((completedTasks.length / tasks.length) * 100) : 0}%)
              </p>
              
              <div className="space-y-3">
                {completedTasks.map(task => (
                  <div key={task.id} className="flex items-start">
                    <div className="mt-0.5">
                      <CheckCircle2 className="h-5 w-5 text-green-500 mr-2" />
                    </div>
                    <div>
                      <p className="font-medium">{task.title}</p>
                    </div>
                  </div>
                ))}
                
                {completedTasks.length === 0 && (
                  <p className="text-center py-4 text-gray-500">
                    No tasks have been completed yet
                  </p>
                )}
              </div>
            </div>
          </section>

          {/* Photos Section */}
          <section className="mb-10">
            <div className="flex items-center mb-4">
              <Camera className="h-5 w-5 text-blue-600 mr-2" />
              <h2 className="text-lg font-semibold">Construction Photos</h2>
            </div>
            
            <div className="bg-white rounded-lg shadow-sm border p-6">
              {photos.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  {photos.map((photo) => (
                    <div 
                      key={photo.id} 
                      className="aspect-square relative rounded-lg overflow-hidden cursor-pointer"
                      onClick={() => setPreviewPhoto(photo)}
                    >
                      <img
                        src={photo.photo_url}
                        alt={photo.caption || `Photo of unit ${unit.unit_number}`}
                        className="w-full h-full object-cover"
                      />
                      {photo.caption && (
                        <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-1 text-xs">
                          {photo.caption}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center py-8 text-gray-500">
                  No photos available yet
                </p>
              )}
            </div>
          </section>
          
          <div className="text-center text-xs text-gray-500 mt-12 mb-6">
            This information is shared securely with you by the construction supervisor.
          </div>
        </main>
      </div>

      {/* Photo Preview Modal */}
      {previewPhoto && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-[60]"
          onClick={() => setPreviewPhoto(null)}
        >
          <div className="relative max-w-[90vw] max-h-[90vh]" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => setPreviewPhoto(null)}
              className="absolute top-4 right-4 text-white hover:text-gray-300"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            <img
              src={previewPhoto.photo_url}
              alt={previewPhoto.caption}
              className="max-w-full max-h-[90vh] object-contain"
            />
            {previewPhoto.caption && (
              <div className="absolute bottom-4 left-0 right-0 text-center text-white bg-black bg-opacity-50 py-2">
                {previewPhoto.caption}
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default SharedHousingUnitView;