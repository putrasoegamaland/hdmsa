// storage-policies.js
import { createClient } from '@supabase/supabase-js';

/**
 * Script to apply Row Level Security (RLS) policies to the task-photos storage bucket.
 * This ensures photos can be uploaded by authenticated users and accessed by appropriate users.
 */

// Supabase connection details
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

/**
 * Apply storage bucket RLS policies
 * @returns {Promise<Object>} Result object with success and message properties
 */
export const applyStoragePolicies = async () => {
  try {
    // Check if user is authenticated
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError || !user) {
      console.error('Authentication required to manage storage policies');
      return { success: false, message: 'Authentication required' };
    }
    
    // Check if user has admin rights (optional, can be implemented based on your app's requirements)
    // This is just a placeholder check - implement appropriate authorization checks for your app
    if (!user.email?.endsWith('@youradmindomain.com')) {
      console.warn('User does not have admin permissions to modify storage policies');
      // Continue anyway for this diagnostic script
    }

    console.log('Checking task-photos bucket existence...');
    
    // Test uploading a small file to verify permissions
    const testBlob = new Blob(['test'], { type: 'text/plain' });
    const testFile = new File([testBlob], 'permission_test.txt');
    
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('task-photos')
      .upload(`test/permission_test_${Date.now()}.txt`, testFile, {
        cacheControl: '3600',
        upsert: false
      });
    
    if (uploadError) {
      console.error('Storage bucket access error:', uploadError);
      
      if (uploadError.message?.includes('bucket') && uploadError.message?.includes('not found')) {
        console.log('Creating task-photos bucket...');
        
        // Attempt to create bucket (requires admin privileges)
        const { data: bucketData, error: bucketError } = await supabase.storage.createBucket('task-photos', {
          public: false, // Make it private
          allowedMimeTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], // Restrict to images
          fileSizeLimit: 5 * 1024 * 1024 // 5MB limit
        });
        
        if (bucketError) {
          console.error('Failed to create bucket:', bucketError);
          return { success: false, message: 'Failed to create storage bucket: ' + bucketError.message };
        }
        
        console.log('Bucket created successfully!');
      } else {
        return { success: false, message: 'Storage access error: ' + uploadError.message };
      }
    } else {
      console.log('Bucket exists and permissions are working!');
      
      // Clean up test file
      const { error: deleteError } = await supabase.storage
        .from('task-photos')
        .remove([uploadData.path]);
      
      if (deleteError) {
        console.warn('Could not clean up test file:', deleteError);
      }
    }
    
    return { 
      success: true, 
      message: 'Storage policies diagnostic completed successfully. Bucket is accessible for uploads.'
    };
  } catch (error) {
    console.error('Unexpected error while managing storage policies:', error);
    return { 
      success: false, 
      message: 'Unexpected error: ' + (error.message || String(error))
    };
  }
};

/**
 * Test storage access for the current user
 * @returns {Promise<Object>} Test result with user, upload and access information
 */
export const testStorageAccess = async () => {
  // Get current authenticated user
  const { data: { user }, error: userError } = await supabase.auth.getUser();
  
  if (userError || !user) {
    return { 
      success: false, 
      authenticated: false, 
      message: 'User not authenticated. Please log in to upload files.'
    };
  }
  
  // Create a small test image (1x1 pixel)
  const canvas = document.createElement('canvas');
  canvas.width = 1;
  canvas.height = 1;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'red';
  ctx.fillRect(0, 0, 1, 1);
  
  // Convert canvas to blob
  return new Promise(resolve => {
    canvas.toBlob(async (blob) => {
      if (!blob) {
        resolve({ 
          success: false, 
          authenticated: true,
          message: 'Failed to create test image'
        });
        return;
      }
      
      const testFile = new File([blob], `test_${Date.now()}.png`, { type: 'image/png' });
      const filePath = `test/${user.id}/${testFile.name}`;
      
      try {
        // Test upload
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('task-photos')
          .upload(filePath, testFile, {
            cacheControl: '3600',
            upsert: false
          });
        
        if (uploadError) {
          resolve({ 
            success: false, 
            authenticated: true,
            message: 'Upload failed: ' + uploadError.message,
            error: uploadError
          });
          return;
        }
        
        // Get URL for uploaded file
        const { data: { publicUrl } } = supabase.storage
          .from('task-photos')
          .getPublicUrl(filePath);
        
        // Try to access the file
        let accessSuccess = false;
        try {
          const response = await fetch(publicUrl, { method: 'HEAD' });
          accessSuccess = response.ok;
        } catch (e) {
          console.warn('Error testing file access:', e);
        }
        
        // Clean up test file
        await supabase.storage.from('task-photos').remove([filePath]);
        
        resolve({ 
          success: true, 
          authenticated: true,
          user: { 
            id: user.id,
            email: user.email 
          },
          uploadResult: { 
            success: true, 
            path: filePath 
          },
          accessResult: {
            success: accessSuccess,
            url: publicUrl
          },
          message: 'Storage access test completed successfully'
        });
      } catch (error) {
        resolve({ 
          success: false, 
          authenticated: true,
          message: 'Unexpected error: ' + (error.message || String(error)),
          error
        });
      }
    }, 'image/png');
  });
};

// Export utilities
export default {
  applyStoragePolicies,
  testStorageAccess
};