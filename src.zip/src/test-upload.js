// src/test-upload.js
// A simple browser-compatible test script for diagnosing Supabase storage upload issues

// Create a data URL representation of a small test image (1x1 red pixel)
const createTestImage = () => {
  const canvas = document.createElement('canvas');
  canvas.width = 1;
  canvas.height = 1;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'red';
  ctx.fillRect(0, 0, 1, 1);
  
  // Convert canvas to data URL
  const dataUrl = canvas.toDataURL('image/png');
  
  // Convert data URL to Blob
  const binary = atob(dataUrl.split(',')[1]);
  const array = [];
  for (let i = 0; i < binary.length; i++) {
    array.push(binary.charCodeAt(i));
  }
  return new Blob([new Uint8Array(array)], {type: 'image/png'});
};

// Function to run the upload test
const testStorageUpload = async (supabase) => {
  console.log('--- SUPABASE STORAGE TEST ---');
  
  try {
    // Get current authenticated user
    console.log('1. Checking authentication status...');
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      console.error('Authentication error:', userError);
      return { success: false, error: 'Authentication error: ' + userError.message };
    }
    
    if (!user) {
      console.error('No authenticated user found');
      return { success: false, error: 'No authenticated user found' };
    }
    
    console.log('2. Authenticated as:', user.email);
    
    // Create a test image
    console.log('3. Creating test image...');
    const testFile = createTestImage();
    const fileName = `test_${Date.now()}.png`;
    const filePath = `test/${fileName}`;
    
    console.log('4. Uploading test image to path:', filePath);
    
    // Attempt to upload the file
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('task-photos')
      .upload(filePath, testFile, {
        cacheControl: '3600',
        upsert: false
      });
      
    if (uploadError) {
      console.error('Upload error:', uploadError);
      return { 
        success: false, 
        error: 'Upload failed: ' + uploadError.message,
        details: uploadError
      };
    }
    
    console.log('5. Upload successful!', uploadData);
    
    // Get the public URL
    const { data: { publicUrl } } = supabase.storage
      .from('task-photos')
      .getPublicUrl(filePath);
      
    console.log('6. Public URL:', publicUrl);
    
    // Try inserting into task_photos table
    console.log('7. Testing database insert...');
    const { data: dbData, error: dbError } = await supabase
      .from('task_photos')
      .insert([{
        task_id: '00000000-0000-0000-0000-000000000000', // Dummy UUID for testing
        photo_url: publicUrl,
        caption: 'Test upload'
        // Note: user_email field is not in task_photos table
      }])
      .select();
      
    if (dbError) {
      console.error('Database insert error:', dbError);
      return { 
        success: false, 
        error: 'Database insert failed: ' + dbError.message,
        details: dbError,
        uploadResult: { success: true, url: publicUrl }
      };
    }
    
    console.log('8. Database insert successful!', dbData);
    
    // Try to delete the image
    console.log('9. Testing deletion...');
    const { error: deleteError } = await supabase.storage
      .from('task-photos')
      .remove([filePath]);
      
    if (deleteError) {
      console.warn('Deletion error:', deleteError);
    } else {
      console.log('10. Deletion successful!');
    }
    
    return { 
      success: true, 
      message: 'All tests passed successfully!',
      uploadResult: { success: true, url: publicUrl },
      dbResult: dbData
    };
    
  } catch (error) {
    console.error('Unexpected error during test:', error);
    return { 
      success: false, 
      error: 'Unexpected error: ' + (error.message || String(error))
    };
  }
};

// Export for usage in browser console or as module
if (typeof module !== 'undefined') {
  module.exports = { testStorageUpload };
}

// Instructions for use:
// 1. Include this file in your HTML or import in your app
// 2. Open browser console and run: await testStorageUpload(supabase)
// 3. Check the console output for detailed diagnostics
console.log('Storage test utility loaded. Run testStorageUpload(supabase) to execute test.');