import { supabase } from './supabase';
import { sendTelegramNotification } from './whatsapp';

export type NotificationType = 'unit_added' | 'task_created' | 'task_updated' | 'progress_updated' | 'photo_added' | 'project_updated';

export interface Notification {
  id: string;
  user_id?: string;
  title: string;
  message: string;
  type: NotificationType;
  link?: string;
  read: boolean;
  created_at: string;
}

export async function createNotification({
  title,
  message,
  type,
  link
}: {
  title: string;
  message: string;
  type: NotificationType;
  link?: string;
}) {
  try {
    const { data, error } = await supabase
      .from('notifications')
      .insert([{
        title,
        message,
        type,
        link,
        read: false
      }])
      .select()
      .single();

    if (error) throw error;

    // Send Telegram notification for every notification created
    const telegramMessage = `<b>${title}</b>\n\n${message}`;
    await sendTelegramNotification(telegramMessage);

    return data;
  } catch (error) {
    console.error('Error creating notification:', error);
    throw error;
  }
}

export async function markNotificationAsRead(id: string) {
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ read: true })
      .eq('id', id);

    if (error) throw error;
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
}

export async function getUnreadNotifications() {
  try {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('read', false)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as Notification[];
  } catch (error) {
    console.error('Error fetching notifications:', error);
    throw error;
  }
}