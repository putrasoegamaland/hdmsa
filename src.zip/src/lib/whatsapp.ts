import { supabase } from './supabase';

export async function sendTelegramNotification(message: string) {
  try {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/telegram`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to send Telegram notification');
    }

    return await response.json();
  } catch (error) {
    console.error('Error sending Telegram notification:', error);
    throw error;
  }
}

// Example usage:
// Send notification when housing unit status changes
export async function notifyContractorViaTelegram(contractorId: string, message: string) {
  try {
    const { data: contractor, error } = await supabase
      .from('contractors')
      .select('name')
      .eq('id', contractorId)
      .single();

    if (error) throw error;
    
    const formattedMessage = `<b>${contractor?.name}</b>\n\n${message}`;
    return await sendTelegramNotification(formattedMessage);
  } catch (error) {
    console.error('Error notifying contractor:', error);
    throw error;
  }
}

// Send notification when task is assigned
export async function notifyTaskAssignment(taskId: string) {
  try {
    const { data: task, error } = await supabase
      .from('tasks')
      .select(`
        title,
        due_date,
        assigned_to,
        housing_unit:housing_unit_id(unit_number)
      `)
      .eq('id', taskId)
      .single();

    if (error) throw error;
    if (!task.assigned_to) return;

    const message = `<b>New Task Assigned</b>\n\nTitle: ${task.title}\nUnit: ${task.housing_unit.unit_number}\nDue: ${new Date(task.due_date).toLocaleDateString()}`;
    
    await notifyContractorViaTelegram(task.assigned_to, message);
  } catch (error) {
    console.error('Error notifying task assignment:', error);
    throw error;
  }
}