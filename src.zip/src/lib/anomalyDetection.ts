import { supabase } from './supabase';
import { differenceInDays, parseISO } from 'date-fns';

export interface Task {
  id: number;
  project_name: string;
  task_name: string;
  start_date: string | null;
  planned_end_date: string;
  actual_end_date: string | null;
  status: 'to_do' | 'in_progress' | 'completed';
}

export interface TaskAnomaly extends Task {
  day_difference: number | null;
  anomaly_status: 'terlambat' | 'tepat waktu' | 'lebih cepat' | 'in_progress' | 'not_started';
}

export const fetchTasks = async (): Promise<Task[]> => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('No authenticated user');

  const { data, error } = await supabase
    .from('construction_0pr47_tasks')
    .select('*')
    .eq('user_email', user.email)
    .order('project_name', { ascending: true });

  if (error) throw error;
  return data || [];
};

export const analyzeTaskDelays = (tasks: Task[]): TaskAnomaly[] => {
  return tasks.map(task => {
    let dayDifference: number | null = null;
    let anomalyStatus: TaskAnomaly['anomaly_status'] = 'not_started';

    const today = new Date();
    const plannedEndDate = parseISO(task.planned_end_date);

    if (task.status === 'completed' && task.actual_end_date) {
      const actualEndDate = parseISO(task.actual_end_date);
      dayDifference = differenceInDays(actualEndDate, plannedEndDate);

      if (dayDifference > 0) {
        anomalyStatus = 'terlambat';
      } else if (dayDifference < 0) {
        anomalyStatus = 'lebih cepat';
      } else {
        anomalyStatus = 'tepat waktu';
      }
    } else if (task.status === 'in_progress') {
      dayDifference = differenceInDays(today, plannedEndDate);
      anomalyStatus = 'in_progress';
      if (dayDifference > 0) {
        anomalyStatus = 'terlambat';
      }
    }

    return {
      ...task,
      day_difference: dayDifference,
      anomaly_status: anomalyStatus,
    };
  });
};