import { supabase } from './supabase';

/**
 * Utility function to calculate the progress percentage for a housing unit
 */
export const calculateProgress = (unit: any): number => {
  // Check if there's any progress data available
  if (unit.progress && unit.progress.length > 0) {
    // Find the latest progress report
    const latestProgress = unit.progress.sort((a: any, b: any) => 
      new Date(b.report_date).getTime() - new Date(a.report_date).getTime()
    )[0];
    return latestProgress.progress_percentage;
  }

  // If no progress data, calculate based on completed tasks
  if (unit.tasks && unit.tasks.length > 0) {
    const completedTasks = unit.tasks.filter((task: any) => task.status === 'completed').length;
    return Math.round((completedTasks / unit.tasks.length) * 100);
  }

  // Default to 0 if no data available
  return 0;
};

/**
 * Update the housing unit progress based on completed tasks
 * @param housingUnitId The ID of the housing unit to update
 */
export const updateHousingUnitProgress = async (housingUnitId: string): Promise<void> => {
  try {
    // Get all tasks for this housing unit
    const { data: tasks, error: tasksError } = await supabase
      .from('tasks')
      .select('status')
      .eq('housing_unit_id', housingUnitId);
    
    if (tasksError) throw tasksError;
    
    if (!tasks || tasks.length === 0) return;
    
    // Calculate the progress percentage
    const completedTasks = tasks.filter(task => task.status === 'completed').length;
    const progressPercentage = Math.round((completedTasks / tasks.length) * 100);
    
    // Update or insert the progress record
    const { error: progressError } = await supabase
      .from('housing_unit_progress')
      .insert({
        housing_unit_id: housingUnitId,
        progress_percentage: progressPercentage,
        report_date: new Date().toISOString(),
      });
      
    if (progressError) throw progressError;
    
  } catch (error) {
    console.error('Error updating housing unit progress:', error);
    throw error;
  }
};