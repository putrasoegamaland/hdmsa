import { supabase } from './supabase';

export interface User {
  id: string;
  email: string;
  role: 'admin' | 'user';
}

export async function getCurrentUser(): Promise<User | null> {
  try {
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      console.error('Error getting auth user:', userError);
      throw userError;
    }
    
    if (!user) {
      console.log('No authenticated user found');
      return null;
    }

    return {
      id: user.id,
      email: user.email!,
      role: (user.user_metadata?.role || 'user') as 'admin' | 'user'
    };
  } catch (error) {
    console.error('Error in getCurrentUser:', error);
    return null;
  }
}

export async function checkPermission(action: string): Promise<boolean> {
  const user = await getCurrentUser();
  if (!user) return false;

  // Admin has all permissions
  if (user.role === 'admin') return true;

  // Regular user permissions
  switch (action) {
    // Housing Units
    case 'housing_units.view':
    case 'housing_units.create':
    case 'housing_units.edit':
      return true;
    case 'housing_units.delete':
      return false;

    // Contractors  
    case 'contractors.view':
    case 'contractors.create':
    case 'contractors.edit':
    case 'contractors.delete':
      return true;

    // Tasks
    case 'tasks.view':
    case 'tasks.edit':
      return true;
    case 'tasks.create':
    case 'tasks.delete':
      return false;

    default:
      return false;
  }
}

export async function handleUnauthorized(message: string = 'Unauthorized action') {
  // Create notification for unauthorized attempt
  try {
    await supabase.from('notifications').insert({
      title: 'Unauthorized Action Attempted',
      message,
      type: 'error'
    });
  } catch (error) {
    console.error('Error creating unauthorized notification:', error);
  }

  throw new Error(message);
}